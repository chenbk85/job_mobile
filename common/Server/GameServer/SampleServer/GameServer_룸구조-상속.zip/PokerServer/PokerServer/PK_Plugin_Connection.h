/* file : PK_Plugin_Connection.h
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-05 11:04:50
comp.: www.neowiz.com
title : 
desc : 

*/

#ifndef __PK_Plugin_Connection_header__
#define __PK_Plugin_Connection_header__
#pragma once

#include "PokerServer_header.h"
#include "MSG_Plugin_Connection.h"

#define PK_CON(pCon,Plugin) PK_Plugin_Connection*pCon=(PK_Plugin_Connection*)Plugin;



struct PK_Plugin_Connection : public MSG_Plugin_Connection
{
public: 
	//--------------------------------------------------------------------------
	// Plugin_IConnection구현부.
	//--------------------------------------------------------------------------
	MOB_INTERFACE_Plugin_IConnection(PK_Plugin_NetIOModel);

	virtual void OnReadPacket_GLReqGameProtocol(GLReqGameProtocol* packet);
	virtual void OnReadPacket_GReqGameEnter(GReqGameEnter* packet);
	virtual void OnReadPacket_GReqGameLeave(GReqGameLeave* packet);
	virtual void OnReadPacket_Unkown(GReqProtocol *packet);

};

 
#endif // __PK_Plugin_Connection_header__
