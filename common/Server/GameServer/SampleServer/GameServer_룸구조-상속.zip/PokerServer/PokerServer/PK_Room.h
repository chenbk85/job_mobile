/* file : PK_Room.h
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-10 18:43:19
comp.: www.neowiz.com
title : 
desc : 

*/

#ifndef __PK_Room_header__
#define __PK_Room_header__
#pragma once



//#--------------------------------------------------------------------------
struct PK_Room : public MSG_Room
//#--------------------------------------------------------------------------
{
	MOB_HEADER_ROOM(PK_Plugin_Connection);
public:
	void User_Join(PK_Plugin_Connection*);
};



#endif // __PK_Room_header__
