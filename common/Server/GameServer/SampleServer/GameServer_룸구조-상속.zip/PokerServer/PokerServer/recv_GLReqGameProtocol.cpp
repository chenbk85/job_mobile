/* file : recv_GLReqGameProtocol.cpp
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-05 19:48:39
comp.: www.neowiz.com
title : 
desc : 

*/

#include "stdafx.h"

#include "stdafx.h"
#include "PK_Plugin_Connection.h"


MOB_RECV_PACKET(PK_Plugin_Connection,req_game_test_packet) //pCon , pRecvData
{
	jRETURN(pRecvData);
	int test_int = pRecvData->test_int();
	string test_string = pRecvData->test_string();

	MOB_MAKE_SEND_PACKET(sendMsg,pSendData,ans_game_test_packet);

	pSendData->set_test_string("asdf");
	pSendData->set_test_int(1234);

	pCon->send_to_all(sendMsg,nMOB::eSAT_SendAll); //나를 포함해(false) 모든 유저에게 보낼때.
	// pCon->send_to_room_user(sendMsg); // 방의 모든 유저에게 보냄.
	// pCon->send_me(sendMsg); //자신에게 다시 보낼때
	// pCon->send_to(sendMsg,1234); //접속번호 1234에게 보낼때.
	//pCon->setTimer(eTIMER_START);
}
