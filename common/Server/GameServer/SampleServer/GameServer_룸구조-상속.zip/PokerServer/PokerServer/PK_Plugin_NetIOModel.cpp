/* file : PK_Plugin_NetIOModel.cpp
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-05 18:50:11
comp.: www.neowiz.com
title : 
desc : 

*/

#include "stdafx.h"
#include "PokerServer_header.h"
#include "PK_Plugin_NetIOModel.h"
#include "PK_Room.h"




MOB_IMPLEMENT_CONNECTION_MANAGER(	PK_Plugin_NetIOModel,PK_Plugin_Connection	,iMAX_USER_COUNT);
MOB_IMPLEMENT_ROOM_MANAGER(			PK_Plugin_NetIOModel,PK_Room				,iMAX_ROOM_COUNT);

