/* file : PK_Plugin_Connection_template_code.cpp
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-05 20:12:12
comp.: www.neowiz.com
title : 
desc : 

*/

#include "stdafx.h"
#include "PK_Plugin_MessageList.h"
#include "PK_Plugin_Connection.h"
#include "PK_Room.h"

//--------------------------------------------------------------------------
void PK_Plugin_Connection::OnReadPacket_GLReqGameProtocol( GLReqGameProtocol* p ) 
//--------------------------------------------------------------------------
{
	jRETURN(p);
	switch (p->type()) 
	{
#define __call_GLReqGameProtocol_Type(PACKET_NAME,HELP) \
case GLReqGameProtocol_Type_##PACKET_NAME:\
	void On_##PACKET_NAME(PK_Plugin_Connection* pCon,s_##PACKET_NAME* p);\
	On_##PACKET_NAME(this,p->mutable_m_##PACKET_NAME());break;\

		for_each_PK_Plugin_MessageList(__call_GLReqGameProtocol_Type);
	}
}


