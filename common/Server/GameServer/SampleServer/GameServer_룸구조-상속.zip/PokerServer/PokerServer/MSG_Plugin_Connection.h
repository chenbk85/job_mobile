/* file : MSG_Plugin.h
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-11 10:56:13
comp.: www.neowiz.com
title : 
desc : 

*/

#ifndef __MSG_Plugin_header__
#define __MSG_Plugin_header__
#pragma once

struct MSG_Plugin_NetIOModel;


struct MSG_Room
{
	virtual void for_each(boost::function<void(nMOB::Plugin_IConnection*)>& func)=0;
};

struct MSG_Plugin_Connection : public Plugin_IConnection
{
	virtual void OnReadPacket_GLReqGameProtocol(GLReqGameProtocol* packet)=0;
	virtual void OnReadPacket_GReqGameEnter(GReqGameEnter* packet)=0;
	virtual void OnReadPacket_GReqGameLeave(GReqGameLeave* packet)=0;
	virtual void OnReadPacket_Unkown(GReqProtocol *packet)=0;

	MSG_Plugin_NetIOModel* GetParent();
	virtual bool MOB_OnReadPacket( char* pBody, int iLengthBody );
	void send_to(GAnsProtocol& msg, pp_game_id_t gid); /*패킷을 다른 사람에게 보낸다.*/
	void send_me(GAnsProtocol& msg);/*자신에게 다시 패킷을 보낸다.*/
	void send_to_all(GAnsProtocol& msg,ESendAllType eSkipMe);/*패킷을 모두 보낸다.*/
	void send_to_room_user(GAnsProtocol& msg,ESendAllType eSkipMe);/*패킷을 모두 보낸다.*/
	virtual MSG_Room*	Get_room();

	ug_room_id_t	Get_room_id()	{ return m_MyInfo.roomid();}
	GReqGameEnter	m_MyInfo;

};

//#--------------------------------------------------------------------------
struct MSG_Plugin_NetIOModel : public nMOB::Plugin_INetIOModel
	//#--------------------------------------------------------------------------
{
	virtual Plugin_IConnection*	Connection_Find(nMOB::pp_game_id_t gameID);
	virtual MSG_Room*			Room_Find(nMOB::ug_room_id_t rid)=0;

};

#endif // __MSG_Plugin_header__
