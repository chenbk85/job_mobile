/* file : PK_Plugin_message_list.h
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-05 20:16:12
comp.: www.neowiz.com
title : 
desc : 

*/

#ifndef __PK_Plugin_message_list_header__
#define __PK_Plugin_message_list_header__
#pragma once



#define for_each_PK_Plugin_MessageList(X)\
	X(req_game_test_packet	," 테스트용.")\

jDEFINE_ENUM_CODE2(PK_Plugin_MessageList);



#endif // __PK_Plugin_message_list_header__
