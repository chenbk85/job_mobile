/* file : MSG_Plugin.cpp
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-11 10:56:15
comp.: www.neowiz.com
title : 
desc : 

*/

#include "stdafx.h"
#include "MSG_Plugin_Connection.h"



//#--------------------------------------------------------------------------
MSG_Plugin_NetIOModel* MSG_Plugin_Connection::GetParent()
//#--------------------------------------------------------------------------
{
	return (MSG_Plugin_NetIOModel*)m_pParent;
}


//#--------------------------------------------------------------------------
MSG_Room* MSG_Plugin_Connection::Get_room()
//#--------------------------------------------------------------------------
{ 
	return GetParent()->Room_Find(Get_room_id());
}

//--------------------------------------------------------------------------
void MSG_Plugin_Connection::send_me(GAnsProtocol& msg)
//--------------------------------------------------------------------------
{
	MOB_NetPacketBuffer & wBuf = m_pMOB_IConnection->m_writeBuff;
	int32 nSize = msg.ByteSize();
	wBuf.header.data_length = msg.ByteSize()+sizeof(int);
	jRETURN(wBuf.header.data_length<nMOB::BUFFER_SIZE);
	memcpy(wBuf.pBody, &nSize, sizeof(int32));
	assert(sizeof(wBuf.header)==sizeof(int32));
	google::protobuf::io::ArrayOutputStream os(wBuf.pBody+sizeof(int), msg.ByteSize());
	msg.SerializeToZeroCopyStream(&os);
	m_pMOB_IConnection->WritePacket(&wBuf);
}

//#--------------------------------------------------------------------------
void MSG_Plugin_Connection::send_to(GAnsProtocol& msg, int gameID)
//#--------------------------------------------------------------------------
{	//패킷을 다른 사람에게 보낸다.
	MSG_Plugin_Connection* pCon = (MSG_Plugin_Connection*)GetParent()->Connection_Find(gameID);
	jRETURN(pCon);
	pCon->send_me(msg);
}

//#--------------------------------------------------------------------------
void MSG_Plugin_Connection::send_to_all(GAnsProtocol& msg,ESendAllType eSkipMe)
//#--------------------------------------------------------------------------
{
#	define jLAMDA_send_to_all_(X,Z) X(GAnsProtocol&, msg) Z(pp_game_id_t,gid)
	jLAMDA_for_each(send_to_all_,MOB_IConnection*)
	{
		PK_CON(pCon , it->m_pPlugin);
		if( gid!=-1 && it->m_pPlugin->m_gid == gid ) return;
		pCon->send_me(msg);
	}
	jLAMDA_end();

	pp_game_id_t gid = -1;
	if(eSkipMe == nMOB::eSAT_SkipMe)
	{
		gid = m_gid;
	}

	boost::function<void (MOB_IConnection*)> func = send_to_all_(msg,gid);
	GetParent()->m_pMOB_INetIOModel->for_each(func);
}


//#--------------------------------------------------------------------------
void MSG_Plugin_Connection::send_to_room_user(GAnsProtocol& msg,ESendAllType eSkipMe)
//#--------------------------------------------------------------------------
{
#define jLAMDA_send_room_user_all(X,Z)  X(pp_game_id_t,skip_gid) Z(GAnsProtocol& , msg)
	jLAMDA_for_each(send_room_user_all,nMOB::Plugin_IConnection*)
	{
		PK_Plugin_Connection* pCon = (PK_Plugin_Connection*)it;
		if( pCon->m_gid == skip_gid) return;
		pCon->send_me(msg);
	}
	jLAMDA_end();


	boost::function<void(Plugin_IConnection*)> func = send_room_user_all(m_gid , msg);
	MSG_Room* pRoom = Get_room();
	jRETURN(pRoom);
	pRoom->for_each(func);
}

//--------------------------------------------------------------------------
bool MSG_Plugin_Connection::MOB_OnReadPacket( char* pBody, int iLengthBody )
//--------------------------------------------------------------------------
{
	google::protobuf::io::ArrayInputStream is(pBody, iLengthBody);
	GReqProtocol recvMsg;
	recvMsg.ParseFromZeroCopyStream(&is);
	switch(recvMsg.type())
	{
	case GReqProtocol_Type_GLREQGAMEPROTOCOL:
		{
			OnReadPacket_GLReqGameProtocol(recvMsg.mutable_reqgameprotocol());
			break;
		}
	case GReqProtocol_Type_GREQGAMEENTER:
		{
			GReqGameEnter* p= recvMsg.mutable_reqgameenter();
			jBREAK(p);
			OnReadPacket_GReqGameEnter(p);
			break;
		}
	case GReqProtocol_Type_GREQGAMELEAVE:
		{
			GReqGameLeave* p = recvMsg.mutable_reqgameleave();
			jBREAK(p);
			OnReadPacket_GReqGameLeave(p);
			break;
		}
	default:
		{
			OnReadPacket_Unkown(&recvMsg);
			jWARN(_T("recvMsg.type() : invalied packet"));
			return false;// return false이면 MOB_ OnDisconnect()가 호출되고 접속해제됨.
		}
	}//switch(recvMsg.type())
	return true;
}



Plugin_IConnection*  MSG_Plugin_NetIOModel::Connection_Find(pp_game_id_t gameID)
{
	jRETURN_ret(0,m_pMOB_INetIOModel);
	boost::function<bool(MOB_IConnection*)> func = find_by_cid(gameID);
	return m_pMOB_INetIOModel->find_if(func);
}

