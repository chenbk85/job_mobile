/* file : PK_Room.cpp
Coder : by icandoit ( icandoit@neowiz.com)
Date : 2012-01-10 18:43:21
comp.: www.neowiz.com
title : 
desc : 

*/

#include "stdafx.h"
#include "PK_Room.h"


void PK_Room::MOB_OnCreate()
{

}
void PK_Room::MOB_OnDelete()
{

}
void PK_Room::User_Join(PK_Plugin_Connection*)
{

}
