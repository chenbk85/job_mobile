using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using nNWM;
using nNWM.nGui;

using jxD = nNWM.nXML.jxDocument; // xml doc;
using jxE = nNWM.nXML.jxElement; // xml element
using jxA = nNWM.nXML.jxVar; // element attribute
using jxV = nNWM.nXML.jxVar; // attribute or element data
using string_id_t = System.Int32;


public class GuiEventManager : jGuiEventManager
{
	public CmdEventManager m_CMD;

	protected override void OnStart()
	{
		if (m_CMD == null)
		{
			Debug.LogError("m_CMD is null. set CmdEventManager gameobject to m_CMD");
			return;
		}
		m_CMD.Set_GuiEvent_LogWindow(GetComponent<GuiEvent_LogWindow>());
	}

	protected override void jGuiStage_LoadedXML(nNWM.nXML.jxDocument stageXml)
	{
		jxE xml = stageXml.m_Root;
		jxV v =null;
		jxE ePlayerList = xml.FindByAttr("Name", "PlayerList", out v);
		int iTot = m_CMD.m_PlayerCmdFile.Length - 1;
		Debug.Log("m_CMD.m_PlayerCmdFile.Length  = " + m_CMD.m_PlayerCmdFile.Length);
		for (int i = 0; i <  iTot; ++i)
		{
			jxE eClone = ePlayerList.begin().MakeClone();
			ePlayerList.InsertChild(eClone);
		}
	
		int idx = 0;
		foreach (jxE e in ePlayerList)
		{
			e.Set_string(m_CMD.m_PlayerCmdFile[idx++].USER_ID);
		}
	}
	protected override void jGuiStage_LoadedGUI(jGuiStage stage)
	{

	}

}//public class GuiEventManager

