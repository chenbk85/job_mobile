
//#--------------------------------------------------------------------------
//CmdEvent_base ���� ���� �ڵ�.
//#--------------------------------------------------------------------------
//asdf�� �ش� ������Ʈ�� �̸����� �ٲ۴�.


using UnityEngine;
using System.Collections;
using user_id_t = System.Int64;
using nNWM;

public class aaaa_cmd_item : CmdEvent_base
{
	nNWM.nAAAA.NetEventPlugin_aaaa cmd_NetEventPlugin(string sUID)
	{
		return (nNWM.nAAAA.NetEventPlugin_aaaa)base.cmd_NetEventPlugin(sUID);
	}

	void buy(nNWM.nConsole.jConsoleArg arg)
	{
		const int eUID = 0 , eITEM_NAME=1 , eITEM_COUNT=2;
		
		if (IsFail_ArgCheck(arg, "<user_id> <item_name> [item_count=1]")) return;
		
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }
		//-------------------------------------------------------------------
		
		string item_name = arg[eITEM_NAME]; // �Ǵ� arg.Get_string(eITEM_NAME)
		int item_count = arg.Get_int32(eITEM_COUNT);

		//plugin.m_User.BuyItem(item_name, item_count);
		m_CMD.Log("item_name = " + item_name + " item_count=" + item_count);
	}


	/*
	 *  ���� ���ø� �ڵ�.   asdf�� ���ϴ� Ŀ�ǵ��̸����� ����.
	 
	void asdf(nNWM.nConsole.jConsoleArg arg)
	{
		const int eUID = 0;
		if (IsFail_ArgCheck(arg, "<uid>")) return;
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }
		//-------------------------------------------------------------------

		var sd = plugin.Make(nProtoBSasdf.Client_GameServer.Type.asdf);
		sd.m_asdf = new nProtoBS.s_asdf
		{
			uid = plugin.GetUserID(),
			batter = arg.Get_int32(eBATTER),
		};
		plugin.send_to_gs(sd);

	}
	 
	 **/



}//public class aaaa_cmd_item : CmdEvent_base

