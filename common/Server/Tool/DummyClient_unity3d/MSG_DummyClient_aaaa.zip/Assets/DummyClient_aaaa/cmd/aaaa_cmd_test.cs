using UnityEngine;
using System.Collections;
using user_id_t = System.Int64;
using nNWM;

public class aaaa_cmd_test : CmdEvent_base
{
	nNWM.nAAAA.NetEventPlugin_aaaa cmd_NetEventPlugin(string sUID)
	{
		return (nNWM.nAAAA.NetEventPlugin_aaaa)base.cmd_NetEventPlugin(sUID);
	}

	void my_func(nNWM.nConsole.jConsoleArg arg)
	{
		const int eARG1 = 0 ,eARG2=1 ,eARG3=2;
		if (IsFail_ArgCheck(arg, "<arg1> <arg2> <arg3>")) return;

		string arg1 = arg[eARG1];
		string arg2 = arg[eARG2];
		string arg3 = arg[eARG3];

		m_CMD.Log("arg1 = " + arg1 + " arg2 = " + arg2 + " arg3 = " + arg3);

	}


	/*
	 * ���ø� �ڵ�.
	 
	void aaaa(nNWM.nConsole.jConsoleArg arg)
	{
		const int eUID = 0;
		if (IsFail_ArgCheck(arg, "<uid>")) return;
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }
		//-------------------------------------------------------------------

		var sd = plugin.Make(nProtoGSaaaa.Client_GameServer.Type.aaaa);
		sd.m_aaaa = new nProtoBS.s_aaaa
		{
			uid = plugin.GetUserID(),
			batter = arg.Get_int32(eBATTER),
		};
		plugin.send_to_gs(sd);

	}
	 
	 * */

}//public class aaaa_cmd_test : CmdEvent_base
