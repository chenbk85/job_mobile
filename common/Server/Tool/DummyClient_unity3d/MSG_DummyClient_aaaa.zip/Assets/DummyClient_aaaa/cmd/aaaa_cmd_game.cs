using UnityEngine;
using System.Collections;
using user_id_t = System.Int64;
using nNWM;

public class aaaa_cmd_game : CmdEvent_base
{
	nNWM.nAAAA.NetEventPlugin_aaaa cmd_NetEventPlugin(string sUID)
	{
		return (nNWM.nAAAA.NetEventPlugin_aaaa)base.cmd_NetEventPlugin(sUID);
	}
	//#--------------------------------------------------------------------------
	void match_auto_join_team(nNWM.nConsole.jConsoleArg arg)
	//#--------------------------------------------------------------------------
	{
		const int eUID = 0;
		if (IsFail_ArgCheck(arg, "<uid>")) return;
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }

		var sd = new MSG.ReqAutoJoin
		{
			CategoryID = 0,
			ChannelID = 0
		};
		plugin.send_to_MSG(sd);
	}
	
	//#--------------------------------------------------------------------------
	void UReqLeaveGame(nNWM.nConsole.jConsoleArg arg)
	//#--------------------------------------------------------------------------
	{
		const int eUID = 0;
		if (IsFail_ArgCheck(arg, "<uid>")) return;
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }
		//-------------------------------------------------------------------

		byte[] info = Serialize<string>(plugin.GetUserID().ToString());
		//info[0] = 111;
		var sd = new MSG.ReqLeaveGame
		{
			GameID = plugin.GetUserID(),
			LeaveInfo = info,
		};
		plugin.send_to_MSG(sd);
	}


	/*
	 * ���ø� �ڵ�.
	 
	//#--------------------------------------------------------------------------
	void aaaa(nNWM.nConsole.jConsoleArg arg)
	//#--------------------------------------------------------------------------
	{
		const int eUID = 0;
		if (IsFail_ArgCheck(arg, "<uid>")) return;
		var plugin = cmd_NetEventPlugin(arg[eUID]);
		if (plugin == null) { m_CMD.LogWarning("user not found"); return; }
	  //nNWM.nAAAA.jUser user= plugin.m_User;
		//-------------------------------------------------------------------

		var sd = plugin.Make(nProtoGSaaaa.Client_GameServer.Type.aaaa);
		sd.m_aaaa = new nProtoBS.s_aaaa
		{
			//uid = plugin.GetUserID(),
			//batter = arg.Get_int32(eBATTER),
		};
		plugin.send_to_gs(sd);

	}
	 
	 * */

}//public class aaaa_cmd_game : CmdEvent_base<aaaa_cmd_game>

