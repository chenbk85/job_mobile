using UnityEngine;
using System.Collections;
using nNWM;

public class aaaa_recv_UserGateServer_Client : MonoBehaviour
{
	//#--------------------------------------------------------------------------
	// Util function 
	//#--------------------------------------------------------------------------
	nProtoUGaaaa.UserGateServer_Client ToRecvData(nNWM.nDummy.NetEventArg arg) 
	{ 
		return (nProtoUGaaaa.UserGateServer_Client)arg.recvData; 
	}
	nNWM.nAAAA.NetEventPlugin_aaaa ToPlugin(nNWM.nDummy.NetEventArg arg) 
	{ 
		return (nNWM.nAAAA.NetEventPlugin_aaaa)arg.plugin; 
	}

	//#--------------------------------------------------------------------------
	// UserGate Server -> Client Net Receiver.
	//#--------------------------------------------------------------------------
	public void ug2x_echo(nNWM.nDummy.NetEventArg arg)
	{
		var rd = ToRecvData(arg).m_ug2x_echo;
		var plugin = ToPlugin(arg);
		//User_aaaa user = plugin.m_User;

		plugin.NetLog(nNWM.nUtil.jDumper.Dump(rd, true));
	}


	/*
	 * �Ʒ� ���ø� �ڵ带 �����Ͽ� ���. aaaa�� ���ϴ� ���������̸����� �ٲٽÿ�.
	 
	public void aaaa(nNWM.nDummy.NetEventArg arg)
	{
		var rd = ToRecvData(arg).m_aaaa;
		var plugin = ToPlugin(arg);
		//User_aaaa user = plugin.m_User;

		plugin.NetLog(nNWM.nUtil.jDumper.Dump(rd, true));
	}
	  
	 *
	 * */
}
