namespace MSG
{
	public class MSGConnected
	{
		public string Ip{get;set;}
		public int port{get;set;}
	}
}