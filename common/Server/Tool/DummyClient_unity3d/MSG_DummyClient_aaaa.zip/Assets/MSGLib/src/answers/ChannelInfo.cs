using MSG.Protocol;
namespace MSG
{
	/**  채널에 대한 정보를 표현하는 클래스. */
	public class ChannelInfo
	{
		/**  채널 ID */
		public int ID { get; set; }
		/**  채널에 대한 설명  */
		public string Description { get; set; }
	}
}