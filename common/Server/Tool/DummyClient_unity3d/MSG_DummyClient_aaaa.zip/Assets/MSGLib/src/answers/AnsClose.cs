using MSG.Protocol;
namespace MSG
{

	/**  게이트웨이의 종료 응답 메시지 */
	/**  @warning ReqClose와 짝이 안맞는 응답의 경우는 에러 상황에서 게이트웨이가 종료될때 전달된다 */
	public class AnsClose
	{
	}
}