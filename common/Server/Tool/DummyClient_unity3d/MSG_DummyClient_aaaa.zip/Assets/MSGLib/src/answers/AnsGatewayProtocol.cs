using MSG.Protocol;
namespace MSG
{
	/**  게이트웨이의 사용자 메시지에 대한 응답 */
	public class AnsGatewayProtocol
	{
		public byte[] Buffer {get;set;}
	}
}