using MSG.Protocol;
namespace MSG
{
	/**  게임서버에서부터 나온 게임관련 응답 메시지 */
	public class AnsGameProtocol
	{
		public byte[] Buffer {get;set;}
	}
}