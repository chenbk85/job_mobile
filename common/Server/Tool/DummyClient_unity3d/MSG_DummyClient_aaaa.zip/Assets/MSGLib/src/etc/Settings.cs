namespace MSG
{
	public class Settings
	{
		public const int FrameworkVersion = 351;
	}
}

