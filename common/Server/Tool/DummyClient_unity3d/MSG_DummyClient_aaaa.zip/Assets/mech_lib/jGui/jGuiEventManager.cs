using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using nNWM;
using nNWM.nGui;

using jxD = nNWM.nXML.jxDocument; // xml doc;
using jxE = nNWM.nXML.jxElement; // xml element
using jxA = nNWM.nXML.jxVar; // element attribute
using jxV = nNWM.nXML.jxVar; // attribute or element data
using string_id_t = System.Int32;


public class jGuiEventManager : MonoBehaviour
{
	public GUISkin m_GUISkin;
	public TextAsset m_XmlFile;
	protected jGuiStage m_jGuiStage;
	public string m_GuiEventPrifix = "GuiEvent_";

	public static jGuiStage Load(string name, string xml, GUISkin skin, GameObject eventHandler, string GuiEventPrifix="GuiEvent_")
	{
		jGuiStage stage = new jGuiStage();
		stage.Load(name, xml, skin, eventHandler, GuiEventPrifix);
		return stage;
	}

	void Start()
	{
		//LevelXMLFile = (TextAsset)Resources.LoadAssetAtPath("xml/xml_test.xml", typeof(TextAsset));
		m_jGuiStage = jGuiEventManager.Load(m_XmlFile.name, m_XmlFile.text, m_GUISkin, gameObject, m_GuiEventPrifix);
		if (m_jGuiStage == null)
		{
			throw new System.Exception(m_XmlFile.name + " : " + m_XmlFile.text + " load fail");
		}

		OnStart();

	}

	void OnGUI()
	{
		if (m_jGuiStage != null)
			m_jGuiStage.OnGUI();

		OnGui();
	}

	protected virtual void OnStart()
	{

	}
	protected virtual void OnGui()
	{

	}
	protected virtual void jGuiStage_LoadedXML(nNWM.nXML.jxDocument stageXml)
	{

	}
	protected virtual void jGuiStage_LoadedGUI(jGuiStage stage)
	{

	}

}//public class jGui
