﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using ProtoBuf;

namespace ProtoBufRemote
{
    /// <summary>
    /// An RpcChannel that communicates with datagram packets. 
    /// Does not work with any Stream, it must be a bidrectional channel like NetworkStream.
    /// </summary>
    public class DatagramRpcChannelClient : RpcChannel
    {
        private readonly Queue<RpcMessage> queuedMessages = new Queue<RpcMessage>();
        private readonly Mutex queueMutex = new Mutex();
        private readonly AutoResetEvent queueEvent = new AutoResetEvent(false);
        private readonly ManualResetEvent closeEvent = new ManualResetEvent(false);
        private readonly Thread readThread;
        private readonly Thread writeThread;
        private byte[] readBuffer;
        private byte[] writeBuffer;
        private UdpClient client;
        private IPEndPoint ep;
        private long totalBytesRead;
        private long totalBytesWritten;

        public DatagramRpcChannelClient(RpcController controller, UdpClient client, IPEndPoint ep)
            : base(controller)
        {
            this.client = client;
            this.ep = ep;
            readThread = new Thread(ReadRun);
            writeThread = new Thread(WriteRun);
        }

        public long TotalBytesRead { get { return Interlocked.Read(ref totalBytesRead); } }

        public long TotalBytesWritten { get { return Interlocked.Read(ref totalBytesWritten); } }

        public override void Start()
        {
            readThread.Start();
            writeThread.Start();
        }

        /// <summary>
        /// Closes all the streams and requests that the channel shutdown, then joins the channel threads until they
        /// have terminated.
        /// </summary>
        public void CloseAndJoin(bool isCloseWriteStream = true)
        {
            //readStream must be closed, it's the only way we can terminate the readThread cleanly. Even async reads
            //don't support cancellation
            //readStream.Close();
            //if (isCloseWriteStream)
            //    writeStream.Close();
            closeEvent.Set();
            readThread.Join();
            writeThread.Join();
        }

        internal override void Send(RpcMessage message)
        {
            queueMutex.WaitOne();

            queuedMessages.Enqueue(message);
            queueEvent.Set();

            queueMutex.ReleaseMutex();
        }

        private void ReadRun()
        {
            //byte[] buffer = new byte[1024];
            int bytesRemaining = sizeof(int);
            int bufferPos = 0;
            bool isTerminated = false;

            while (!isTerminated)
            {
                // read to buffer
                try
                {
                    readBuffer = client.Receive(ref this.ep);
                }
                catch (SocketException e)
                {
                    if (e.ErrorCode == 10060) // Timeout exception
                        continue;
                }
                if (readBuffer == null)
                    continue;

                bytesRemaining = BitConverter.ToInt32(readBuffer, 0);
                bufferPos = sizeof(int);

                //if (bytesRemaining > buffer.Length)
                //    buffer = new byte[bytesRemaining];

                //var memStream = new MemoryStream(buffer, 0, bufferPos);
                var memStream = new MemoryStream(readBuffer, bufferPos, bytesRemaining);
                RpcMessage message = Serializer.Deserialize<RpcMessage>(memStream);
                Receive(message);

                readBuffer = null;

                Interlocked.Add(ref totalBytesRead, bytesRemaining + bufferPos);
            }
        }

        private void WriteRun()
        {
            var waitHandles = new WaitHandle[] { queueEvent, closeEvent };
            bool isTerminated = false;
            var memStream = new MemoryStream();
            writeBuffer = new byte[512];
            while (!isTerminated)
            {
                int waitIndex = WaitHandle.WaitAny(waitHandles);

                queueMutex.WaitOne();
                while (queuedMessages.Count > 0)
                {
                    RpcMessage message = queuedMessages.Dequeue();
                    try
                    {
                        memStream.Position = 0;
                        Serializer.SerializeWithLengthPrefix(memStream, message, PrefixStyle.Fixed32);
                        Buffer.BlockCopy(memStream.GetBuffer(), 0, writeBuffer, 0, (int)memStream.Length);
                        client.Send(writeBuffer, (int)memStream.Length);
                        Interlocked.Add(ref totalBytesWritten, memStream.Position);
                    }
                    catch (InvalidOperationException)
                    {
                        isTerminated = true;
                        break;
                    }
                    catch (IOException)
                    {
                        isTerminated = true;
                        break;
                    }
                }
                queueMutex.ReleaseMutex();

                if (waitIndex == 1)
                    break;
            }
            Array.Clear(writeBuffer, 0, writeBuffer.Length);
        }
    }
}
