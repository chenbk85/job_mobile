﻿using System;
using System.Collections.Generic;

namespace M3Server
{
    class SampleService : ISampleService
    {
        public bool TestPrime(int x)
        {
            Console.WriteLine("Testing whether {0} is a prime number.", x);
            if (x == 1)
                return false;
            if (x == 2)
                return true;
            if ((x & 1) == 0)
                return false;
            for (int divisor = 3; divisor < x; divisor += 2)
            {
                if ((x % divisor) == 0)
                    return false;
            }
            return true;
        }

        public void SyncAni(String str)
        {
            Console.WriteLine("SyncAni {0}", str);
        }
        public void SyncSkill(Int32 id)
        {
            Console.WriteLine("SyncSkill {0}", id);
        }
        public void RequestNPCInfo(Int32 id)
        {
            Console.WriteLine("RequestNPCInfo {0}", id);
        }
        public void RequestNPCTarget(long id)
        {
            Console.WriteLine("RequestNPCTarget {0}", id);
        }
        public void NPCDamaged(long id, int amnt)
        {
            Console.WriteLine("NPCDamaged {0},{1}", id, amnt);
        }
    }
}