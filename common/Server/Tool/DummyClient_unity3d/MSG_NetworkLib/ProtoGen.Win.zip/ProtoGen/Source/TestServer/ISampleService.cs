﻿using System;
using System.Collections.Generic;

namespace M3Server
{
    public interface ISampleService
    {
        bool TestPrime(int x);
        void SyncAni(String str);
        void SyncSkill(Int32 id);
        void RequestNPCInfo(Int32 id);
        void RequestNPCTarget(long id);
        void NPCDamaged(long id, int amnt);
    }

}
