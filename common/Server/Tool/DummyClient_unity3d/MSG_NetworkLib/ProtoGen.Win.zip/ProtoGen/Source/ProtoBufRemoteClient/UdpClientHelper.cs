﻿/* Project : M3 network library
* Author : Sung Ho Kim
* Date : 07/24/2012
* Brief : UDP Client helper class
* Usage : UdpClientHelper
*/
using System;
using System.Net;
using System.Net.Sockets;
using ProtoBufRemote;

namespace M3
{
    // User class to connect, send using ProtoBufRemote library
    public class UdpClientHelper<T> where T : class
    {
        private UdpClient client;
        private IPHostEntry remoteHostEntry;
        private IPEndPoint remoteIpEndPoint;
        public T service;

        public UdpClientHelper()
        {
            //Create an instance of UdpClient.
            this.client = new UdpClient();
        }

        ~UdpClientHelper()  // destructor
        {
            // cleanup
            this.client.Close();
            this.client = null;
        }

        public void Start(String serverName, int udpPort, int timeOut = 0)
        {
            try
            {
                this.client.ExclusiveAddressUse = false;
                this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                this.client.Connect(serverName, udpPort);

                remoteHostEntry = Dns.GetHostEntry(serverName);
                remoteIpEndPoint = new IPEndPoint(remoteHostEntry.AddressList[0], udpPort);

                setTimeout(timeOut);

                var controller = new RpcController();
                var rpcclient = new RpcClient(controller);

                var channel = new UdpRpcChannelClient(controller, this.client, remoteIpEndPoint);

                channel.Start();

                this.service = rpcclient.GetProxy<T>();
            }
            catch (Exception e)
            {
                Console.WriteLine("An Exception Occurred!");
                Console.WriteLine(e.ToString());
            }
        }

        public void Send() { }

        protected void setTimeout(int milliseconds)
        {
            int sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout);
            Console.WriteLine("Default SendTimeout: {0}", sockopt);
            this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, milliseconds);
            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout);
            Console.WriteLine("New SendTimeout: {0}", sockopt);

            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout);
            Console.WriteLine("Default ReceiveTimeout: {0}", sockopt);
            this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, milliseconds);
            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout);
            Console.WriteLine("New ReceiveTimeout: {0}", sockopt);
        }

    }

}
