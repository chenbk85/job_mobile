﻿using System;
using System.Collections.Generic;

namespace M3
{
    public interface ISampleService
    {
        bool TestPrime(int x);
        IAsyncResult BeginTestPrime(int x, AsyncCallback callback, object state);
        bool EndTestPrime(IAsyncResult asyncResult);

        void SyncAni(String x);
        IAsyncResult BeginSyncAni(String x, AsyncCallback callback, object state);
        void EndSyncAni(IAsyncResult asyncResult);

        void SyncSkill(Int32 x);
        IAsyncResult BeginSyncSkill(Int32 x, AsyncCallback callback, object state);
        void EndSyncSkill(IAsyncResult asyncResult);

        void RequestNPCInfo(Int32 x);
        IAsyncResult BeginRequestNPCInfo(Int32 x, AsyncCallback callback, object state);
        void EndRequestNPCInfo(IAsyncResult asyncResult);

        void RequestNPCTarget(long x);
        IAsyncResult BeginRequestNPCTarget(long x, AsyncCallback callback, object state);
        void EndRequestNPCTarget(IAsyncResult asyncResult);

        void NPCDamaged(long id, Int32 amnt);
        IAsyncResult BeginNPCDamaged(long id, Int32 amnt, AsyncCallback callback, object state);
        void EndNPCDamaged(IAsyncResult asyncResult);
    }
}
