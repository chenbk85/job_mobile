﻿/* Project : M3 network library
* Author : Sung Ho Kim
* Date : 07/24/2012
* Brief : Test Client program
* Usage : SampleClient
*/
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace M3
{
    public class SampleClient
    {
        private const int udpPort = 4568;
        private const int tcpPort = 13000;

        public SampleClient()
        {
        }

        public void TestClient(String serverName)
        {
            try
            {
                UdpClientHelper<ISampleService> helper = new UdpClientHelper<ISampleService>();
                TcpClientHelper<ISampleService> helper2 = new TcpClientHelper<ISampleService>();

                helper2.Start(serverName, tcpPort);
                helper2.GetPublishedMethods();

                helper.Start(serverName, udpPort, 1000);

                int counter = 0;
                while (true)
                {
                    Console.WriteLine("Enter number to test:");
                    int x = Int32.Parse(Console.ReadLine());

                    bool isPrime;
                    if (counter++ % 2 == 0)
                    {
                        Console.WriteLine(" Asking server if " + x + " is prime...");
                        isPrime = helper.service.TestPrime(x);
                    }
                    else
                    {
                        Console.WriteLine(" Asking server if " + x + " is prime, using an async query...");
                        IAsyncResult asyncResult = helper.service.BeginTestPrime(x, null, null);
                        Console.WriteLine(" Doing some other stuff while the server is calculating...");
                        isPrime = helper.service.EndTestPrime(asyncResult);
                    }

                    if (isPrime)
                        Console.WriteLine(" Server says: Prime!");
                    else
                        Console.WriteLine(" Server says: Not prime!");

                    helper.service.SyncAni("HELLO");
                    helper.service.SyncSkill(32);
                    helper.service.RequestNPCTarget(100L);
                    helper.service.RequestNPCInfo(45);
                    helper.service.NPCDamaged(200L, 100);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("An Exception Occurred!");
                Console.WriteLine(e.ToString());
            }
        }

        public static void Main(String[] argv)
        {
            String serverName = "localhost";
            if (argv.Length > 0)
            {
                Console.WriteLine("Usage: SampleClient <Server Name or IP Address>");
                Console.WriteLine("Example: SampleClient localhost");
                serverName = argv[0];
            }
            SampleClient suc = new SampleClient();
            suc.TestClient(serverName);
            Console.WriteLine("The client is disconnected.");
        }
    }
}
// created on 8/26/2001 at 1:21 PM