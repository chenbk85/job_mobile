﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using ProtoBufRemote;

namespace M3Server
{
    public class TcpServer<T> where T : class
    {
        private const Int32 tcpPort = 13000;

        public void WorkThreadFunction(T cls)
        {
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");

            TcpListener tcpListener = new TcpListener(localAddr, tcpPort);
            tcpListener.Start();

            TcpClient tcpClient = tcpListener.AcceptTcpClient();

            var controller = new RpcController();
            var server = new RpcServer(controller);

            //server.RegisterService<ISampleService>(new SampleService());
            server.RegisterService<T>(cls);

            var channel = new NetworkStreamRpcChannel(controller, tcpClient.GetStream());
            channel.Start();

            while (tcpClient.Connected)
                System.Threading.Thread.Sleep(1000);

            channel.CloseAndJoin();
        }
    }
}
