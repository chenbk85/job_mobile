﻿/* Project : M3 network library
* Author : Sung Ho Kim
* Date : 07/24/2012
* Brief : Test UDP Server program
* Usage : TcpUdpServer
*/
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using ProtoBufRemote;

namespace M3Server
{
    public class UdpServer<T> where T : class
    {
        private const int udpPort = 4568;

        public void WorkThreadFunction(T cls)
        {
            try
            {
                IPEndPoint localIpEndPoint = new IPEndPoint(IPAddress.Any, udpPort);
                UdpClient udpServer = new UdpClient();
                udpServer.ExclusiveAddressUse = false;
                udpServer.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udpServer.Client.Bind(localIpEndPoint);
                Console.WriteLine("Server bind to 0.0.0.0:{0}", udpPort);

                var controller = new RpcController();
                var server = new RpcServer(controller);

                //server.RegisterService<ISampleService>(new SampleService());
                server.RegisterService<T>(cls);

                IPEndPoint tmpIpEndPoint = new IPEndPoint(IPAddress.Any, udpPort);

                var channel = new UdpRpcChannel(controller, udpServer, tmpIpEndPoint);
                channel.Start();

                int tmp = udpServer.Available;
                while (tmp >= 0)
                {
                    tmp = udpServer.Available;
                }

                channel.CloseAndJoin();

                Console.WriteLine("Connection closed.\n");
            }
            catch (SocketException se)
            {
                Console.WriteLine("A Socket Exception has occurred!" + se.ToString());
            }
        }
    }
}