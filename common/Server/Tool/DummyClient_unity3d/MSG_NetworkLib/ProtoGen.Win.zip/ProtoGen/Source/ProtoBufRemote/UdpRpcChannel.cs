﻿using System.Net;
using System.Net.Sockets;

namespace ProtoBufRemote
{
    /// <summary>
    /// Trivial subclass of DatagramRpcChannel, uses the given byte[] arrays for reading and writing.
    /// </summary>
    public class UdpRpcChannel : DatagramRpcChannel
    {
        public UdpRpcChannel(RpcController controller, UdpClient client, IPEndPoint ep)
            : base(controller, client, ep)
        {
        }
    }
}
