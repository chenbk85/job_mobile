﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace M3Server
{
    class SampleServer
    {
        public static Thread tcpthread, udpthread;

        public static void Main(String[] argv)
        {
            TcpServer<ISampleService> tcpServ = new TcpServer<ISampleService>();
            UdpServer<ISampleService> udpServ = new UdpServer<ISampleService>();

            try
            {
                SampleService ss = new SampleService();
                tcpthread = new Thread(o => { tcpServ.WorkThreadFunction(ss); });
                tcpthread.Start(ss);
                udpthread = new Thread(o => { udpServ.WorkThreadFunction(ss); });
                udpthread.Start(ss);
            }
            catch (Exception e)
            {
                Console.WriteLine("An Exception has occurred!" + e.ToString());
                tcpthread.Abort();
                udpthread.Abort();
            }
        }
    }
}
