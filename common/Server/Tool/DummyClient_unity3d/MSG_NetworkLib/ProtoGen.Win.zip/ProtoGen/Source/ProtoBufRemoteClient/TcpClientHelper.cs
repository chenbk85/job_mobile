﻿/* Project : M3 network library
* Author : Sung Ho Kim
* Date : 07/24/2012
* Brief : TCP Client helper class
* Usage : TcpClientHelper
*/
using System;
using System.Net;
using System.Net.Sockets;
using ProtoBufRemote;

namespace M3
{
    // User class to connect, send using ProtoBufRemote library
    public class TcpClientHelper<T> where T : class
    {
        private TcpClient client;
        public T service;

        public TcpClientHelper()
        {
            //Create an instance of UdpClient.
            this.client = new TcpClient();
        }

        ~TcpClientHelper()  // destructor
        {
            // cleanup
            this.client.Close();
            this.client = null;
        }

        public void Start(String serverName, int tcpPort, int timeOut = 0)
        {
            try
            {
                this.client.Connect(serverName, tcpPort);
                var controller = new RpcController();
                var rpcclient = new RpcClient(controller);

                var channel = new NetworkStreamRpcChannel(controller, this.client.GetStream());
                channel.Start();

                this.service = rpcclient.GetProxy<T>();
            }
            catch (Exception e)
            {
                Console.WriteLine("An Exception Occurred!");
                Console.WriteLine(e.ToString());
            }
        }

        // crude introspection mechanism to query server for published methods
        // should return a list of { methodName, methodVersion, methodParameters }
        // due to the possible large size of the return data and need for reliably receiving
        // this data, we should receive this via TCP and not UDP
        // sk68: 7/25/2012 Update:  creating interface stubs at runtime might violate
        //                          AppStore policy regarding dynamic code generation.
        //                          Keep static client-server stub for the time being.
        public void GetPublishedMethods(int version = 0) { }

        public void Send() { }

        protected void setTimeout(int milliseconds)
        {
            int sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout);
            Console.WriteLine("Default SendTimeout: {0}", sockopt);
            this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, milliseconds);
            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout);
            Console.WriteLine("New SendTimeout: {0}", sockopt);

            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout);
            Console.WriteLine("Default ReceiveTimeout: {0}", sockopt);
            this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, milliseconds);
            sockopt = (int)this.client.Client.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout);
            Console.WriteLine("New ReceiveTimeout: {0}", sockopt);
        }

    }

}
