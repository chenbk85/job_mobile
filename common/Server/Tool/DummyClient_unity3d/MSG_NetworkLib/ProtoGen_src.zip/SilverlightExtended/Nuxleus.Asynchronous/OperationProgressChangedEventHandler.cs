﻿using System;

namespace SilverlightExtended {
    public delegate void OperationProgressChangedEventHandler(AsyncProtoBufOperation sender, OperationProgressChangedEventArgs e);
}
