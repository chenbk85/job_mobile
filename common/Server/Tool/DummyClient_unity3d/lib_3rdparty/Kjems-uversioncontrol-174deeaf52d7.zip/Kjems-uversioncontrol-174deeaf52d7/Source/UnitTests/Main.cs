namespace VersionControl.UnitTests
{
    public class UnitTests
    {
        public static void Main(string[] args)
        {
        }
    }
}