﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UnityVersionControl")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Playdead")]
[assembly: AssemblyProduct("UnityVersionControl")]
[assembly: AssemblyCopyright("Copyright Playdead©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: InternalsVisibleTo("RendererInspectors")]
[assembly: ComVisible(false)]
[assembly: Guid("9f6b00d4-77aa-4bd6-890b-d357fa49f5fe")]

[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("1.1.0.0")]
