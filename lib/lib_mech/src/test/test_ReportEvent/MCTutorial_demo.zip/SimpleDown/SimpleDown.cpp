// SimpleDown.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Messages.h"
#include "utilities.h"


int _tmain(int argc, TCHAR* argv[])
{
	// Retrieve current user name
	TCHAR szUserName[ 128 ];
	DWORD cchUserName = 128;
	GetUserName( szUserName, &cchUserName );

	TCHAR szBuffer[ 512 ];	
	DWORD cchBuffer = 512;


// Part 1: Using FormatMessage() to retrieve message resources


	// Load first message
	util::LoadMessage( IDS_HELLO, szBuffer, cchBuffer);
	_tprintf( szBuffer );
	
	// Load second message with insertion parameter
	util::LoadMessage( IDS_GREETING, szBuffer, cchBuffer, szUserName );
	_tprintf( szBuffer );

	// Change threads locale explicitly to English 
	SetThreadLocale( MAKELCID( MAKELANGID( 0x0409, SUBLANG_NEUTRAL ), SORT_DEFAULT ) );
	util::LoadMessage( IDS_GREETING, szBuffer, cchBuffer, szUserName );
	_tprintf( szBuffer );

	// Change threads locale to explicitly to German
	SetThreadLocale( MAKELCID( MAKELANGID( 0x0407, SUBLANG_NEUTRAL ), SORT_DEFAULT ) );
	util::LoadMessage( IDS_GREETING, szBuffer, cchBuffer, szUserName );
	_tprintf( szBuffer );


// Part 2: Working with the NT eventlog
	
	// Install our event source into the registry. 
	// This would fail if the calling user does not have admin privs. 
	// In a real project it is best to do this in your setup.
	util::AddEventSource( _T("SimpleDown"), 2 );
	

	
	// Open the eventlog
	HANDLE hEventLog = RegisterEventSource( NULL, _T("SimpleDown") );

	// Log an event
	BOOL bSuccess = ReportEvent(
		hEventLog,					// Handle to the eventlog
		EVENTLOG_WARNING_TYPE,		// Type of event
		CATEGORY_ONE,				// Category (could also be 0)
		EVENT_BACKUP,				// Event id
		NULL,						// User's sid (NULL for none)
		0,							// Number of insertion strings
		0,							// Number of additional bytes
		NULL,						// Array of insertion strings
		NULL						// Pointer to additional bytes
	);

	// And another one
	PCTSTR aInsertions[] = { argv[0], szUserName};
	bSuccess = ReportEvent(
		hEventLog,					// Handle to the eventlog
		EVENTLOG_INFORMATION_TYPE,	// Type of event
		CATEGORY_TWO,				// Category (could also be 0)
		EVENT_STARTED_BY,			// Event id
		NULL,						// User's sid (NULL for none)
		2,							// Number of insertion strings
		0,							// Number of additional bytes
		aInsertions,				// Array of insertion strings
		NULL						// Pointer to additional bytes
	);


	// Close eventlog
	DeregisterEventSource( hEventLog );


	// Uninstall our event source from the registry. However, afterwards the event ids are no
	// longer availabe, so you should do this only during deinstallation of your product

	// util::RemoveEventSource( _T("SimpleDown") );


	return 0;
}
