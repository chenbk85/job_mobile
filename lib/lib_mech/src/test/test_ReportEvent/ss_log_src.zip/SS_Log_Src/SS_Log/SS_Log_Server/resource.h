//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SS_Log_Server.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SS_LOGTYPE                  129
#define IDD_FILTERSETTINGS              130
#define IDC_STATUS                      1000
#define IDC_CHECK1                      1001
#define IDC_TEXTINMSG_CHECK             1001
#define IDC_TEXTINMSG_EDIT              1002
#define IDC_FILENAME_CHECK              1003
#define IDC_FILENAME_EDIT               1004
#define IDC_ID_CHECK                    1005
#define IDC_ID_EDIT1                    1006
#define IDC_ID_EDIT2                    1007
#define IDC_VERTICAL_BAR                1008
#define IDC_APPLY                       1009
#define IDC_REQ_ALL_FILTERS_RADIO       1010
#define IDC_REQ_ONE_FILTER_RADIO        1011
#define IDC_FILTERS_GROUP               1012
#define IDC_AUTO_APPLY_CHECK            1013
#define IDC_SEARCH_FILTERS_GROUP        1014
#define ID_EDIT_FILTERSETTINGS          32773
#define ID_VIEW_REFRESH                 32774
#define ID_EDIT_LISTVIEW_FILTER         32775
#define IDS_ADDIN_DESCRIPTION           41446
#define IDS_INSTALL_SS_LOG_ADDIN_PROMPT 41447

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
