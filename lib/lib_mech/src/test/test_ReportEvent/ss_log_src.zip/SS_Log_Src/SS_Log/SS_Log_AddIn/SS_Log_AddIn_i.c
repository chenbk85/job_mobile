
#pragma warning( disable: 4049 )  /* more than 64k source lines */
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */
#pragma warning( disable: 4211 )  /* redefine extent to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 6.00.0359 */
/* at Wed Mar 12 12:47:01 2003
 */
/* Compiler settings for C:\VCProjects\SS_Log on CodeProject\SS_Log\SS_Log_AddIn\SS_Log_AddIn.odl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)

#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_SS_Log_AddIn,0xFA62656D,0xB129,0x4479,0xB9,0xB8,0x35,0xD5,0x6F,0x80,0x05,0x8D);


MIDL_DEFINE_GUID(IID, IID_ICommands,0xBA3F3B08,0x7605,0x43C2,0x82,0x99,0xEF,0xAF,0x97,0x7E,0xBC,0xC0);


MIDL_DEFINE_GUID(CLSID, CLSID_Commands,0x2546CC08,0x5803,0x471C,0x88,0x25,0x6D,0x6E,0xB0,0x71,0xFC,0xD7);


MIDL_DEFINE_GUID(CLSID, CLSID_ApplicationEvents,0x9314F28B,0x5EB6,0x450E,0x96,0x0F,0x27,0x99,0x65,0x34,0xAE,0xE0);


MIDL_DEFINE_GUID(CLSID, CLSID_DebuggerEvents,0xF7119C0F,0x1D34,0x442D,0xA0,0xCE,0x01,0xFB,0xA7,0xC9,0xA1,0x5F);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/

