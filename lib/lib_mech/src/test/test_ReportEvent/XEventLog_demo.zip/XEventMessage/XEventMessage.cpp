// XEventMessage.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "XEventMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXEventMessageApp

BEGIN_MESSAGE_MAP(CXEventMessageApp, CWinApp)
	//{{AFX_MSG_MAP(CXEventMessageApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXEventMessageApp construction

CXEventMessageApp::CXEventMessageApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CXEventMessageApp object

CXEventMessageApp theApp;
