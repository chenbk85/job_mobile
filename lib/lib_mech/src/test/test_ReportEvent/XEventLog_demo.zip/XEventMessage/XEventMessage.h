// XEventMessage.h : main header file for the XEVENTMESSAGE DLL
//

#ifndef XEVENTMESSAGE_H
#define XEVENTMESSAGE_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXEventMessageApp
// See XEventMessage.cpp for the implementation of this class
//

class CXEventMessageApp : public CWinApp
{
public:
	CXEventMessageApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXEventMessageApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CXEventMessageApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //XEVENTMESSAGE_H
