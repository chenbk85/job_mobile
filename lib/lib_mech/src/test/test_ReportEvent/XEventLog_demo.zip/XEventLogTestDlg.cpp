// XEventLogTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "XEventLogTest.h"
#include "XEventLogTestDlg.h"
#include "about.h"
#include "io.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXEventLogTestDlg dialog

CXEventLogTestDlg::CXEventLogTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CXEventLogTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CXEventLogTestDlg)
	m_strText = _T("This is a sample string");
	m_nType = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	CString str;
	str.LoadString(AFX_IDS_APP_TITLE);
	m_pEventLog = new CXEventLog(str);
	ASSERT(m_pEventLog);
}

CXEventLogTestDlg::~CXEventLogTestDlg()
{
	if (m_pEventLog)
		delete m_pEventLog;
}

void CXEventLogTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CXEventLogTestDlg)
	DDX_Control(pDX, IDC_STRING, m_Edit);
	DDX_Control(pDX, IDC_LIST, m_List);
	DDX_Text(pDX, IDC_STRING, m_strText);
	DDX_Radio(pDX, IDC_TYPE_INFORMATION, m_nType);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CXEventLogTestDlg, CDialog)
	//{{AFX_MSG_MAP(CXEventLogTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_WRITE_LOG, OnWriteLog)
	ON_BN_CLICKED(IDC_TYPE_ERROR, OnType)
	ON_BN_CLICKED(IDC_TYPE_INFORMATION, OnType)
	ON_BN_CLICKED(IDC_TYPE_WARNING, OnType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXEventLogTestDlg message handlers

BOOL CXEventLogTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		pSysMenu->DeleteMenu(SC_MAXIMIZE, MF_BYCOMMAND);
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
#if 0  // -----------------------------------------------------------
	// this shows how to construct a local CXEventLog object
	CXEventLog el;
	el.Init(_T("myapp"));
	el.Write(EVENTLOG_ERROR_TYPE, _T("This is a sample error."));

	// this can also be done like this:
	CXEventLog el2(_T("myapp2"));
	el2.Write(EVENTLOG_ERROR_TYPE, _T("This is sample error 2."));
#endif // -----------------------------------------------------------

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CXEventLogTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CXEventLogTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CXEventLogTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CXEventLogTestDlg::OnWriteLog() 
{
	UpdateData(TRUE);

	TCHAR szPathName[_MAX_PATH*2];

	szPathName[0] = _T('\0');
	::GetModuleFileName(NULL, szPathName, MAX_PATH*2-2);

	TCHAR *cp = _tcsrchr(szPathName, _T('\\'));
	if (cp != NULL)
		*cp = _T('\0');

	_tcscat(szPathName, _T("\\XEventMessage.dll"));

	if (_taccess(szPathName, 0) == -1)
		AfxMessageBox(_T("XEventMessage.dll is not available.\r\n\r\n")
					  _T("Please copy XEventMessage.dll to the\r\n")
					  _T("exe's directory, or the Event Viewer will \r\n")
					  _T("put garbage in the Description box.") );

	if (m_strText.IsEmpty())
	{
		AfxMessageBox(_T("Please enter a text string."));
		m_Edit.SetFocus();
		return;
	}

	m_List.AddString(m_strText);

	WORD wType = EVENTLOG_INFORMATION_TYPE;

	switch (m_nType)
	{
		case 0: wType = EVENTLOG_INFORMATION_TYPE; break;
		case 1: wType = EVENTLOG_WARNING_TYPE; break;
		case 2: wType = EVENTLOG_ERROR_TYPE; break;
	}

	m_pEventLog->Write(wType, m_strText);


	// This is example of formatted multi-line output

	DWORD dwThreadId = 0xDEADBEEF;
	CString str;
	str.Format(_T("Thread=%08X\r\n")
			   _T("Error=%s\r\n")
			   _T("Cause=%s"),
			   dwThreadId, _T("Can't delete file"), _T("File does not exist"));
	m_pEventLog->Write(EVENTLOG_ERROR_TYPE, str);

}

void CXEventLogTestDlg::OnType() 
{
	UpdateData(TRUE);
}
