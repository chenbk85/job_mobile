// XEventLogTest.h : main header file for the XEventLogTEST application

#ifndef XEVENTLOGTEST_H
#define XEVENTLOGTEST_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXEventLogTestApp:
// See XEventLogTest.cpp for the implementation of this class
//

class CXEventLogTestApp : public CWinApp
{
public:
	CXEventLogTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXEventLogTestApp)
public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXEventLogTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //XEVENTLOGTEST_H
