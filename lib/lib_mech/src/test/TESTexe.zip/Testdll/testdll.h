/* file : testdll.h
Coder : by jjuiddong ( jjuiddong@nate.com)
Date : 2011-08-01 19:49:55
comp.: neovian.co.kr
title : 
desc : 

*/

#ifndef __testdll_header__
#define __testdll_header__
#pragma once
#include <windows.h>
#include <wchar.h>
struct Ia
{
	virtual void func(WCHAR* A)=0;
	virtual WCHAR* get(int a)=0;
};



#endif // __testdll_header__
