
void make_Insert_table(WCHAR* szSQL, nAQ::Use_F_Transport* p )
{

jw_sprintf(szSQL, L"INSERT INTO Use_F_Transport ( \
uid\
,fuid\
,movetown\
,finish_time\
) VALUES ( \
%I64d,\
%I64d,\
%I64d,\
%d-%d-%d %d:%d:%d)"
,p->Get_uid().m_db_id
,p->Get_fuid().m_db_id
,p->Get_movetown().m_db_id
,p->Get_finish_time() 
);

}