
SELECT \
uid , \
name , \
pwd , \
nic_name , \
last_login_time , \
last_logout_time , \
joined_world , \
capital_tuid , \
faim , \
bad_faim , \
cash_money FROM Use_User

