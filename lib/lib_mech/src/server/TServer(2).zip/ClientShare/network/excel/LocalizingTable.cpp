/*------------------------------------------------------------
Create By Z:\bin_sam\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Dec 22 18:08:12 2009

command line : 
Excel_Converter.exe Z:\src_sam\share\network\excel\aq_monster.txt Z:\src_sam\share\network\excel\aq_table.txt Z:\src_sam\share\network\excel\aq_user.txt Z:\src_sam\share\network\excel\ServerResult.txt Z:\src_sam\share\network\excel\ClientResult.txt Z:\src_sam\share\network\excel\LocalizingTable.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "LocalizingTable.h"


for_each_nLocal_LocalizingTable_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nLocal {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ETextCategory[] = 
{
	{ 5 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nLocal_ETextCategory_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	uint16 Sys_LocalizingText::Get_id()	{		return (uint16)m_id_i16;}
	void Sys_LocalizingText::Set_id(uint16 v)
	{
		m_id_i16=v;
	}

	ETextCategory Sys_LocalizingText::Get_category()	{		return (ETextCategory)m_category_e;}
	void Sys_LocalizingText::Set_category(ETextCategory v)
	{
		if(v<eBEGIN_ETextCategory || v>=eEND_ETextCategory)
		{
			GetjILog()->Error(_T("Sys_LocalizingText::Set_category(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_ETextCategory,eEND_ETextCategory,v);
		}
		m_category_e=v;
	}

	tcstr Sys_LocalizingText::Get_name()	{		return (tcstr)m_name_t256;}
	void Sys_LocalizingText::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingText::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t256 , v, 256);
	}

	wcstr Sys_LocalizingText::Get_name_kor()	{		return (wcstr)m_name_kor_w256;}
	void Sys_LocalizingText::Set_name_kor(wcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingText::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_w256 , v, 256);
	}

	wcstr Sys_LocalizingText::Get_name_loc()	{		return (wcstr)m_name_loc_w256;}
	void Sys_LocalizingText::Set_name_loc(wcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingText::Set_name_loc( val = NULL )");}
		nTR_net::jSetter(m_name_loc_w256 , v, 256);
	}

	uint16 Sys_LocalizingWord::Get_id()	{		return (uint16)m_id_i16;}
	void Sys_LocalizingWord::Set_id(uint16 v)
	{
		m_id_i16=v;
	}

	tcstr Sys_LocalizingWord::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_LocalizingWord::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingWord::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	wcstr Sys_LocalizingWord::Get_name_kor()	{		return (wcstr)m_name_kor_w32;}
	void Sys_LocalizingWord::Set_name_kor(wcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingWord::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_w32 , v, 32);
	}

	wcstr Sys_LocalizingWord::Get_name_loc()	{		return (wcstr)m_name_loc_w32;}
	void Sys_LocalizingWord::Set_name_loc(wcstr v)
	{
		if(!v){ throw _T("Sys_LocalizingWord::Set_name_loc( val = NULL )");}
		nTR_net::jSetter(m_name_loc_w32 , v, 32);
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_LocalizingText> g_Sys_LocalizingText;


void Sys_LocalizingText::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_id(nTR_net::StringToVal<uint16>(out[0]));
	Set_category(nTR_net::StringToVal(out[1],nLocal::eBEGIN_ETextCategory));
	Set_name(nUNI::scb1024_t(out[2]).getT());
	Set_name_kor(nUNI::scb1024_t(out[3]).getW());
	Set_name_loc(nUNI::scb1024_t(out[4]).getW());
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_LocalizingWord> g_Sys_LocalizingWord;


void Sys_LocalizingWord::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_id(nTR_net::StringToVal<uint16>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_name_kor(nUNI::scb1024_t(out[2]).getW());
	Set_name_loc(nUNI::scb1024_t(out[3]).getW());
}

void Sys_LocalizingText::jDebugPrint()
{
	for_each_nLocal_Sys_LocalizingText_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_LocalizingWord::jDebugPrint()
{
	for_each_nLocal_Sys_LocalizingWord_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


} //namespace nLocal 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nLocal;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nLocal::Sys_LocalizingText> Sys_LocalizingText_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_LocalizingText_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nLocal::Sys_LocalizingWord> Sys_LocalizingWord_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_LocalizingWord_csv_file_t);

	namespace nTR_excel { namespace nLocal
	{
		jSQ_REGIST_BIND(nTR_excel_nLocal_LocalizingTable)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nLocal_LocalizingTable_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nLocal_ETextCategory_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_LocalizingText_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_LocalizingText*(int index)","array operator")
				jSQ_fn(find,"Sys_LocalizingText*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_LocalizingText)
			for_each_nLocal_Sys_LocalizingText_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_LocalizingText)
			jSQ_end();
			jSQ_g_var(&g_Sys_LocalizingText,g_Sys_LocalizingText);

			jSQ_Interface(Sys_LocalizingWord_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_LocalizingWord*(int index)","array operator")
				jSQ_fn(find,"Sys_LocalizingWord*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_LocalizingWord)
			for_each_nLocal_Sys_LocalizingWord_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_LocalizingWord)
			jSQ_end();
			jSQ_g_var(&g_Sys_LocalizingWord,g_Sys_LocalizingWord);

		}
	} /*namespace nLocal */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

