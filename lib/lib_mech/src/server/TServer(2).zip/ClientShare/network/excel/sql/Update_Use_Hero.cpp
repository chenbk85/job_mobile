
void make_update_table(WCHAR*szSQL , nAQ::Use_Hero* p)
{
jw_sprintf(szSQL, L"UPDATE Use_Hero SET\
[hsid]=%d \
,[uid]=%I64d \
,[tuid]=%I64d \
,[exp_domestic]=%d \
,[exp_combat]=%d \
,[exp_total]=%d \
,[level]=%d \
,[work_state]=%d \
,[slot_horse]=%d \
,[slot_weapon]=%d \
,[slot_armor]=%d \
,[slot_accessory1]=%d \
,[slot_accessory2]=%d \
 WHERE [huid]=%I64d "
	,p->Get_hsid()
	,p->Get_uid()
	,p->Get_tuid()
	,p->Get_exp_domestic()
	,p->Get_exp_combat()
	,p->Get_exp_total()
	,p->Get_level()
	,p->Get_work_state()
	,p->Get_slot_horse()
	,p->Get_slot_weapon()
	,p->Get_slot_armor()
	,p->Get_slot_accessory1()
	,p->Get_slot_accessory2()
	,p->Get_huid().m_db_id
);

}


/*
	@huid	BIGINT
	,@hsid	SMALLINT
	,@uid	BIGINT
	,@tuid	BIGINT
	,@exp_domestic	INT
	,@exp_combat	INT
	,@exp_total	INT
	,@level	INT
	,@work_state	TINYINT
	,@slot_horse	INT
	,@slot_weapon	INT
	,@slot_armor	INT
	,@slot_accessory1	INT
	,@slot_accessory2	INT
*/