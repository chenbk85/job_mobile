/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Wed Jan 13 13:37:25 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\aq_table.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "aq_table.h"


for_each_nAQ_aq_table_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EAttackType[] = 
{
	{ 6 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EAttackType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EAvatarParts[] = 
{
	{ 24 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EAvatarParts_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EAvatarSubclass[] = 
{
	{ 10 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EAvatarSubclass_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EDamageType[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EDamageType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EItemBind[] = 
{
	{ 3 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EItemBind_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EItemClass[] = 
{
	{ 8 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EItemClass_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EItemGrade[] = 
{
	{ 7 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EItemGrade_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EItemQuality[] = 
{
	{ 6 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EItemQuality_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EItemSubclass[] = 
{
	{ 33 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EItemSubclass_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EMechanic[] = 
{
	{ 8 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EMechanic_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EModifier[] = 
{
	{ 29 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EModifier_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EModValueType[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EModValueType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ESkillCastType[] = 
{
	{ 5 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_ESkillCastType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ESkillType[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_ESkillType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ETarget[] = 
{
	{ 5 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_ETarget_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	uint32 Sys_Avatar::Get_asid()	{		return (uint32)m_asid_u32;}
	void Sys_Avatar::Set_asid(uint32 v)
	{
		m_asid_u32=v;
	}

	tcstr Sys_Avatar::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Avatar::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Avatar::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	EAvatarClass Sys_Avatar::Get_baseclass()	{		return (EAvatarClass)m_baseclass_e;}
	void Sys_Avatar::Set_baseclass(EAvatarClass v)
	{
		if(v<eBEGIN_EAvatarClass || v>=eEND_EAvatarClass)
		{
			GetjILog()->Error(_T("Sys_Avatar::Set_baseclass(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAvatarClass,eEND_EAvatarClass,v);
		}
		m_baseclass_e=v;
	}

	EAvatarSubclass Sys_Avatar::Get_subclass()	{		return (EAvatarSubclass)m_subclass_e;}
	void Sys_Avatar::Set_subclass(EAvatarSubclass v)
	{
		if(v<eBEGIN_EAvatarSubclass || v>=eEND_EAvatarSubclass)
		{
			GetjILog()->Error(_T("Sys_Avatar::Set_subclass(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAvatarSubclass,eEND_EAvatarSubclass,v);
		}
		m_subclass_e=v;
	}

	int32 Sys_Avatar::Get_hp_max()	{		return (int32)m_hp_max_i32;}
	void Sys_Avatar::Set_hp_max(int32 v)
	{
		if(v<0) v = 0;
		m_hp_max_i32=v;
	}

	int32 Sys_Avatar::Get_mp_max()	{		return (int32)m_mp_max_i32;}
	void Sys_Avatar::Set_mp_max(int32 v)
	{
		if(v<0) v = 0;
		m_mp_max_i32=v;
	}

	int32 Sys_Avatar::Get_hp_regen()	{		return (int32)m_hp_regen_i32;}
	void Sys_Avatar::Set_hp_regen(int32 v)
	{
		m_hp_regen_i32=v;
	}

	int32 Sys_Avatar::Get_mp_regen()	{		return (int32)m_mp_regen_i32;}
	void Sys_Avatar::Set_mp_regen(int32 v)
	{
		m_mp_regen_i32=v;
	}

	int32 Sys_Avatar::Get_st_str()	{		return (int32)m_st_str_i32;}
	void Sys_Avatar::Set_st_str(int32 v)
	{
		if(v<0) v = 0;
		m_st_str_i32=v;
	}

	int32 Sys_Avatar::Get_st_sta()	{		return (int32)m_st_sta_i32;}
	void Sys_Avatar::Set_st_sta(int32 v)
	{
		if(v<0) v = 0;
		m_st_sta_i32=v;
	}

	int32 Sys_Avatar::Get_st_agi()	{		return (int32)m_st_agi_i32;}
	void Sys_Avatar::Set_st_agi(int32 v)
	{
		if(v<0) v = 0;
		m_st_agi_i32=v;
	}

	int32 Sys_Avatar::Get_st_int()	{		return (int32)m_st_int_i32;}
	void Sys_Avatar::Set_st_int(int32 v)
	{
		if(v<0) v = 0;
		m_st_int_i32=v;
	}

	int32 Sys_Avatar::Get_st_men()	{		return (int32)m_st_men_i32;}
	void Sys_Avatar::Set_st_men(int32 v)
	{
		if(v<0) v = 0;
		m_st_men_i32=v;
	}

	int32 Sys_Avatar::Get_reation_aerial_type()	{		return (int32)m_reation_aerial_type_i32;}
	void Sys_Avatar::Set_reation_aerial_type(int32 v)
	{
		m_reation_aerial_type_i32=v;
	}

	int32 Sys_Avatar::Get_reation_blow_type()	{		return (int32)m_reation_blow_type_i32;}
	void Sys_Avatar::Set_reation_blow_type(int32 v)
	{
		m_reation_blow_type_i32=v;
	}

	int32 Sys_Avatar::Get_reation_push_type()	{		return (int32)m_reation_push_type_i32;}
	void Sys_Avatar::Set_reation_push_type(int32 v)
	{
		m_reation_push_type_i32=v;
	}

	int32 Sys_Avatar::Get_physic_atk()	{		return (int32)m_physic_atk_i32;}
	void Sys_Avatar::Set_physic_atk(int32 v)
	{
		m_physic_atk_i32=v;
	}

	int32 Sys_Avatar::Get_physic_def()	{		return (int32)m_physic_def_i32;}
	void Sys_Avatar::Set_physic_def(int32 v)
	{
		m_physic_def_i32=v;
	}

	float Sys_Avatar::Get_physic_crit()	{		return (float)m_physic_crit_f;}
	void Sys_Avatar::Set_physic_crit(float v)
	{
		m_physic_crit_f=v;
	}

	int32 Sys_Avatar::Get_magic_atk()	{		return (int32)m_magic_atk_i32;}
	void Sys_Avatar::Set_magic_atk(int32 v)
	{
		m_magic_atk_i32=v;
	}

	int32 Sys_Avatar::Get_magic_def()	{		return (int32)m_magic_def_i32;}
	void Sys_Avatar::Set_magic_def(int32 v)
	{
		m_magic_def_i32=v;
	}

	float Sys_Avatar::Get_magic_crit()	{		return (float)m_magic_crit_f;}
	void Sys_Avatar::Set_magic_crit(float v)
	{
		m_magic_crit_f=v;
	}

	float Sys_Avatar::Get_attack_speed()	{		return (float)m_attack_speed_f;}
	void Sys_Avatar::Set_attack_speed(float v)
	{
		m_attack_speed_f=v;
	}

	float Sys_Avatar::Get_casting_speed()	{		return (float)m_casting_speed_f;}
	void Sys_Avatar::Set_casting_speed(float v)
	{
		m_casting_speed_f=v;
	}

	float Sys_Avatar::Get_move_speed()	{		return (float)m_move_speed_f;}
	void Sys_Avatar::Set_move_speed(float v)
	{
		m_move_speed_f=v;
	}

	float Sys_Avatar::Get_dash_speed()	{		return (float)m_dash_speed_f;}
	void Sys_Avatar::Set_dash_speed(float v)
	{
		m_dash_speed_f=v;
	}

	float Sys_Avatar::Get_hit_chance()	{		return (float)m_hit_chance_f;}
	void Sys_Avatar::Set_hit_chance(float v)
	{
		m_hit_chance_f=v;
	}

	float Sys_Avatar::Get_avoid_chance()	{		return (float)m_avoid_chance_f;}
	void Sys_Avatar::Set_avoid_chance(float v)
	{
		m_avoid_chance_f=v;
	}

	float Sys_Avatar::Get_jumpFactor()	{		return (float)m_jumpFactor_f;}
	void Sys_Avatar::Set_jumpFactor(float v)
	{
		m_jumpFactor_f=v;
	}

	int32 Sys_Avatar::Get_resist_fire()	{		return (int32)m_resist_fire_i32;}
	void Sys_Avatar::Set_resist_fire(int32 v)
	{
		m_resist_fire_i32=v;
	}

	int32 Sys_Avatar::Get_resist_water()	{		return (int32)m_resist_water_i32;}
	void Sys_Avatar::Set_resist_water(int32 v)
	{
		m_resist_water_i32=v;
	}

	int32 Sys_Avatar::Get_resist_light()	{		return (int32)m_resist_light_i32;}
	void Sys_Avatar::Set_resist_light(int32 v)
	{
		m_resist_light_i32=v;
	}

	int32 Sys_Avatar::Get_resist_dark()	{		return (int32)m_resist_dark_i32;}
	void Sys_Avatar::Set_resist_dark(int32 v)
	{
		m_resist_dark_i32=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo1()	{		return (Sys_Skill_id_t)m_combo1_i16;}
	void Sys_Avatar::Set_combo1(Sys_Skill_id_t v)
	{
		m_combo1_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo2()	{		return (Sys_Skill_id_t)m_combo2_i16;}
	void Sys_Avatar::Set_combo2(Sys_Skill_id_t v)
	{
		m_combo2_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo3()	{		return (Sys_Skill_id_t)m_combo3_i16;}
	void Sys_Avatar::Set_combo3(Sys_Skill_id_t v)
	{
		m_combo3_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo4()	{		return (Sys_Skill_id_t)m_combo4_i16;}
	void Sys_Avatar::Set_combo4(Sys_Skill_id_t v)
	{
		m_combo4_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo5()	{		return (Sys_Skill_id_t)m_combo5_i16;}
	void Sys_Avatar::Set_combo5(Sys_Skill_id_t v)
	{
		m_combo5_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_jump_atk()	{		return (Sys_Skill_id_t)m_jump_atk_i16;}
	void Sys_Avatar::Set_jump_atk(Sys_Skill_id_t v)
	{
		m_jump_atk_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_dash_atk()	{		return (Sys_Skill_id_t)m_dash_atk_i16;}
	void Sys_Avatar::Set_dash_atk(Sys_Skill_id_t v)
	{
		m_dash_atk_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo1_2h()	{		return (Sys_Skill_id_t)m_combo1_2h_i16;}
	void Sys_Avatar::Set_combo1_2h(Sys_Skill_id_t v)
	{
		m_combo1_2h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo2_2h()	{		return (Sys_Skill_id_t)m_combo2_2h_i16;}
	void Sys_Avatar::Set_combo2_2h(Sys_Skill_id_t v)
	{
		m_combo2_2h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo3_3h()	{		return (Sys_Skill_id_t)m_combo3_3h_i16;}
	void Sys_Avatar::Set_combo3_3h(Sys_Skill_id_t v)
	{
		m_combo3_3h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo4_2h()	{		return (Sys_Skill_id_t)m_combo4_2h_i16;}
	void Sys_Avatar::Set_combo4_2h(Sys_Skill_id_t v)
	{
		m_combo4_2h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_combo5_2h()	{		return (Sys_Skill_id_t)m_combo5_2h_i16;}
	void Sys_Avatar::Set_combo5_2h(Sys_Skill_id_t v)
	{
		m_combo5_2h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_jump_atk_2h()	{		return (Sys_Skill_id_t)m_jump_atk_2h_i16;}
	void Sys_Avatar::Set_jump_atk_2h(Sys_Skill_id_t v)
	{
		m_jump_atk_2h_i16=v;
	}

	Sys_Skill_id_t Sys_Avatar::Get_dash_atk_2h()	{		return (Sys_Skill_id_t)m_dash_atk_2h_i16;}
	void Sys_Avatar::Set_dash_atk_2h(Sys_Skill_id_t v)
	{
		m_dash_atk_2h_i16=v;
	}

	tcstr Sys_Avatar::Get_xmlname()	{		return (tcstr)m_xmlname_t32;}
	void Sys_Avatar::Set_xmlname(tcstr v)
	{
		if(!v){ throw _T("Sys_Avatar::Set_xmlname( val = NULL )");}
		nTR_net::jSetter(m_xmlname_t32 , v, 32);
	}

	tcstr Sys_Avatar::Get_fkmname()	{		return (tcstr)m_fkmname_t256;}
	void Sys_Avatar::Set_fkmname(tcstr v)
	{
		if(!v){ throw _T("Sys_Avatar::Set_fkmname( val = NULL )");}
		nTR_net::jSetter(m_fkmname_t256 , v, 256);
	}

	uint32 Sys_Item::Get_isid()	{		return (uint32)m_isid_u32;}
	void Sys_Item::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	tcstr Sys_Item::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Item::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	EItemClass Sys_Item::Get_category()	{		return (EItemClass)m_category_e;}
	void Sys_Item::Set_category(EItemClass v)
	{
		if(v<eBEGIN_EItemClass || v>=eEND_EItemClass)
		{
			GetjILog()->Error(_T("Sys_Item::Set_category(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemClass,eEND_EItemClass,v);
		}
		m_category_e=v;
	}

	EItemSubclass Sys_Item::Get_subcategory()	{		return (EItemSubclass)m_subcategory_e;}
	void Sys_Item::Set_subcategory(EItemSubclass v)
	{
		if(v<eBEGIN_EItemSubclass || v>=eEND_EItemSubclass)
		{
			GetjILog()->Error(_T("Sys_Item::Set_subcategory(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemSubclass,eEND_EItemSubclass,v);
		}
		m_subcategory_e=v;
	}

	EItemGrade Sys_Item::Get_grade()	{		return (EItemGrade)m_grade_e;}
	void Sys_Item::Set_grade(EItemGrade v)
	{
		if(v<eBEGIN_EItemGrade || v>=eEND_EItemGrade)
		{
			GetjILog()->Error(_T("Sys_Item::Set_grade(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemGrade,eEND_EItemGrade,v);
		}
		m_grade_e=v;
	}

	EItemQuality Sys_Item::Get_quality()	{		return (EItemQuality)m_quality_e;}
	void Sys_Item::Set_quality(EItemQuality v)
	{
		if(v<eBEGIN_EItemQuality || v>=eEND_EItemQuality)
		{
			GetjILog()->Error(_T("Sys_Item::Set_quality(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemQuality,eEND_EItemQuality,v);
		}
		m_quality_e=v;
	}

	EItemBind Sys_Item::Get_bind_type()	{		return (EItemBind)m_bind_type_e;}
	void Sys_Item::Set_bind_type(EItemBind v)
	{
		if(v<eBEGIN_EItemBind || v>=eEND_EItemBind)
		{
			GetjILog()->Error(_T("Sys_Item::Set_bind_type(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemBind,eEND_EItemBind,v);
		}
		m_bind_type_e=v;
	}

	EAvatarParts Sys_Item::Get_part()	{		return (EAvatarParts)m_part_e;}
	void Sys_Item::Set_part(EAvatarParts v)
	{
		if(v<eBEGIN_EAvatarParts || v>=eEND_EAvatarParts)
		{
			GetjILog()->Error(_T("Sys_Item::Set_part(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAvatarParts,eEND_EAvatarParts,v);
		}
		m_part_e=v;
	}

	EAvatarClass Sys_Item::Get_reqClass()	{		return (EAvatarClass)m_reqClass_e;}
	void Sys_Item::Set_reqClass(EAvatarClass v)
	{
		if(v<eBEGIN_EAvatarClass || v>=eEND_EAvatarClass)
		{
			GetjILog()->Error(_T("Sys_Item::Set_reqClass(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAvatarClass,eEND_EAvatarClass,v);
		}
		m_reqClass_e=v;
	}

	EAvatarSubclass Sys_Item::Get_reqSubclass()	{		return (EAvatarSubclass)m_reqSubclass_e;}
	void Sys_Item::Set_reqSubclass(EAvatarSubclass v)
	{
		if(v<eBEGIN_EAvatarSubclass || v>=eEND_EAvatarSubclass)
		{
			GetjILog()->Error(_T("Sys_Item::Set_reqSubclass(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAvatarSubclass,eEND_EAvatarSubclass,v);
		}
		m_reqSubclass_e=v;
	}

	int32 Sys_Item::Get_maxCount()	{		return (int32)m_maxCount_i32;}
	void Sys_Item::Set_maxCount(int32 v)
	{
		m_maxCount_i32=v;
	}

	int32 Sys_Item::Get_stackCount()	{		return (int32)m_stackCount_i32;}
	void Sys_Item::Set_stackCount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_stackCount_i32=v;
	}

	int32 Sys_Item::Get_buyPrice()	{		return (int32)m_buyPrice_i32;}
	void Sys_Item::Set_buyPrice(int32 v)
	{
		m_buyPrice_i32=v;
	}

	int32 Sys_Item::Get_sellPrice()	{		return (int32)m_sellPrice_i32;}
	void Sys_Item::Set_sellPrice(int32 v)
	{
		m_sellPrice_i32=v;
	}

	int32 Sys_Item::Get_repairPrice()	{		return (int32)m_repairPrice_i32;}
	void Sys_Item::Set_repairPrice(int32 v)
	{
		m_repairPrice_i32=v;
	}

	int32 Sys_Item::Get_reqCash()	{		return (int32)m_reqCash_i32;}
	void Sys_Item::Set_reqCash(int32 v)
	{
		m_reqCash_i32=v;
	}

	int32 Sys_Item::Get_reqLevel()	{		return (int32)m_reqLevel_i32;}
	void Sys_Item::Set_reqLevel(int32 v)
	{
		if(v>60) v = 60;
		if(v<1) v = 1;
		m_reqLevel_i32=v;
	}

	int32 Sys_Item::Get_durability()	{		return (int32)m_durability_i32;}
	void Sys_Item::Set_durability(int32 v)
	{
		m_durability_i32=v;
	}

	int32 Sys_Item::Get_activeTime()	{		return (int32)m_activeTime_i32;}
	void Sys_Item::Set_activeTime(int32 v)
	{
		m_activeTime_i32=v;
	}

	int32 Sys_Item::Get_trigger_skill()	{		return (int32)m_trigger_skill_i32;}
	void Sys_Item::Set_trigger_skill(int32 v)
	{
		m_trigger_skill_i32=v;
	}

	tcstr Sys_Item::Get_iconname()	{		return (tcstr)m_iconname_t256;}
	void Sys_Item::Set_iconname(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_iconname( val = NULL )");}
		nTR_net::jSetter(m_iconname_t256 , v, 256);
	}

	tcstr Sys_Item::Get_delegate()	{		return (tcstr)m_delegate_t128;}
	void Sys_Item::Set_delegate(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_delegate( val = NULL )");}
		nTR_net::jSetter(m_delegate_t128 , v, 128);
	}

	tcstr Sys_Item::Get_filename()	{		return (tcstr)m_filename_t256;}
	void Sys_Item::Set_filename(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_filename( val = NULL )");}
		nTR_net::jSetter(m_filename_t256 , v, 256);
	}

	tcstr Sys_Item::Get_xmlname()	{		return (tcstr)m_xmlname_t32;}
	void Sys_Item::Set_xmlname(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_xmlname( val = NULL )");}
		nTR_net::jSetter(m_xmlname_t32 , v, 32);
	}

	tcstr Sys_Item::Get_description()	{		return (tcstr)m_description_t32;}
	void Sys_Item::Set_description(tcstr v)
	{
		if(!v){ throw _T("Sys_Item::Set_description( val = NULL )");}
		nTR_net::jSetter(m_description_t32 , v, 32);
	}

	Sys_Skill_id_t Sys_Skill::Get_ssid()	{		return (Sys_Skill_id_t)m_ssid_i16;}
	void Sys_Skill::Set_ssid(Sys_Skill_id_t v)
	{
		m_ssid_i16=v;
	}

	tcstr Sys_Skill::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Skill::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	uint8 Sys_Skill::Get_level()	{		return (uint8)m_level_i8;}
	void Sys_Skill::Set_level(uint8 v)
	{
		m_level_i8=v;
	}

	int32 Sys_Skill::Get_maxLevel()	{		return (int32)m_maxLevel_i32;}
	void Sys_Skill::Set_maxLevel(int32 v)
	{
		m_maxLevel_i32=v;
	}

	int32 Sys_Skill::Get_reqLevel()	{		return (int32)m_reqLevel_i32;}
	void Sys_Skill::Set_reqLevel(int32 v)
	{
		m_reqLevel_i32=v;
	}

	int32 Sys_Skill::Get_reqGold()	{		return (int32)m_reqGold_i32;}
	void Sys_Skill::Set_reqGold(int32 v)
	{
		m_reqGold_i32=v;
	}

	int32 Sys_Skill::Get_reqSP()	{		return (int32)m_reqSP_i32;}
	void Sys_Skill::Set_reqSP(int32 v)
	{
		m_reqSP_i32=v;
	}

	uint32 Sys_Skill::Get_reqItem()	{		return (uint32)m_reqItem_u32;}
	void Sys_Skill::Set_reqItem(uint32 v)
	{
		m_reqItem_u32=v;
	}

	int32 Sys_Skill::Get_costHP()	{		return (int32)m_costHP_i32;}
	void Sys_Skill::Set_costHP(int32 v)
	{
		m_costHP_i32=v;
	}

	int32 Sys_Skill::Get_costMP()	{		return (int32)m_costMP_i32;}
	void Sys_Skill::Set_costMP(int32 v)
	{
		m_costMP_i32=v;
	}

	uint32 Sys_Skill::Get_costItem()	{		return (uint32)m_costItem_u32;}
	void Sys_Skill::Set_costItem(uint32 v)
	{
		m_costItem_u32=v;
	}

	ESkillType Sys_Skill::Get_type()	{		return (ESkillType)m_type_e;}
	void Sys_Skill::Set_type(ESkillType v)
	{
		if(v<eBEGIN_ESkillType || v>=eEND_ESkillType)
		{
			GetjILog()->Error(_T("Sys_Skill::Set_type(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_ESkillType,eEND_ESkillType,v);
		}
		m_type_e=v;
	}

	ESkillCastType Sys_Skill::Get_castingType()	{		return (ESkillCastType)m_castingType_e;}
	void Sys_Skill::Set_castingType(ESkillCastType v)
	{
		if(v<eBEGIN_ESkillCastType || v>=eEND_ESkillCastType)
		{
			GetjILog()->Error(_T("Sys_Skill::Set_castingType(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_ESkillCastType,eEND_ESkillCastType,v);
		}
		m_castingType_e=v;
	}

	int32 Sys_Skill::Get_castingAnim()	{		return (int32)m_castingAnim_i32;}
	void Sys_Skill::Set_castingAnim(int32 v)
	{
		m_castingAnim_i32=v;
	}

	float Sys_Skill::Get_castingTime()	{		return (float)m_castingTime_f;}
	void Sys_Skill::Set_castingTime(float v)
	{
		m_castingTime_f=v;
	}

	float Sys_Skill::Get_chargingTime()	{		return (float)m_chargingTime_f;}
	void Sys_Skill::Set_chargingTime(float v)
	{
		m_chargingTime_f=v;
	}

	float Sys_Skill::Get_chargingMutiplier()	{		return (float)m_chargingMutiplier_f;}
	void Sys_Skill::Set_chargingMutiplier(float v)
	{
		m_chargingMutiplier_f=v;
	}

	float Sys_Skill::Get_coolTime()	{		return (float)m_coolTime_f;}
	void Sys_Skill::Set_coolTime(float v)
	{
		m_coolTime_f=v;
	}

	int32 Sys_Skill::Get_skillAnim()	{		return (int32)m_skillAnim_i32;}
	void Sys_Skill::Set_skillAnim(int32 v)
	{
		m_skillAnim_i32=v;
	}

	ETarget Sys_Skill::Get_target()	{		return (ETarget)m_target_e;}
	void Sys_Skill::Set_target(ETarget v)
	{
		if(v<eBEGIN_ETarget || v>=eEND_ETarget)
		{
			GetjILog()->Error(_T("Sys_Skill::Set_target(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_ETarget,eEND_ETarget,v);
		}
		m_target_e=v;
	}

	EAttackType Sys_Skill::Get_attackType()	{		return (EAttackType)m_attackType_e;}
	void Sys_Skill::Set_attackType(EAttackType v)
	{
		if(v<eBEGIN_EAttackType || v>=eEND_EAttackType)
		{
			GetjILog()->Error(_T("Sys_Skill::Set_attackType(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EAttackType,eEND_EAttackType,v);
		}
		m_attackType_e=v;
	}

	float Sys_Skill::Get_attackRate()	{		return (float)m_attackRate_f;}
	void Sys_Skill::Set_attackRate(float v)
	{
		m_attackRate_f=v;
	}

	float Sys_Skill::Get_hit_chance()	{		return (float)m_hit_chance_f;}
	void Sys_Skill::Set_hit_chance(float v)
	{
		m_hit_chance_f=v;
	}

	float Sys_Skill::Get_critical_chance()	{		return (float)m_critical_chance_f;}
	void Sys_Skill::Set_critical_chance(float v)
	{
		m_critical_chance_f=v;
	}

	float Sys_Skill::Get_effectRange()	{		return (float)m_effectRange_f;}
	void Sys_Skill::Set_effectRange(float v)
	{
		m_effectRange_f=v;
	}

	float Sys_Skill::Get_effectDuration()	{		return (float)m_effectDuration_f;}
	void Sys_Skill::Set_effectDuration(float v)
	{
		m_effectDuration_f=v;
	}

	tcstr Sys_Skill::Get_effect()	{		return (tcstr)m_effect_t32;}
	void Sys_Skill::Set_effect(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_effect( val = NULL )");}
		nTR_net::jSetter(m_effect_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_castingFX()	{		return (tcstr)m_castingFX_t32;}
	void Sys_Skill::Set_castingFX(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_castingFX( val = NULL )");}
		nTR_net::jSetter(m_castingFX_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_skillFX()	{		return (tcstr)m_skillFX_t32;}
	void Sys_Skill::Set_skillFX(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_skillFX( val = NULL )");}
		nTR_net::jSetter(m_skillFX_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_chargingFX()	{		return (tcstr)m_chargingFX_t32;}
	void Sys_Skill::Set_chargingFX(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_chargingFX( val = NULL )");}
		nTR_net::jSetter(m_chargingFX_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_collisionFX()	{		return (tcstr)m_collisionFX_t32;}
	void Sys_Skill::Set_collisionFX(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_collisionFX( val = NULL )");}
		nTR_net::jSetter(m_collisionFX_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_targetFX()	{		return (tcstr)m_targetFX_t32;}
	void Sys_Skill::Set_targetFX(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_targetFX( val = NULL )");}
		nTR_net::jSetter(m_targetFX_t32 , v, 32);
	}

	tcstr Sys_Skill::Get_description()	{		return (tcstr)m_description_t256;}
	void Sys_Skill::Set_description(tcstr v)
	{
		if(!v){ throw _T("Sys_Skill::Set_description( val = NULL )");}
		nTR_net::jSetter(m_description_t256 , v, 256);
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Avatar> g_Sys_Avatar;


void Sys_Avatar::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_asid(nTR_net::StringToVal<Sys_Avatar_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_baseclass(nTR_net::StringToVal(out[2],nAQ::eBEGIN_EAvatarClass));
	Set_subclass(nTR_net::StringToVal(out[3],nAQ::eBEGIN_EAvatarSubclass));
	Set_hp_max(nTR_net::StringToVal<int32>(out[4]));
	Set_mp_max(nTR_net::StringToVal<int32>(out[5]));
	Set_hp_regen(nTR_net::StringToVal<int32>(out[6]));
	Set_mp_regen(nTR_net::StringToVal<int32>(out[7]));
	Set_st_str(nTR_net::StringToVal<int32>(out[8]));
	Set_st_sta(nTR_net::StringToVal<int32>(out[9]));
	Set_st_agi(nTR_net::StringToVal<int32>(out[10]));
	Set_st_int(nTR_net::StringToVal<int32>(out[11]));
	Set_st_men(nTR_net::StringToVal<int32>(out[12]));
	Set_reation_aerial_type(nTR_net::StringToVal<int32>(out[13]));
	Set_reation_blow_type(nTR_net::StringToVal<int32>(out[14]));
	Set_reation_push_type(nTR_net::StringToVal<int32>(out[15]));
	Set_physic_atk(nTR_net::StringToVal<int32>(out[16]));
	Set_physic_def(nTR_net::StringToVal<int32>(out[17]));
	Set_physic_crit(nTR_net::StringToVal<float>(out[18]));
	Set_magic_atk(nTR_net::StringToVal<int32>(out[19]));
	Set_magic_def(nTR_net::StringToVal<int32>(out[20]));
	Set_magic_crit(nTR_net::StringToVal<float>(out[21]));
	Set_attack_speed(nTR_net::StringToVal<float>(out[22]));
	Set_casting_speed(nTR_net::StringToVal<float>(out[23]));
	Set_move_speed(nTR_net::StringToVal<float>(out[24]));
	Set_dash_speed(nTR_net::StringToVal<float>(out[25]));
	Set_hit_chance(nTR_net::StringToVal<float>(out[26]));
	Set_avoid_chance(nTR_net::StringToVal<float>(out[27]));
	Set_jumpFactor(nTR_net::StringToVal<float>(out[28]));
	Set_resist_fire(nTR_net::StringToVal<int32>(out[29]));
	Set_resist_water(nTR_net::StringToVal<int32>(out[30]));
	Set_resist_light(nTR_net::StringToVal<int32>(out[31]));
	Set_resist_dark(nTR_net::StringToVal<int32>(out[32]));
	Set_combo1(nTR_net::StringToVal<Sys_Skill_id_t>(out[33]));
	Set_combo2(nTR_net::StringToVal<Sys_Skill_id_t>(out[34]));
	Set_combo3(nTR_net::StringToVal<Sys_Skill_id_t>(out[35]));
	Set_combo4(nTR_net::StringToVal<Sys_Skill_id_t>(out[36]));
	Set_combo5(nTR_net::StringToVal<Sys_Skill_id_t>(out[37]));
	Set_jump_atk(nTR_net::StringToVal<Sys_Skill_id_t>(out[38]));
	Set_dash_atk(nTR_net::StringToVal<Sys_Skill_id_t>(out[39]));
	Set_combo1_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[40]));
	Set_combo2_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[41]));
	Set_combo3_3h(nTR_net::StringToVal<Sys_Skill_id_t>(out[42]));
	Set_combo4_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[43]));
	Set_combo5_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[44]));
	Set_jump_atk_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[45]));
	Set_dash_atk_2h(nTR_net::StringToVal<Sys_Skill_id_t>(out[46]));
	Set_xmlname(nUNI::scb1024_t(out[47]).getT());
	Set_fkmname(nUNI::scb1024_t(out[48]).getT());
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Item> g_Sys_Item;


void Sys_Item::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_Item_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_category(nTR_net::StringToVal(out[2],nAQ::eBEGIN_EItemClass));
	Set_subcategory(nTR_net::StringToVal(out[3],nAQ::eBEGIN_EItemSubclass));
	Set_grade(nTR_net::StringToVal(out[4],nAQ::eBEGIN_EItemGrade));
	Set_quality(nTR_net::StringToVal(out[5],nAQ::eBEGIN_EItemQuality));
	Set_bind_type(nTR_net::StringToVal(out[6],nAQ::eBEGIN_EItemBind));
	Set_part(nTR_net::StringToVal(out[7],nAQ::eBEGIN_EAvatarParts));
	Set_reqClass(nTR_net::StringToVal(out[8],nAQ::eBEGIN_EAvatarClass));
	Set_reqSubclass(nTR_net::StringToVal(out[9],nAQ::eBEGIN_EAvatarSubclass));
	Set_maxCount(nTR_net::StringToVal<int32>(out[10]));
	Set_stackCount(nTR_net::StringToVal<int32>(out[11]));
	Set_buyPrice(nTR_net::StringToVal<int32>(out[12]));
	Set_sellPrice(nTR_net::StringToVal<int32>(out[13]));
	Set_repairPrice(nTR_net::StringToVal<int32>(out[14]));
	Set_reqCash(nTR_net::StringToVal<int32>(out[15]));
	Set_reqLevel(nTR_net::StringToVal<int32>(out[16]));
	Set_durability(nTR_net::StringToVal<int32>(out[17]));
	Set_activeTime(nTR_net::StringToVal<int32>(out[18]));
	Set_trigger_skill(nTR_net::StringToVal<int32>(out[19]));
	Set_iconname(nUNI::scb1024_t(out[20]).getT());
	Set_delegate(nUNI::scb1024_t(out[21]).getT());
	Set_filename(nUNI::scb1024_t(out[22]).getT());
	Set_xmlname(nUNI::scb1024_t(out[23]).getT());
	Set_description(nUNI::scb1024_t(out[24]).getT());
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Skill> g_Sys_Skill;


void Sys_Skill::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_ssid(nTR_net::StringToVal<Sys_Skill_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_level(nTR_net::StringToVal<skill_level_t>(out[2]));
	Set_maxLevel(nTR_net::StringToVal<int32>(out[3]));
	Set_reqLevel(nTR_net::StringToVal<int32>(out[4]));
	Set_reqGold(nTR_net::StringToVal<int32>(out[5]));
	Set_reqSP(nTR_net::StringToVal<int32>(out[6]));
	Set_reqItem(nTR_net::StringToVal<Sys_Item_id_t>(out[7]));
	Set_costHP(nTR_net::StringToVal<int32>(out[8]));
	Set_costMP(nTR_net::StringToVal<int32>(out[9]));
	Set_costItem(nTR_net::StringToVal<Sys_Item_id_t>(out[10]));
	Set_type(nTR_net::StringToVal(out[11],nAQ::eBEGIN_ESkillType));
	Set_castingType(nTR_net::StringToVal(out[12],nAQ::eBEGIN_ESkillCastType));
	Set_castingAnim(nTR_net::StringToVal<int32>(out[13]));
	Set_castingTime(nTR_net::StringToVal<float>(out[14]));
	Set_chargingTime(nTR_net::StringToVal<float>(out[15]));
	Set_chargingMutiplier(nTR_net::StringToVal<float>(out[16]));
	Set_coolTime(nTR_net::StringToVal<float>(out[17]));
	Set_skillAnim(nTR_net::StringToVal<int32>(out[18]));
	Set_target(nTR_net::StringToVal(out[19],nAQ::eBEGIN_ETarget));
	Set_attackType(nTR_net::StringToVal(out[20],nAQ::eBEGIN_EAttackType));
	Set_attackRate(nTR_net::StringToVal<float>(out[21]));
	Set_hit_chance(nTR_net::StringToVal<float>(out[22]));
	Set_critical_chance(nTR_net::StringToVal<float>(out[23]));
	Set_effectRange(nTR_net::StringToVal<float>(out[24]));
	Set_effectDuration(nTR_net::StringToVal<float>(out[25]));
	Set_effect(nUNI::scb1024_t(out[26]).getT());
	Set_castingFX(nUNI::scb1024_t(out[27]).getT());
	Set_skillFX(nUNI::scb1024_t(out[28]).getT());
	Set_chargingFX(nUNI::scb1024_t(out[29]).getT());
	Set_collisionFX(nUNI::scb1024_t(out[30]).getT());
	Set_targetFX(nUNI::scb1024_t(out[31]).getT());
	Set_description(nUNI::scb1024_t(out[32]).getT());
}

void Sys_Avatar::jDebugPrint()
{
	for_each_nAQ_Sys_Avatar_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_Item::jDebugPrint()
{
	for_each_nAQ_Sys_Item_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_Skill::jDebugPrint()
{
	for_each_nAQ_Sys_Skill_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	db_uid_type_ref Use_Avatar::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Avatar::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	db_uid_type_ref Use_Avatar::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_Avatar::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	uint32 Use_Avatar::Get_asid()	{		return (uint32)m_asid_u32;}
	void Use_Avatar::Set_asid(uint32 v)
	{
		m_asid_u32=v;
	}

	avatar_level_t Use_Avatar::Get_level()	{		return (avatar_level_t)m_level_i8;}
	void Use_Avatar::Set_level(avatar_level_t v)
	{
		m_level_i8=v;
	}

	wcstr Use_Avatar::Get_nic_name()	{		return (wcstr)m_nic_name_w32;}
	void Use_Avatar::Set_nic_name(wcstr v)
	{
		if(!v){ throw _T("Use_Avatar::Set_nic_name( val = NULL )");}
		nTR_net::jSetter(m_nic_name_w32 , v, 32);
	}

	wcstr Use_Avatar::Get_guild()	{		return (wcstr)m_guild_w32;}
	void Use_Avatar::Set_guild(wcstr v)
	{
		if(!v){ throw _T("Use_Avatar::Set_guild( val = NULL )");}
		nTR_net::jSetter(m_guild_w32 , v, 32);
	}

	wcstr Use_Avatar::Get_using_title()	{		return (wcstr)m_using_title_w32;}
	void Use_Avatar::Set_using_title(wcstr v)
	{
		if(!v){ throw _T("Use_Avatar::Set_using_title( val = NULL )");}
		nTR_net::jSetter(m_using_title_w32 , v, 32);
	}

	int32 Use_Avatar::Get_game_gold()	{		return (int32)m_game_gold_i32;}
	void Use_Avatar::Set_game_gold(int32 v)
	{
		m_game_gold_i32=v;
	}

	acstr Use_Avatar::Get_joint_village()	{		return (acstr)m_joint_village_a32;}
	void Use_Avatar::Set_joint_village(acstr v)
	{
		if(!v){ throw _T("Use_Avatar::Set_joint_village( val = NULL )");}
		nTR_net::jSetter(m_joint_village_a32 , v, 32);
	}

	SYSTEMTIME_REF Use_Avatar::Get_last_login_time()	{		return (SYSTEMTIME_REF)m_last_login_time_tm;}
	void Use_Avatar::Set_last_login_time(const SYSTEMTIME_REF v)
	{
		m_last_login_time_tm=v;
	}

	SYSTEMTIME_REF Use_Avatar::Get_last_logout_time()	{		return (SYSTEMTIME_REF)m_last_logout_time_tm;}
	void Use_Avatar::Set_last_logout_time(const SYSTEMTIME_REF v)
	{
		m_last_logout_time_tm=v;
	}

	int16 Use_Avatar::Get_exp_current()	{		return (int16)m_exp_current_i16;}
	void Use_Avatar::Set_exp_current(int16 v)
	{
		m_exp_current_i16=v;
	}

	int16 Use_Avatar::Get_exp_next()	{		return (int16)m_exp_next_i16;}
	void Use_Avatar::Set_exp_next(int16 v)
	{
		m_exp_next_i16=v;
	}

	int16 Use_Avatar::Get_skill_point()	{		return (int16)m_skill_point_i16;}
	void Use_Avatar::Set_skill_point(int16 v)
	{
		m_skill_point_i16=v;
	}

	int16 Use_Avatar::Get_stat_str()	{		return (int16)m_stat_str_i16;}
	void Use_Avatar::Set_stat_str(int16 v)
	{
		m_stat_str_i16=v;
	}

	int16 Use_Avatar::Get_stat_agi()	{		return (int16)m_stat_agi_i16;}
	void Use_Avatar::Set_stat_agi(int16 v)
	{
		m_stat_agi_i16=v;
	}

	int16 Use_Avatar::Get_stat_con()	{		return (int16)m_stat_con_i16;}
	void Use_Avatar::Set_stat_con(int16 v)
	{
		m_stat_con_i16=v;
	}

	int16 Use_Avatar::Get_stat_int()	{		return (int16)m_stat_int_i16;}
	void Use_Avatar::Set_stat_int(int16 v)
	{
		m_stat_int_i16=v;
	}

	int16 Use_Avatar::Get_stat_men()	{		return (int16)m_stat_men_i16;}
	void Use_Avatar::Set_stat_men(int16 v)
	{
		m_stat_men_i16=v;
	}

	int16 Use_Avatar::Get_health()	{		return (int16)m_health_i16;}
	void Use_Avatar::Set_health(int16 v)
	{
		m_health_i16=v;
	}

	int16 Use_Avatar::Get_mana()	{		return (int16)m_mana_i16;}
	void Use_Avatar::Set_mana(int16 v)
	{
		m_mana_i16=v;
	}

	int16 Use_Avatar::Get_hp_regen()	{		return (int16)m_hp_regen_i16;}
	void Use_Avatar::Set_hp_regen(int16 v)
	{
		m_hp_regen_i16=v;
	}

	int16 Use_Avatar::Get_mp_regen()	{		return (int16)m_mp_regen_i16;}
	void Use_Avatar::Set_mp_regen(int16 v)
	{
		m_mp_regen_i16=v;
	}

	int16 Use_Avatar::Get_physic_atk_power()	{		return (int16)m_physic_atk_power_i16;}
	void Use_Avatar::Set_physic_atk_power(int16 v)
	{
		m_physic_atk_power_i16=v;
	}

	int16 Use_Avatar::Get_magic_atk_power()	{		return (int16)m_magic_atk_power_i16;}
	void Use_Avatar::Set_magic_atk_power(int16 v)
	{
		m_magic_atk_power_i16=v;
	}

	int16 Use_Avatar::Get_physic_def_power()	{		return (int16)m_physic_def_power_i16;}
	void Use_Avatar::Set_physic_def_power(int16 v)
	{
		m_physic_def_power_i16=v;
	}

	int16 Use_Avatar::Get_magic_def_power()	{		return (int16)m_magic_def_power_i16;}
	void Use_Avatar::Set_magic_def_power(int16 v)
	{
		m_magic_def_power_i16=v;
	}

	int16 Use_Avatar::Get_physic_critical_chance()	{		return (int16)m_physic_critical_chance_i16;}
	void Use_Avatar::Set_physic_critical_chance(int16 v)
	{
		m_physic_critical_chance_i16=v;
	}

	int16 Use_Avatar::Get_magic_critical_chance()	{		return (int16)m_magic_critical_chance_i16;}
	void Use_Avatar::Set_magic_critical_chance(int16 v)
	{
		m_magic_critical_chance_i16=v;
	}

	int16 Use_Avatar::Get_attack_speed()	{		return (int16)m_attack_speed_i16;}
	void Use_Avatar::Set_attack_speed(int16 v)
	{
		m_attack_speed_i16=v;
	}

	int16 Use_Avatar::Get_casting_speed()	{		return (int16)m_casting_speed_i16;}
	void Use_Avatar::Set_casting_speed(int16 v)
	{
		m_casting_speed_i16=v;
	}

	int16 Use_Avatar::Get_move_speed()	{		return (int16)m_move_speed_i16;}
	void Use_Avatar::Set_move_speed(int16 v)
	{
		m_move_speed_i16=v;
	}

	int16 Use_Avatar::Get_dash_speed()	{		return (int16)m_dash_speed_i16;}
	void Use_Avatar::Set_dash_speed(int16 v)
	{
		m_dash_speed_i16=v;
	}

	int16 Use_Avatar::Get_hit_chance()	{		return (int16)m_hit_chance_i16;}
	void Use_Avatar::Set_hit_chance(int16 v)
	{
		m_hit_chance_i16=v;
	}

	int16 Use_Avatar::Get_avoid_chance()	{		return (int16)m_avoid_chance_i16;}
	void Use_Avatar::Set_avoid_chance(int16 v)
	{
		m_avoid_chance_i16=v;
	}

	int16 Use_Avatar::Get_jump()	{		return (int16)m_jump_i16;}
	void Use_Avatar::Set_jump(int16 v)
	{
		m_jump_i16=v;
	}

	int16 Use_Avatar::Get_resist_fire()	{		return (int16)m_resist_fire_i16;}
	void Use_Avatar::Set_resist_fire(int16 v)
	{
		m_resist_fire_i16=v;
	}

	int16 Use_Avatar::Get_resist_water()	{		return (int16)m_resist_water_i16;}
	void Use_Avatar::Set_resist_water(int16 v)
	{
		m_resist_water_i16=v;
	}

	int16 Use_Avatar::Get_resist_light()	{		return (int16)m_resist_light_i16;}
	void Use_Avatar::Set_resist_light(int16 v)
	{
		m_resist_light_i16=v;
	}

	int16 Use_Avatar::Get_resist_dark()	{		return (int16)m_resist_dark_i16;}
	void Use_Avatar::Set_resist_dark(int16 v)
	{
		m_resist_dark_i16=v;
	}

	int16 Use_Avatar::Get_pk_win()	{		return (int16)m_pk_win_i16;}
	void Use_Avatar::Set_pk_win(int16 v)
	{
		m_pk_win_i16=v;
	}

	int16 Use_Avatar::Get_pk_lose()	{		return (int16)m_pk_lose_i16;}
	void Use_Avatar::Set_pk_lose(int16 v)
	{
		m_pk_lose_i16=v;
	}

	int16 Use_Avatar::Get_pk_level()	{		return (int16)m_pk_level_i16;}
	void Use_Avatar::Set_pk_level(int16 v)
	{
		m_pk_level_i16=v;
	}

	int16 Use_Avatar::Get_pk_exp()	{		return (int16)m_pk_exp_i16;}
	void Use_Avatar::Set_pk_exp(int16 v)
	{
		m_pk_exp_i16=v;
	}

	int16 Use_Avatar::Get_pk_next_exp()	{		return (int16)m_pk_next_exp_i16;}
	void Use_Avatar::Set_pk_next_exp(int16 v)
	{
		m_pk_next_exp_i16=v;
	}

	int16 Use_Avatar::Get_effect_state()	{		return (int16)m_effect_state_i16;}
	void Use_Avatar::Set_effect_state(int16 v)
	{
		m_effect_state_i16=v;
	}

	db_uid_type_ref Use_Item_IC_ACCESSORY::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_ACCESSORY::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_ACCESSORY::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_ACCESSORY::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_ACCESSORY::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_ACCESSORY::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_ACCESSORY::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_ACCESSORY::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_ACCESSORY::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_ACCESSORY::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_ACCESSORY::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_ACCESSORY::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_ACCESSORY::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_ACCESSORY::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	EItemQuality Use_Item_IC_ACCESSORY::Get_quality()	{		return (EItemQuality)m_quality_e;}
	void Use_Item_IC_ACCESSORY::Set_quality(EItemQuality v)
	{
		if(v<eBEGIN_EItemQuality || v>=eEND_EItemQuality)
		{
			GetjILog()->Error(_T("Use_Item_IC_ACCESSORY::Set_quality(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemQuality,eEND_EItemQuality,v);
		}
		m_quality_e=v;
	}

	int32 Use_Item_IC_ACCESSORY::Get_quality_value()	{		return (int32)m_quality_value_i32;}
	void Use_Item_IC_ACCESSORY::Set_quality_value(int32 v)
	{
		m_quality_value_i32=v;
	}

	db_uid_type_ref Use_Item_IC_AMOR::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_AMOR::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_AMOR::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_AMOR::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_AMOR::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_AMOR::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_AMOR::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_AMOR::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_AMOR::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_AMOR::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_AMOR::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_AMOR::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_AMOR::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_AMOR::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	EItemQuality Use_Item_IC_AMOR::Get_quality()	{		return (EItemQuality)m_quality_e;}
	void Use_Item_IC_AMOR::Set_quality(EItemQuality v)
	{
		if(v<eBEGIN_EItemQuality || v>=eEND_EItemQuality)
		{
			GetjILog()->Error(_T("Use_Item_IC_AMOR::Set_quality(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemQuality,eEND_EItemQuality,v);
		}
		m_quality_e=v;
	}

	int32 Use_Item_IC_AMOR::Get_quality_value()	{		return (int32)m_quality_value_i32;}
	void Use_Item_IC_AMOR::Set_quality_value(int32 v)
	{
		m_quality_value_i32=v;
	}

	db_uid_type_ref Use_Item_IC_CONSUMABLE::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_CONSUMABLE::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_CONSUMABLE::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_CONSUMABLE::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_CONSUMABLE::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_CONSUMABLE::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_CONSUMABLE::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_CONSUMABLE::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_CONSUMABLE::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_CONSUMABLE::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_CONSUMABLE::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_CONSUMABLE::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_CONSUMABLE::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_CONSUMABLE::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	db_uid_type_ref Use_Item_IC_COSTUME::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_COSTUME::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_COSTUME::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_COSTUME::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_COSTUME::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_COSTUME::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_COSTUME::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_COSTUME::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_COSTUME::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_COSTUME::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_COSTUME::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_COSTUME::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_COSTUME::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_COSTUME::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	db_uid_type_ref Use_Item_IC_MISC::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_MISC::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_MISC::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_MISC::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_MISC::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_MISC::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_MISC::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_MISC::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_MISC::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_MISC::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_MISC::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_MISC::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_MISC::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_MISC::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	db_uid_type_ref Use_Item_IC_QUEST::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_QUEST::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_QUEST::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_QUEST::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_QUEST::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_QUEST::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_QUEST::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_QUEST::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_QUEST::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_QUEST::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_QUEST::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_QUEST::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_QUEST::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_QUEST::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	db_uid_type_ref Use_Item_IC_RESOURCE::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_RESOURCE::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_RESOURCE::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_RESOURCE::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_RESOURCE::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_RESOURCE::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_RESOURCE::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_RESOURCE::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_RESOURCE::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_RESOURCE::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_RESOURCE::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_RESOURCE::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_RESOURCE::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_RESOURCE::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	db_uid_type_ref Use_Item_IC_WEAPON::Get_iuid()	{		return (db_uid_type_ref)m_iuid_i64;}
	void Use_Item_IC_WEAPON::Set_iuid(db_uid_type_ref v)
	{
		m_iuid_i64=v;
	}

	db_uid_type_ref Use_Item_IC_WEAPON::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Item_IC_WEAPON::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	uint32 Use_Item_IC_WEAPON::Get_isid()	{		return (uint32)m_isid_u32;}
	void Use_Item_IC_WEAPON::Set_isid(uint32 v)
	{
		m_isid_u32=v;
	}

	int32 Use_Item_IC_WEAPON::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_Item_IC_WEAPON::Set_amount(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_Item_IC_WEAPON::Get_limite_time_end()	{		return (SYSTEMTIME_REF)m_limite_time_end_tm;}
	void Use_Item_IC_WEAPON::Set_limite_time_end(const SYSTEMTIME_REF v)
	{
		m_limite_time_end_tm=v;
	}

	bool Use_Item_IC_WEAPON::Get_is_possession()	{		return (bool)m_is_possession_b;}
	void Use_Item_IC_WEAPON::Set_is_possession(bool v)
	{
		m_is_possession_b=v;
	}

	int32 Use_Item_IC_WEAPON::Get_endurance()	{		return (int32)m_endurance_i32;}
	void Use_Item_IC_WEAPON::Set_endurance(int32 v)
	{
		m_endurance_i32=v;
	}

	EItemQuality Use_Item_IC_WEAPON::Get_quality()	{		return (EItemQuality)m_quality_e;}
	void Use_Item_IC_WEAPON::Set_quality(EItemQuality v)
	{
		if(v<eBEGIN_EItemQuality || v>=eEND_EItemQuality)
		{
			GetjILog()->Error(_T("Use_Item_IC_WEAPON::Set_quality(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EItemQuality,eEND_EItemQuality,v);
		}
		m_quality_e=v;
	}

	int32 Use_Item_IC_WEAPON::Get_quality_value()	{		return (int32)m_quality_value_i32;}
	void Use_Item_IC_WEAPON::Set_quality_value(int32 v)
	{
		m_quality_value_i32=v;
	}

	db_uid_type_ref Use_Skill::Get_suid()	{		return (db_uid_type_ref)m_suid_i64;}
	void Use_Skill::Set_suid(db_uid_type_ref v)
	{
		m_suid_i64=v;
	}

	db_uid_type_ref Use_Skill::Get_auid()	{		return (db_uid_type_ref)m_auid_i64;}
	void Use_Skill::Set_auid(db_uid_type_ref v)
	{
		m_auid_i64=v;
	}

	Sys_Skill_id_t Use_Skill::Get_ssid()	{		return (Sys_Skill_id_t)m_ssid_i16;}
	void Use_Skill::Set_ssid(Sys_Skill_id_t v)
	{
		m_ssid_i16=v;
	}

	int32 Use_Skill::Get_skill_level()	{		return (int32)m_skill_level_i32;}
	void Use_Skill::Set_skill_level(int32 v)
	{
		m_skill_level_i32=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
void Use_Avatar::jDebugPrint()
{
	for_each_nAQ_Use_Avatar_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_ACCESSORY::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_ACCESSORY_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_AMOR::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_AMOR_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_CONSUMABLE::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_CONSUMABLE_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_COSTUME::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_COSTUME_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_MISC::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_MISC_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_QUEST::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_QUEST_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_RESOURCE::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_RESOURCE_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Item_IC_WEAPON::jDebugPrint()
{
	for_each_nAQ_Use_Item_IC_WEAPON_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Skill::jDebugPrint()
{
	for_each_nAQ_Use_Skill_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

#ifdef TR_SERVER_SIDE_CODE

	for_each_nAQ_aq_table_Use_STRUCT_LIST(jEXCEL_SQL_BIND_FUNC_DEFINE);
#endif //TR_SERVER_SIDE_CODE


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Avatar> Sys_Avatar_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Avatar_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Item> Sys_Item_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Item_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Skill> Sys_Skill_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Skill_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_aq_table)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_aq_table_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_EAttackType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EAvatarParts_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EAvatarSubclass_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EDamageType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EItemBind_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EItemClass_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EItemGrade_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EItemQuality_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EItemSubclass_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EMechanic_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EModifier_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EModValueType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_ESkillCastType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_ESkillType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_ETarget_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_Avatar_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Avatar*(int index)","array operator")
				jSQ_fn(find,"Sys_Avatar*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Avatar)
			for_each_nAQ_Sys_Avatar_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Avatar)
			jSQ_end();
			jSQ_g_var(&g_Sys_Avatar,g_Sys_Avatar);

			jSQ_Interface(Sys_Item_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Item*(int index)","array operator")
				jSQ_fn(find,"Sys_Item*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Item)
			for_each_nAQ_Sys_Item_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Item)
			jSQ_end();
			jSQ_g_var(&g_Sys_Item,g_Sys_Item);

			jSQ_Interface(Sys_Skill_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Skill*(int index)","array operator")
				jSQ_fn(find,"Sys_Skill*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Skill)
			for_each_nAQ_Sys_Skill_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Skill)
			jSQ_end();
			jSQ_g_var(&g_Sys_Skill,g_Sys_Skill);

			jSQ_Interface(Use_Avatar)
			for_each_nAQ_Use_Avatar_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Avatar)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_ACCESSORY)
			for_each_nAQ_Use_Item_IC_ACCESSORY_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_ACCESSORY)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_AMOR)
			for_each_nAQ_Use_Item_IC_AMOR_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_AMOR)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_CONSUMABLE)
			for_each_nAQ_Use_Item_IC_CONSUMABLE_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_CONSUMABLE)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_COSTUME)
			for_each_nAQ_Use_Item_IC_COSTUME_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_COSTUME)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_MISC)
			for_each_nAQ_Use_Item_IC_MISC_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_MISC)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_QUEST)
			for_each_nAQ_Use_Item_IC_QUEST_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_QUEST)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_RESOURCE)
			for_each_nAQ_Use_Item_IC_RESOURCE_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_RESOURCE)
			jSQ_end();

			jSQ_Interface(Use_Item_IC_WEAPON)
			for_each_nAQ_Use_Item_IC_WEAPON_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Item_IC_WEAPON)
			jSQ_end();

			jSQ_Interface(Use_Skill)
			for_each_nAQ_Use_Skill_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Skill)
			jSQ_end();

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

