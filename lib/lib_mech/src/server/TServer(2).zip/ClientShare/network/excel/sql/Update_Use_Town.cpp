
void make_update_table(WCHAR*szSQL , nAQ::Use_Town* p)
{
jw_sprintf(szSQL, L"UPDATE Use_Town SET\
[uid]=%I64d \
,[name]='%s' \
,[castle_sid]=%d \
,[townpos_sid]=%d \
,[village_con]=%d \
,[town_hero_huid]=%I64d \
,[gold_num]=%d \
,[food_num]=%d \
,[tree_num]=%d \
,[stone_num]=%d \
,[iron_num]=%d \
,[silk_num]=%d \
,[population_num]=%d \
,[soldier_num]=%d \
,[pike_num]=%d \
,[heavy_num]=%d \
,[halberd_num]=%d \
,[bow_num]=%d \
,[crossbow_num]=%d \
,[bowgun_num]=%d \
,[ballista_num]=%d \
,[chariot_num]=%d \
,[wagon_num]=%d \
,[horse_num]=%d \
,[wheelbarrow_num]=%d \
,[cart_num]=%d \
,[ladder_num]=%d \
,[ram_num]=%d \
,[tower_num]=%d \
,[trebuchet_num]=%d \
,[help]='%s' \
 WHERE [tuid]=%I64d "
	,p->Get_uid()
	,p->Get_name()
	,p->Get_castle_sid()
	,p->Get_townpos_sid()
	,p->Get_village_con()
	,p->Get_town_hero_huid()
	,p->Get_gold_num()
	,p->Get_food_num()
	,p->Get_tree_num()
	,p->Get_stone_num()
	,p->Get_iron_num()
	,p->Get_silk_num()
	,p->Get_population_num()
	,p->Get_soldier_num()
	,p->Get_pike_num()
	,p->Get_heavy_num()
	,p->Get_halberd_num()
	,p->Get_bow_num()
	,p->Get_crossbow_num()
	,p->Get_bowgun_num()
	,p->Get_ballista_num()
	,p->Get_chariot_num()
	,p->Get_wagon_num()
	,p->Get_horse_num()
	,p->Get_wheelbarrow_num()
	,p->Get_cart_num()
	,p->Get_ladder_num()
	,p->Get_ram_num()
	,p->Get_tower_num()
	,p->Get_trebuchet_num()
	,p->Get_help()
	,p->Get_tuid().m_db_id
);

}


/*
	@tuid	BIGINT
	,@uid	BIGINT
	,@name	NVARCHAR(32)
	,@castle_sid	SMALLINT
	,@townpos_sid	SMALLINT
	,@village_con	INT
	,@town_hero_huid	BIGINT
	,@gold_num	INT
	,@food_num	INT
	,@tree_num	INT
	,@stone_num	INT
	,@iron_num	INT
	,@silk_num	INT
	,@population_num	INT
	,@soldier_num	INT
	,@pike_num	INT
	,@heavy_num	INT
	,@halberd_num	INT
	,@bow_num	INT
	,@crossbow_num	INT
	,@bowgun_num	INT
	,@ballista_num	INT
	,@chariot_num	INT
	,@wagon_num	INT
	,@horse_num	INT
	,@wheelbarrow_num	INT
	,@cart_num	INT
	,@ladder_num	INT
	,@ram_num	INT
	,@tower_num	INT
	,@trebuchet_num	INT
	,@help	NVARCHAR(64)
*/