
SELECT \
cuid , \
uid , \
npc_csid FROM Use_Castle

