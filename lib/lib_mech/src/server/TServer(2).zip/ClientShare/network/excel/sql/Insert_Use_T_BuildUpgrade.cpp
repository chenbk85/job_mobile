
jw_sprintf(szSQL, L"INSERT INTO Use_T_BuildUpgrade ( \
tb_uid\
,user_uid\
,town_uid\
,build_type\
,finish_time\
) values ( \
NULL \
NULL \
NULL \
NULL \
NULL)",
,a.tb_uid \
,a.user_uid \
,a.town_uid \
,a.build_type \
,a.finish_time.wYear,a.finish_time.wMonth,a.finish_time.wDay,a.finish_time.wHour,a.finish_time.wMinute,a.finish_time.wSecond \
);