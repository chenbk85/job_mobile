
void make_update_table(WCHAR*szSQL , nAQ::Use_Force* p)
{
jw_sprintf(szSQL, L"UPDATE Use_Force SET\
[uid]=%I64d \
,[huid1]=%I64d \
,[huid2]=%I64d \
,[huid3]=%I64d \
,[fsid]=%d \
,[state_xml_id]='%s' \
,[morale]=%d \
,[morale_decrease]=%d \
,[energy]=%d \
,[energy_fill]=%d \
,[unit_soldier]=%d \
,[unit_wound]=%d \
,[unit_injury]=%d \
,[att]=%d \
,[def]=%d \
,[mspeed]=%d \
,[aspeed]=%d \
,[arange]=%d \
,[srange]=%d \
,[killing]=%d \
,[survival]=%d \
,[food]=%d \
,[gold]=%d \
,[tree]=%d \
,[stone]=%d \
,[iron]=%d \
,[silk]=%d \
,[PosType]=%d \
,[PosID]=%d \
,[x]=%d \
,[y]=%d \
 WHERE [fuid]=%I64d "
	,p->Get_uid()
	,p->Get_huid1()
	,p->Get_huid2()
	,p->Get_huid3()
	,p->Get_fsid()
	,p->Get_state_xml_id()
	,p->Get_morale()
	,p->Get_morale_decrease()
	,p->Get_energy()
	,p->Get_energy_fill()
	,p->Get_unit_soldier()
	,p->Get_unit_wound()
	,p->Get_unit_injury()
	,p->Get_att()
	,p->Get_def()
	,p->Get_mspeed()
	,p->Get_aspeed()
	,p->Get_arange()
	,p->Get_srange()
	,p->Get_killing()
	,p->Get_survival()
	,p->Get_food()
	,p->Get_gold()
	,p->Get_tree()
	,p->Get_stone()
	,p->Get_iron()
	,p->Get_silk()
	,p->Get_PosType()
	,p->Get_PosID()
	,p->Get_x()
	,p->Get_y()
	,p->Get_fuid().m_db_id
);

}


/*
	@fuid	BIGINT
	,@uid	BIGINT
	,@huid1	BIGINT
	,@huid2	BIGINT
	,@huid3	BIGINT
	,@fsid	SMALLINT
	,@state_xml_id	VARCHAR(32)
	,@morale	SMALLINT
	,@morale_decrease	SMALLINT
	,@energy	SMALLINT
	,@energy_fill	SMALLINT
	,@unit_soldier	SMALLINT
	,@unit_wound	SMALLINT
	,@unit_injury	SMALLINT
	,@att	SMALLINT
	,@def	SMALLINT
	,@mspeed	SMALLINT
	,@aspeed	SMALLINT
	,@arange	SMALLINT
	,@srange	SMALLINT
	,@killing	SMALLINT
	,@survival	SMALLINT
	,@food	SMALLINT
	,@gold	SMALLINT
	,@tree	SMALLINT
	,@stone	SMALLINT
	,@iron	SMALLINT
	,@silk	SMALLINT
	,@PosType	TINYINT
	,@PosID	INT
	,@x	SMALLINT
	,@y	SMALLINT
*/