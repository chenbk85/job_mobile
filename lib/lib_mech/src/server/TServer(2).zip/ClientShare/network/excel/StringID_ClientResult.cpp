/*------------------------------------------------------------
         Created by CE_ServerTool:function(Result_Create)
-------------------------------------------------------------*/
#include "stdafx.h"
#include "StringID_ClientResult.h"
namespace nMech
{
  jEnumString StringID_ClientResult::m_jEnumString[] =
  {
         { StringID_ClientResult::eTOT, _T(""),_T("NULL")     }
           for_each_nDebug_StringID_ClientResult(net_stringID_gen_EnumStringTable)
  };
}
