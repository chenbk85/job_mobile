/*------------------------------------------------------------
Create By Z:\bin_sam\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Dec 22 17:44:45 2009

command line : 
Excel_Converter.exe Z:\src_sam\share\network\excel\aq_monster.txt Z:\src_sam\share\network\excel\aq_table.txt Z:\src_sam\share\network\excel\aq_user.txt Z:\src_sam\share\network\excel\ServerResult.txt Z:\src_sam\share\network\excel\ClientResult.txt Z:\src_sam\share\network\excel\LocalizingTable.txt 

-------------------------------------------------------------*/

#ifndef __namespace_nErrorResult___filename_ServerResult_
#define __namespace_nErrorResult___filename_ServerResult_

#include "db_type.h"

// -------------------------------------------------
// struct �ڵ� ���ø� ����
// -------------------------------------------------
#define for_each_nErrorResult_ServerResult_Sys_STRUCT_LIST(STRUCT)\
	STRUCT(Sys_ServerResult,������ȣ,nTR_excel,nErrorResult)\



	// FUNC(eng_name,name,data_type,field_order,getter_type,setter_type,data_type_simple)
	#ifndef for_each_nErrorResult_Sys_ServerResult_STRUCT_FIELD
	#define for_each_nErrorResult_Sys_ServerResult_STRUCT_FIELD(FIELD)\
		FIELD(id,	������ȣ	,uint16	,0 , uint16 , uint16 , i16)\
		FIELD(eng_name,	�����̸�	,tname32_t	,1 , tcstr , tcstr , t32)\
		FIELD(description,	��������	,tname128_t	,2 , tcstr , tcstr , t128)\

	#endif // for_each_nErrorResult_Sys_ServerResult_STRUCT_FIELD

// -------------------------------------------------
// �ڵ� ����
// -------------------------------------------------
namespace nTR_excel { namespace nErrorResult {

	struct TR_SERVER_LIB_API Sys_ServerResult /* ������ȣ */
{
		uint16 m_id_i16; // ������ȣ min_max(,)
				typedef uint16 primary_key_t;
		primary_key_t GetPrimaryKey() { return m_id_i16; }
		void SetPrimaryKey(primary_key_t id) { m_id_i16 = id; }
		tname32_t m_eng_name_t32; // �����̸� min_max(,)
		tname128_t m_description_t128; // �������� min_max(,)

		//�ڵ������ �ֺܼ��� IsGenerateFullCode=true�̸� #define�� ����ڵ��� ��ü�� ���� �����ϴ�.
		enum enumSys_ServerResult
		{
			EField_BEGIN,
			#ifdef jEXCEL_STRUCT_ENUM_GEN
				for_each_nErrorResult_Sys_ServerResult_STRUCT_FIELD(jEXCEL_STRUCT_ENUM_GEN)
			#endif //jEXCEL_STRUCT_ENUM_GEN
			EField_END
		};
		enum { eSTRUCT_COUNT =  3 };

		#ifdef TR_SERVER_SIDE_CODE
			#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
				for_each_nErrorResult_Sys_ServerResult_STRUCT_FIELD(jEXCEL_STRUCT_GETTER_SETTER_GEN)
			#endif //jEXCEL_STRUCT_GETTER_SETTER_GEN

			#ifdef jEXCEL_STRUCT_COMMON_CODE
				jEXCEL_STRUCT_COMMON_CODE(Sys_ServerResult)
			#endif // jEXCEL_STRUCT_COMMON_CODE

		#endif //TR_SERVER_SIDE_CODE

	}; // struct Sys_ServerResult
	enum { eSTRUCT_SIZE_Sys_ServerResult = sizeof(Sys_ServerResult) };

	extern TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_ServerResult> g_Sys_ServerResult;

	
} //namespace nErrorResult 
	
}// namespace nTR_excel 

	#ifdef TR_SERVER_SIDE_CODE
		namespace nTR_net{
			using namespace nTR_excel::nErrorResult;
			#ifdef jEXCEL_struct_header_default_function
				for_each_nErrorResult_ServerResult_Sys_STRUCT_LIST(jEXCEL_struct_header_default_function);
			#endif //jEXCEL_struct_header_default_function

		} // nTR_net
	#endif //TR_SERVER_SIDE_CODE

	#ifndef jNOT_USE_SQ_BIND_CODE

		using namespace nTR_excel::nErrorResult;
		for_each_nErrorResult_ServerResult_Sys_STRUCT_LIST(jEXCEL_SQ_DECLARE_INSTANCE_TYPE);

	#endif //jNOT_USE_SQ_BIND_CODE



	#endif //__namespace_nErrorResult___filename_ServerResult_
