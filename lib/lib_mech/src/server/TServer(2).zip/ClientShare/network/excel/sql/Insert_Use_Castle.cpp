
void make_Insert_table(WCHAR* szSQL, nAQ::Use_Castle* p )
{

jw_sprintf(szSQL, L"INSERT INTO Use_Castle ( \
uid\
,npc_csid\
) VALUES ( \
%I64d,\
%d)"
,p->Get_uid().m_db_id
,p->Get_npc_csid() 
);

}