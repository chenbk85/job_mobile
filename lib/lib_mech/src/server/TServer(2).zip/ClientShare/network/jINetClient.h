
#ifndef __AqClient_Bridge_Interface_h__
#define __AqClient_Bridge_Interface_h__


#include "network/jPlayer.h"


typedef void jNet_CallBack_t(void*);
#define jINTERFACE_jINetClient(X) public:	\
	virtual jPlayer* GetPlayer() ##X\
	\
	virtual bool console_parsor(TCHAR* sz) ##X \
	/* �α伭�� ����*/\
	virtual void Send_X2L_USER_LOGIN(const char* world,const char* id, vector<nMech::uint8> &pwd) ##X \
	virtual void Send_X2L_CHANNEL_SELECT(const char* channel_name) ##X \
	virtual void Send_X2T_TOWN_SELECT(townid_t townid) ##X \
	virtual void Send_X2T_NEW_TOWN(Sys_Castle_id_t csid,Sys_TownPos_id_t tpsid,wname32_t town_name) ##X \
	virtual void Send_X2T_TOWN_DELETE(townid_t index) ##X \
	virtual void SendToTown(jPacket_Base* pP) ##X \
	\
	virtual void NetworkStart()##X\
	virtual void NetworkEnd()##X\
	virtual void Connect_Town() ##X \
	\
	virtual const vector<jWorldServerInfo>& GetWorldInfo() ##X\
	virtual bool IsOnline() ##X \
	virtual time_t GetServerTime() ##X \
	virtual nEVENT::jIMsgManager* Get_MM() ##X \
	/*���������� ����ð��� �������� ���� �ð��� ��Ʈ������ �������*/\
	virtual cstr GetLeftTime(IN time_t server_end_time, OUT fname_t buf) ##X\

jINTERFACE_END(jINetClient);


extern jINetClient* g_pjINetClient;





#define jINetClient_arg jPlayer* pUser,jIPacketSocket_IOCP* pS,void* _pData
struct jINetClient_Receiver{virtual void Call(jINetClient_arg) =0;};

#ifndef jINetClient_RECEIVER
#define jINetClient_RECEIVER(ACTION) \
struct _jJOIN_2(jINetClient_,ACTION) : public jINetClient_Receiver {\
	_jJOIN_2(jINetClient_,ACTION)(){nMech::jBase::RegistNamedPointer(jS(jINetClient),_T(#ACTION),this);} \
	virtual void Call(jINetClient_arg);}; \
	static _jJOIN_2(jINetClient_,ACTION) _jJOIN_2(g_jINetClient_,ACTION);\
	void _jJOIN_2(jINetClient_,ACTION)::Call(jINetClient_arg)
#endif


#define jINetClient_RECEIVER_ARG(X) S_##X& Data = *((S_##X*)_pData);nswb1024_t  buf;

#endif //asdlasdfqwerqwerqwerwqe