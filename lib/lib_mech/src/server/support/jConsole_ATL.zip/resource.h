//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by jConsole_ATL.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDR_MENU1                       201
#define IDC_BTN_START                   1000
#define IDC_STATUS                      1001
#define IDC_LV_LOG                      1002
#define IDC_LIST                        1003
#define IDC_BTN_VIEW_CHARACTER_LIST     1004
#define IDC_CHK_SCREEN                  1005
#define IDC_CHK_FILE                    1006
#define IDC_BTN_MIDDLEWARE              1009
#define IDC_SERVERINFO                  1010
#define IDC_LIST1                       1011
#define IDC_ST_MW                       1012
#define IDC_STATIC_MESSAGE              1012
#define IDC_ST_RELAY                    1013
#define IDC_ST_MW3                      1014
#define IDC_ST_STUN                     1014
#define IDC_BUTTON1                     1015
#define IDC_EDIT1                       1017
#define ID_COMMAND_USERDATASAVEANDCLEAR 32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
