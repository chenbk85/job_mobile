/* file : TClientUser.h
Coder : by icandoit ( mech12@nate.com)
Date : 2009-07-14 15:41:55
comp.: wiki.aqrius.com
title : 
desc : 

*/

#ifndef __AqClientUser_header__
#define __AqClientUser_header__
#pragma once

#include "../TCommon/TClientUserBase.h"

struct TClientUser_D : public _AqClientUserBase , public nDataStruct::yVectorNode<TClientUser_D>
{
	jDECLEAR_YVECTOR_MANAGER(TClientUser_D);
	virtual void Create()
	{
		_AqClientUserBase::_Create();
	}
	virtual void Destroy()
	{
		_AqClientUserBase::_Destroy();
	}
	virtual void CopyFrom(const TClientUser_D& o)
	{
		jAssert0(0 && "TClientUser_D::CopyFrom");
	}

};


typedef TClientUser_D TClientUser;

#endif // __AqClientUser_header__
