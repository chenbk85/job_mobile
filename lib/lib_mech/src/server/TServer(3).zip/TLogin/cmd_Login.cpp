/* file : cmd_Login.cpp
Coder : by icandoit ( mech12@nate.com)
Date : 2009-09-09 16:38:46
comp.: wiki.aqrius.com
title : 
desc : 

*/

#include "stdafx.h"


jCONSOLE_CMD_AUTO_user_lists();