/* file : TClientUser.h
Coder : by icandoit ( mech12@nate.com)
Date : 2009-07-14 15:41:55
comp.: wiki.aqrius.com
title : 
desc : 

*/

#ifndef __AqClientUser_header__
#define __AqClientUser_header__
#pragma once

#include "../TCommon/TClientUserBase.h"

struct TClientUser_L : public _AqClientUserBase , public nDataStruct::yVectorNode<TClientUser_L>
{
	jDECLEAR_YVECTOR_MANAGER(TClientUser_L);

	virtual void Create()
	{
		_AqClientUserBase::_Create();
	}
	virtual void Destroy()
	{
		_AqClientUserBase::_Destroy();
	}
	virtual void CopyFrom(const TClientUser_L& o)
	{
		jAssert0(0 && "TClientUser_L::CopyFrom");
	}
};

typedef TClientUser_L TClientUser;

#endif // __AqClientUser_header__
