
SELECT \
tuid , \
uid , \
name , \
castle_sid , \
townpos_sid , \
village_con , \
town_hero_huid , \
gold_num , \
food_num , \
tree_num , \
stone_num , \
iron_num , \
silk_num , \
population_num , \
soldier_num , \
pike_num , \
heavy_num , \
halberd_num , \
bow_num , \
crossbow_num , \
bowgun_num , \
ballista_num , \
chariot_num , \
wagon_num , \
horse_num , \
wheelbarrow_num , \
cart_num , \
ladder_num , \
ram_num , \
tower_num , \
trebuchet_num , \
help FROM Use_Town

