
void make_Insert_table(WCHAR* szSQL, nAQ::Use_T_Output* p )
{

jw_sprintf(szSQL, L"INSERT INTO Use_T_Output ( \
uid\
,tuid\
,build_type\
,huid\
,output\
,amount\
,finish_time\
) VALUES ( \
%I64d,\
%I64d,\
%d,\
%I64d,\
%d,\
%d,\
%d-%d-%d %d:%d:%d)"
,p->Get_uid().m_db_id
,p->Get_tuid().m_db_id
,p->Get_build_type() 
,p->Get_huid().m_db_id
,p->Get_output() 
,p->Get_amount() 
,p->Get_finish_time() 
);

}