/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Wed Jan 13 13:37:25 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "aq_enum.h"


for_each_nAQ_aq_enum_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ETownClass[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_ETownClass_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_aq_enum)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_aq_enum_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_ETownClass_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

