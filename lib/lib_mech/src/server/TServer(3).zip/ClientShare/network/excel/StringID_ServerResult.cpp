/*------------------------------------------------------------
         Created by CE_ServerTool:function(Result_Create)
-------------------------------------------------------------*/
#include "stdafx.h"
#include "StringID_ServerResult.h"
namespace nMech
{
  jEnumString StringID_ServerResult::m_jEnumString[] =
  {
         { StringID_ServerResult::eTOT, _T(""),_T("NULL")     }
           for_each_nDebug_StringID_ServerResult(net_stringID_gen_EnumStringTable)
  };
}
