
SELECT \
huid , \
hsid , \
uid , \
tuid , \
exp_domestic , \
exp_combat , \
exp_total , \
level , \
work_state , \
slot_horse , \
slot_weapon , \
slot_armor , \
slot_accessory1 , \
slot_accessory2 FROM Use_Hero

