/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Mar  9 20:51:21 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\sam_castle.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "sam_castle.h"


for_each_nAQ_sam_castle_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_Evillage_Condition[] = 
{
	{ 5 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_Evillage_Condition_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	uint16 Sys_Castle::Get_csid()	{		return (uint16)m_csid_i16;}
	void Sys_Castle::Set_csid(uint16 v)
	{
		m_csid_i16=v;
	}

	tcstr Sys_Castle::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Castle::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Castle::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	tcstr Sys_Castle::Get_name_kor()	{		return (tcstr)m_name_kor_t32;}
	void Sys_Castle::Set_name_kor(tcstr v)
	{
		if(!v){ throw _T("Sys_Castle::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_t32 , v, 32);
	}

	Sys_Hero_id_t Sys_Castle::Get_default_gsid()	{		return (Sys_Hero_id_t)m_default_gsid_u16;}
	void Sys_Castle::Set_default_gsid(uint16 v)
	{
		m_default_gsid_u16=v;
	}

	tcstr Sys_Castle::Get_force_gen_name()	{		return (tcstr)m_force_gen_name_t32;}
	void Sys_Castle::Set_force_gen_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Castle::Set_force_gen_name( val = NULL )");}
		nTR_net::jSetter(m_force_gen_name_t32 , v, 32);
	}

	Sys_Castle_id_t Sys_CastlePos::Get_cpsid()	{		return (Sys_Castle_id_t)m_cpsid_i16;}
	void Sys_CastlePos::Set_cpsid(uint16 v)
	{
		m_cpsid_i16=v;
	}

	uint16 Sys_CastlePos::Get_x()	{		return (uint16)m_x_i16;}
	void Sys_CastlePos::Set_x(uint16 v)
	{
		m_x_i16=v;
	}

	uint16 Sys_CastlePos::Get_y()	{		return (uint16)m_y_i16;}
	void Sys_CastlePos::Set_y(uint16 v)
	{
		m_y_i16=v;
	}

	tcstr Sys_CastlePos::Get_castle_map()	{		return (tcstr)m_castle_map_t32;}
	void Sys_CastlePos::Set_castle_map(tcstr v)
	{
		if(!v){ throw _T("Sys_CastlePos::Set_castle_map( val = NULL )");}
		nTR_net::jSetter(m_castle_map_t32 , v, 32);
	}

	Sys_TownPos_id_t Sys_TownPos::Get_tpsid()	{		return (Sys_TownPos_id_t)m_tpsid_u16;}
	void Sys_TownPos::Set_tpsid(uint16 v)
	{
		m_tpsid_u16=v;
	}

	uint16 Sys_TownPos::Get_x()	{		return (uint16)m_x_i16;}
	void Sys_TownPos::Set_x(uint16 v)
	{
		m_x_i16=v;
	}

	uint16 Sys_TownPos::Get_y()	{		return (uint16)m_y_i16;}
	void Sys_TownPos::Set_y(uint16 v)
	{
		m_y_i16=v;
	}

	tcstr Sys_TownPos::Get_town_map_type()	{		return (tcstr)m_town_map_type_t32;}
	void Sys_TownPos::Set_town_map_type(tcstr v)
	{
		if(!v){ throw _T("Sys_TownPos::Set_town_map_type( val = NULL )");}
		nTR_net::jSetter(m_town_map_type_t32 , v, 32);
	}

	uint16 Sys_TownPos::Get_object_id()	{		return (uint16)m_object_id_i16;}
	void Sys_TownPos::Set_object_id(uint16 v)
	{
		m_object_id_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Castle> g_Sys_Castle;


void Sys_Castle::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_csid(nTR_net::StringToVal<uint16>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_name_kor(nUNI::scb1024_t(out[2]).getT());
	Set_default_gsid(nTR_net::StringToVal<Sys_Hero_id_t>(out[3]));
	Set_force_gen_name(nUNI::scb1024_t(out[4]).getT());
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_CastlePos> g_Sys_CastlePos;


void Sys_CastlePos::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_cpsid(nTR_net::StringToVal<Sys_Castle_id_t>(out[0]));
	Set_x(nTR_net::StringToVal<uint16>(out[1]));
	Set_y(nTR_net::StringToVal<uint16>(out[2]));
	Set_castle_map(nUNI::scb1024_t(out[3]).getT());
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_TownPos> g_Sys_TownPos;


void Sys_TownPos::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_tpsid(nTR_net::StringToVal<Sys_TownPos_id_t>(out[0]));
	Set_x(nTR_net::StringToVal<uint16>(out[1]));
	Set_y(nTR_net::StringToVal<uint16>(out[2]));
	Set_town_map_type(nUNI::scb1024_t(out[3]).getT());
	Set_object_id(nTR_net::StringToVal<uint16>(out[4]));
}

void Sys_Castle::jDebugPrint()
{
	for_each_nAQ_Sys_Castle_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_CastlePos::jDebugPrint()
{
	for_each_nAQ_Sys_CastlePos_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_TownPos::jDebugPrint()
{
	for_each_nAQ_Sys_TownPos_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	uint16 Use_Castle::Get_cuid()	{		return (uint16)m_cuid_i16;}
	void Use_Castle::Set_cuid(uint16 v)
	{
		m_cuid_i16=v;
	}

	db_uid_type_ref Use_Castle::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_Castle::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	Sys_Castle_id_t Use_Castle::Get_npc_csid()	{		return (Sys_Castle_id_t)m_npc_csid_i16;}
	void Use_Castle::Set_npc_csid(uint16 v)
	{
		m_npc_csid_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
void Use_Castle::jDebugPrint()
{
	for_each_nAQ_Use_Castle_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

#ifdef TR_SERVER_SIDE_CODE

	for_each_nAQ_sam_castle_Use_STRUCT_LIST(jEXCEL_SQL_BIND_FUNC_DEFINE);
#endif //TR_SERVER_SIDE_CODE


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Castle> Sys_Castle_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Castle_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_CastlePos> Sys_CastlePos_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_CastlePos_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_TownPos> Sys_TownPos_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_TownPos_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_sam_castle)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_sam_castle_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_Evillage_Condition_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_Castle_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Castle*(int index)","array operator")
				jSQ_fn(find,"Sys_Castle*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Castle)
			for_each_nAQ_Sys_Castle_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Castle)
			jSQ_end();
			jSQ_g_var(&g_Sys_Castle,g_Sys_Castle);

			jSQ_Interface(Sys_CastlePos_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_CastlePos*(int index)","array operator")
				jSQ_fn(find,"Sys_CastlePos*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_CastlePos)
			for_each_nAQ_Sys_CastlePos_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_CastlePos)
			jSQ_end();
			jSQ_g_var(&g_Sys_CastlePos,g_Sys_CastlePos);

			jSQ_Interface(Sys_TownPos_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_TownPos*(int index)","array operator")
				jSQ_fn(find,"Sys_TownPos*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_TownPos)
			for_each_nAQ_Sys_TownPos_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_TownPos)
			jSQ_end();
			jSQ_g_var(&g_Sys_TownPos,g_Sys_TownPos);

			jSQ_Interface(Use_Castle)
			for_each_nAQ_Use_Castle_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Castle)
			jSQ_end();

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

