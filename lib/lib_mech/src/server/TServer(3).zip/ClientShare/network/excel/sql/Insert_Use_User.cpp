
void make_Insert_table(WCHAR* szSQL, nAQ::Use_User* p )
{

jw_sprintf(szSQL, L"INSERT INTO Use_User ( \
name\
,pwd\
,nic_name\
,last_login_time\
,last_logout_time\
,joined_world\
,capital_tuid\
,faim\
,bad_faim\
,cash_money\
) VALUES ( \
'%s',\
'%s',\
N'%s',\
%d-%d-%d %d:%d:%d,\
%d-%d-%d %d:%d:%d,\
'%s',\
%I64d,\
%d,\
%d,\
%d)"
,jT(p->Get_name())
,jT(p->Get_pwd())
,jT(p->Get_nic_name())
,p->Get_last_login_time() 
,p->Get_last_logout_time() 
,jT(p->Get_joined_world())
,p->Get_capital_tuid().m_db_id
,p->Get_faim() 
,p->Get_bad_faim() 
,p->Get_cash_money() 
);

}