/*------------------------------------------------------------
Create By Z:\bin_sam\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Dec 22 18:08:12 2009

command line : 
Excel_Converter.exe Z:\src_sam\share\network\excel\aq_monster.txt Z:\src_sam\share\network\excel\aq_table.txt Z:\src_sam\share\network\excel\aq_user.txt Z:\src_sam\share\network\excel\ServerResult.txt Z:\src_sam\share\network\excel\ClientResult.txt Z:\src_sam\share\network\excel\LocalizingTable.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "ClientResult.h"

namespace nTR_excel { namespace nErrorResult {


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	uint16 Sys_ClientResult::Get_id()	{		return (uint16)m_id_i16;}
	void Sys_ClientResult::Set_id(uint16 v)
	{
		m_id_i16=v;
	}

	tcstr Sys_ClientResult::Get_eng_name()	{		return (tcstr)m_eng_name_t32;}
	void Sys_ClientResult::Set_eng_name(tcstr v)
	{
		if(!v){ throw _T("Sys_ClientResult::Set_eng_name( val = NULL )");}
		nTR_net::jSetter(m_eng_name_t32 , v, 32);
	}

	tcstr Sys_ClientResult::Get_description()	{		return (tcstr)m_description_t128;}
	void Sys_ClientResult::Set_description(tcstr v)
	{
		if(!v){ throw _T("Sys_ClientResult::Set_description( val = NULL )");}
		nTR_net::jSetter(m_description_t128 , v, 128);
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_ClientResult> g_Sys_ClientResult;


void Sys_ClientResult::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_id(nTR_net::StringToVal<uint16>(out[0]));
	Set_eng_name(nUNI::scb1024_t(out[1]).getT());
	Set_description(nUNI::scb1024_t(out[2]).getT());
}

void Sys_ClientResult::jDebugPrint()
{
	for_each_nErrorResult_Sys_ClientResult_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


} //namespace nErrorResult 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nErrorResult;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nErrorResult::Sys_ClientResult> Sys_ClientResult_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_ClientResult_csv_file_t);

	namespace nTR_excel { namespace nErrorResult
	{
		jSQ_REGIST_BIND(nTR_excel_nErrorResult_ClientResult)
		{
			jSQ_Interface(Sys_ClientResult_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_ClientResult*(int index)","array operator")
				jSQ_fn(find,"Sys_ClientResult*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_ClientResult)
			for_each_nErrorResult_Sys_ClientResult_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_ClientResult)
			jSQ_end();
			jSQ_g_var(&g_Sys_ClientResult,g_Sys_ClientResult);

		}
	} /*namespace nErrorResult */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

