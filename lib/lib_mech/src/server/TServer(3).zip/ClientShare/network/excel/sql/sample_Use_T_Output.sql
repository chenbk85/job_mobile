
SELECT \
to_uid , \
uid , \
tuid , \
build_type , \
huid , \
output , \
amount , \
finish_time FROM Use_T_Output

