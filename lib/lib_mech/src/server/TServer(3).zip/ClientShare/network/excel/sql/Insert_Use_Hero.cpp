
void make_Insert_table(WCHAR* szSQL, nAQ::Use_Hero* p )
{

jw_sprintf(szSQL, L"INSERT INTO Use_Hero ( \
hsid\
,uid\
,tuid\
,exp_domestic\
,exp_combat\
,exp_total\
,level\
,work_state\
,slot_horse\
,slot_weapon\
,slot_armor\
,slot_accessory1\
,slot_accessory2\
) VALUES ( \
%d,\
%I64d,\
%I64d,\
%d,\
%d,\
%d,\
%d,\
%d,\
%d,\
%d,\
%d,\
%d,\
%d)"
,p->Get_hsid() 
,p->Get_uid().m_db_id
,p->Get_tuid().m_db_id
,p->Get_exp_domestic() 
,p->Get_exp_combat() 
,p->Get_exp_total() 
,p->Get_level() 
,p->Get_work_state() 
,p->Get_slot_horse() 
,p->Get_slot_weapon() 
,p->Get_slot_armor() 
,p->Get_slot_accessory1() 
,p->Get_slot_accessory2() 
);

}