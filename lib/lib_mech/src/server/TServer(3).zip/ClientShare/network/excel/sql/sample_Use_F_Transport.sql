
SELECT \
ft_uid , \
uid , \
fuid , \
movetown , \
finish_time FROM Use_F_Transport

