
SELECT \
fuid , \
uid , \
huid1 , \
huid2 , \
huid3 , \
fsid , \
state_xml_id , \
morale , \
morale_decrease , \
energy , \
energy_fill , \
unit_soldier , \
unit_wound , \
unit_injury , \
att , \
def , \
mspeed , \
aspeed , \
arange , \
srange , \
killing , \
survival , \
food , \
gold , \
tree , \
stone , \
iron , \
silk , \
PosType , \
PosID , \
x , \
y FROM Use_Force

