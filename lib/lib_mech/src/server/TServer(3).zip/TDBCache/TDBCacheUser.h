/* file : TDBCacheUser.h
Coder : by icandoit ( mech12@nate.com)
Date : 2009-08-21 17:25:16
comp.: wiki.aqrius.com
title : 
desc : 

*/

#ifndef __2323AqDBCacheUser_432
#define __2323AqDBCacheUser_432

#pragma once

#include "../TDBQuery/MemoryMap.h"
#include "../TCommon/jUserZoneInfo_DC.h"


struct TConnectedServerNode;

class TDBCacheUser
{
	int m_iFlag;
public:
	jUserZoneInfo_DC*		m_pjDBUserInfo;
	jUserZoneInfo_DC* GetDB(){return m_pjDBUserInfo;}

	nAQ::Use_Town* TownUse(townid_t aid)
	{
		if(aid>Town_size() || aid<=0) 
		{
			GetjILog()->Log(jFUNC1 _T("townid_t id�� �߸��Ǿ����ϴ�. : %d"),aid);
			return 0;
		}
		return GetDB()->m_Town+aid-1;
	}

	userid_t Get_uid(){ return GetDB()->m_uid;}
	acstr Get_name(){ return GetDB()->m_szID;}

	uint8&				Town_size(){ return GetDB()->Town_size();}
	nAQ::Use_Town*	Town_at(townid_t aid){ return GetDB()->Town_at(aid);}
	void				Town_erase(townid_t aid);

	TConnectedServerNode*	m_pToTown;
	TConnectedServerNode*	m_pToDungeon;

	////////////////////////////////////////////////////////////////////////////////////////////////
	// TDBCacheUser
	TDBCacheUser::TDBCacheUser()
	{
		_Destroy();
	}

	TDBCacheUser::~TDBCacheUser()
	{
		_Destroy();
	}
	void _Create()
	{
		m_pToTown =0;
		m_pToDungeon=0;
	}

	void TDBCacheUser::_Destroy()
	{
		m_pjDBUserInfo=0;
	}

	void Setup_DBData(){}//db data �ε��� ù �ʱ�ȭ
};

cstr ToString(TDBCacheUser* pUser,fname_t buf);


#endif // __2323AqDBCacheUser_432
