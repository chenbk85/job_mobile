/* file : TClientUser.cpp
Coder : by icandoit ( mech12@nate.com)
Date : 2009-07-14 15:42:03
comp.: wiki.aqrius.com
title : 
desc : 

*/

#include "stdafx.h"
#include "TClientUser.h"

jDEFINE_YVECTOR_MANAGER(TClientUser, 256,10);

TClientUser::TClientUser()
{
	m_uid.m_id = 0;
}

int TClientUser::StartPlayTime()
{
	m_playTime = GetTickCount();
	return 0;
}

int TClientUser::GetPlayTime()
{
	uint32 rTime = GetTickCount() - m_playTime;		
	return rTime > 0 ? rTime / 60000 : 0; //1000*60 �д���
}
