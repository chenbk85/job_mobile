/* file : net_SQ.h
Coder : by icandoit ( mech12@nate.com)
Date : 2008-10-08 18:58:16
comp.: actoz.com
title : 
desc : 

*/

#ifndef __net_SQ_header__
#define __net_SQ_header__
#pragma once

#if 0
DECLARE_INSTANCE_TYPE(jServerInfoBase);
DECLARE_INSTANCE_TYPE(jServerInfo);
DECLARE_INSTANCE_TYPE(jServerUserCountInfo);
//DECLARE_ENUM_TYPE(ETextCategory);

DECLARE_ENUM_TYPE(jServerInfo::EServerType);
#endif


#endif // __net_SQ_header__