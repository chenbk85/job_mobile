/* file : net_Setter.cpp
Coder : by icandoit ( mech12@nate.com)
Date : 2008-03-31 10:46:05
comp.: www.actoz.com
title : 
desc : 

*/

#include "stdafx.h"
#include "net_Setter.h"

