
SELECT \
tb_uid , \
user_uid , \
town_uid , \
build_type , \
finish_time FROM Use_T_BuildUpgrade

