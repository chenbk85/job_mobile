/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Mar  9 20:51:21 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\sam_force.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "sam_force.h"


for_each_nAQ_sam_force_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_E_ClassItemA[] = 
{
	{ 10 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_E_ClassItemA_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_E_ClassItemB[] = 
{
	{ 8 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_E_ClassItemB_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_E_W_Event[] = 
{
	{ 6 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_E_W_Event_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EForceClass[] = 
{
	{ 5 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EForceClass_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EForcePosType[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EForcePosType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	Sys_Force_id_t Sys_Force::Get_fsid()	{		return (Sys_Force_id_t)m_fsid_u16;}
	void Sys_Force::Set_fsid(uint16 v)
	{
		m_fsid_u16=v;
	}

	tcstr Sys_Force::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Force::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Force::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	tcstr Sys_Force::Get_name_kor()	{		return (tcstr)m_name_kor_t32;}
	void Sys_Force::Set_name_kor(tcstr v)
	{
		if(!v){ throw _T("Sys_Force::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_t32 , v, 32);
	}

	EForceClass Sys_Force::Get_force_class()	{		return (EForceClass)m_force_class_e;}
	void Sys_Force::Set_force_class(EForceClass v)
	{
		if(v<eBEGIN_EForceClass || v>=eEND_EForceClass)
		{
			GetjILog()->Error(_T("Sys_Force::Set_force_class(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EForceClass,eEND_EForceClass,v);
		}
		m_force_class_e=v;
	}

	E_ClassItemA Sys_Force::Get_forceClassItemA()	{		return (E_ClassItemA)m_forceClassItemA_e;}
	void Sys_Force::Set_forceClassItemA(E_ClassItemA v)
	{
		if(v<eBEGIN_E_ClassItemA || v>=eEND_E_ClassItemA)
		{
			GetjILog()->Error(_T("Sys_Force::Set_forceClassItemA(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_E_ClassItemA,eEND_E_ClassItemA,v);
		}
		m_forceClassItemA_e=v;
	}

	E_ClassItemB Sys_Force::Get_forceClassItemB()	{		return (E_ClassItemB)m_forceClassItemB_e;}
	void Sys_Force::Set_forceClassItemB(E_ClassItemB v)
	{
		if(v<eBEGIN_E_ClassItemB || v>=eEND_E_ClassItemB)
		{
			GetjILog()->Error(_T("Sys_Force::Set_forceClassItemB(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_E_ClassItemB,eEND_E_ClassItemB,v);
		}
		m_forceClassItemB_e=v;
	}

	int16 Sys_Force::Get_att()	{		return (int16)m_att_i16;}
	void Sys_Force::Set_att(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_att_i16=v;
	}

	int16 Sys_Force::Get_def()	{		return (int16)m_def_i16;}
	void Sys_Force::Set_def(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_def_i16=v;
	}

	int16 Sys_Force::Get_mspeed()	{		return (int16)m_mspeed_i16;}
	void Sys_Force::Set_mspeed(int16 v)
	{
		if(v>1000) v = 1000;
		if(v<0) v = 0;
		m_mspeed_i16=v;
	}

	int16 Sys_Force::Get_aspeed()	{		return (int16)m_aspeed_i16;}
	void Sys_Force::Set_aspeed(int16 v)
	{
		if(v>10000) v = 10000;
		if(v<0) v = 0;
		m_aspeed_i16=v;
	}

	int16 Sys_Force::Get_srange()	{		return (int16)m_srange_i16;}
	void Sys_Force::Set_srange(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_srange_i16=v;
	}

	int16 Sys_Force::Get_suvival_ratio()	{		return (int16)m_suvival_ratio_i16;}
	void Sys_Force::Set_suvival_ratio(int16 v)
	{
		if(v>1000) v = 1000;
		if(v<0) v = 0;
		m_suvival_ratio_i16=v;
	}

	int16 Sys_Force::Get_kill_ratio()	{		return (int16)m_kill_ratio_i16;}
	void Sys_Force::Set_kill_ratio(int16 v)
	{
		if(v>1000) v = 1000;
		if(v<0) v = 0;
		m_kill_ratio_i16=v;
	}

	int16 Sys_Force::Get_client_id()	{		return (int16)m_client_id_i16;}
	void Sys_Force::Set_client_id(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_client_id_i16=v;
	}

	int16 Sys_Force::Get_unit_load()	{		return (int16)m_unit_load_i16;}
	void Sys_Force::Set_unit_load(int16 v)
	{
		if(v>100000) v = 100000;
		if(v<0) v = 0;
		m_unit_load_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Force> g_Sys_Force;


void Sys_Force::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_fsid(nTR_net::StringToVal<Sys_Force_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_name_kor(nUNI::scb1024_t(out[2]).getT());
	Set_force_class(nTR_net::StringToVal(out[3],nAQ::eBEGIN_EForceClass));
	Set_forceClassItemA(nTR_net::StringToVal(out[4],nAQ::eBEGIN_E_ClassItemA));
	Set_forceClassItemB(nTR_net::StringToVal(out[5],nAQ::eBEGIN_E_ClassItemB));
	Set_att(nTR_net::StringToVal<int16>(out[6]));
	Set_def(nTR_net::StringToVal<int16>(out[7]));
	Set_mspeed(nTR_net::StringToVal<int16>(out[8]));
	Set_aspeed(nTR_net::StringToVal<int16>(out[9]));
	Set_srange(nTR_net::StringToVal<int16>(out[10]));
	Set_suvival_ratio(nTR_net::StringToVal<int16>(out[11]));
	Set_kill_ratio(nTR_net::StringToVal<int16>(out[12]));
	Set_client_id(nTR_net::StringToVal<int16>(out[13]));
	Set_unit_load(nTR_net::StringToVal<int16>(out[14]));
}

void Sys_Force::jDebugPrint()
{
	for_each_nAQ_Sys_Force_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	db_uid_type_ref Use_F_Transport::Get_ft_uid()	{		return (db_uid_type_ref)m_ft_uid_i64;}
	void Use_F_Transport::Set_ft_uid(db_uid_type_ref v)
	{
		m_ft_uid_i64=v;
	}

	db_uid_type_ref Use_F_Transport::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_F_Transport::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	db_uid_type_ref Use_F_Transport::Get_fuid()	{		return (db_uid_type_ref)m_fuid_i64;}
	void Use_F_Transport::Set_fuid(db_uid_type_ref v)
	{
		m_fuid_i64=v;
	}

	db_uid_type_ref Use_F_Transport::Get_movetown()	{		return (db_uid_type_ref)m_movetown_i64;}
	void Use_F_Transport::Set_movetown(db_uid_type_ref v)
	{
		m_movetown_i64=v;
	}

	SYSTEMTIME_REF Use_F_Transport::Get_finish_time()	{		return (SYSTEMTIME_REF)m_finish_time_tm;}
	void Use_F_Transport::Set_finish_time(const SYSTEMTIME_REF v)
	{
		m_finish_time_tm=v;
	}

	db_uid_type_ref Use_Force::Get_fuid()	{		return (db_uid_type_ref)m_fuid_i64;}
	void Use_Force::Set_fuid(db_uid_type_ref v)
	{
		m_fuid_i64=v;
	}

	db_uid_type_ref Use_Force::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_Force::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	db_uid_type_ref Use_Force::Get_huid1()	{		return (db_uid_type_ref)m_huid1_i64;}
	void Use_Force::Set_huid1(db_uid_type_ref v)
	{
		m_huid1_i64=v;
	}

	db_uid_type_ref Use_Force::Get_huid2()	{		return (db_uid_type_ref)m_huid2_i64;}
	void Use_Force::Set_huid2(db_uid_type_ref v)
	{
		m_huid2_i64=v;
	}

	db_uid_type_ref Use_Force::Get_huid3()	{		return (db_uid_type_ref)m_huid3_i64;}
	void Use_Force::Set_huid3(db_uid_type_ref v)
	{
		m_huid3_i64=v;
	}

	Sys_Force_id_t Use_Force::Get_fsid()	{		return (Sys_Force_id_t)m_fsid_u16;}
	void Use_Force::Set_fsid(uint16 v)
	{
		m_fsid_u16=v;
	}

	acstr Use_Force::Get_state_xml_id()	{		return (acstr)m_state_xml_id_a32;}
	void Use_Force::Set_state_xml_id(acstr v)
	{
		if(!v){ throw _T("Use_Force::Set_state_xml_id( val = NULL )");}
		nTR_net::jSetter(m_state_xml_id_a32 , v, 32);
	}

	int16 Use_Force::Get_morale()	{		return (int16)m_morale_i16;}
	void Use_Force::Set_morale(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_morale_i16=v;
	}

	int16 Use_Force::Get_morale_decrease()	{		return (int16)m_morale_decrease_i16;}
	void Use_Force::Set_morale_decrease(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_morale_decrease_i16=v;
	}

	int16 Use_Force::Get_energy()	{		return (int16)m_energy_i16;}
	void Use_Force::Set_energy(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_energy_i16=v;
	}

	int16 Use_Force::Get_energy_fill()	{		return (int16)m_energy_fill_i16;}
	void Use_Force::Set_energy_fill(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_energy_fill_i16=v;
	}

	int16 Use_Force::Get_unit_soldier()	{		return (int16)m_unit_soldier_i16;}
	void Use_Force::Set_unit_soldier(int16 v)
	{
		if(v>10000) v = 10000;
		if(v<0) v = 0;
		m_unit_soldier_i16=v;
	}

	int16 Use_Force::Get_unit_wound()	{		return (int16)m_unit_wound_i16;}
	void Use_Force::Set_unit_wound(int16 v)
	{
		if(v>10000) v = 10000;
		if(v<0) v = 0;
		m_unit_wound_i16=v;
	}

	int16 Use_Force::Get_unit_injury()	{		return (int16)m_unit_injury_i16;}
	void Use_Force::Set_unit_injury(int16 v)
	{
		if(v>10000) v = 10000;
		if(v<0) v = 0;
		m_unit_injury_i16=v;
	}

	int16 Use_Force::Get_att()	{		return (int16)m_att_i16;}
	void Use_Force::Set_att(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_att_i16=v;
	}

	int16 Use_Force::Get_def()	{		return (int16)m_def_i16;}
	void Use_Force::Set_def(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_def_i16=v;
	}

	int16 Use_Force::Get_mspeed()	{		return (int16)m_mspeed_i16;}
	void Use_Force::Set_mspeed(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_mspeed_i16=v;
	}

	int16 Use_Force::Get_aspeed()	{		return (int16)m_aspeed_i16;}
	void Use_Force::Set_aspeed(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_aspeed_i16=v;
	}

	int16 Use_Force::Get_arange()	{		return (int16)m_arange_i16;}
	void Use_Force::Set_arange(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_arange_i16=v;
	}

	int16 Use_Force::Get_srange()	{		return (int16)m_srange_i16;}
	void Use_Force::Set_srange(int16 v)
	{
		if(v>100) v = 100;
		if(v<0) v = 0;
		m_srange_i16=v;
	}

	int16 Use_Force::Get_killing()	{		return (int16)m_killing_i16;}
	void Use_Force::Set_killing(int16 v)
	{
		if(v>1000) v = 1000;
		if(v<0) v = 0;
		m_killing_i16=v;
	}

	int16 Use_Force::Get_survival()	{		return (int16)m_survival_i16;}
	void Use_Force::Set_survival(int16 v)
	{
		if(v>1000) v = 1000;
		if(v<0) v = 0;
		m_survival_i16=v;
	}

	int16 Use_Force::Get_food()	{		return (int16)m_food_i16;}
	void Use_Force::Set_food(int16 v)
	{
		if(v>1000000) v = 1000000;
		if(v<0) v = 0;
		m_food_i16=v;
	}

	int16 Use_Force::Get_gold()	{		return (int16)m_gold_i16;}
	void Use_Force::Set_gold(int16 v)
	{
		if(v>100000000) v = 100000000;
		if(v<0) v = 0;
		m_gold_i16=v;
	}

	int16 Use_Force::Get_tree()	{		return (int16)m_tree_i16;}
	void Use_Force::Set_tree(int16 v)
	{
		if(v>100000) v = 100000;
		if(v<0) v = 0;
		m_tree_i16=v;
	}

	int16 Use_Force::Get_stone()	{		return (int16)m_stone_i16;}
	void Use_Force::Set_stone(int16 v)
	{
		if(v>100000) v = 100000;
		if(v<0) v = 0;
		m_stone_i16=v;
	}

	int16 Use_Force::Get_iron()	{		return (int16)m_iron_i16;}
	void Use_Force::Set_iron(int16 v)
	{
		if(v>100000) v = 100000;
		if(v<0) v = 0;
		m_iron_i16=v;
	}

	int16 Use_Force::Get_silk()	{		return (int16)m_silk_i16;}
	void Use_Force::Set_silk(int16 v)
	{
		if(v>100000) v = 100000;
		if(v<0) v = 0;
		m_silk_i16=v;
	}

	EForcePosType Use_Force::Get_PosType()	{		return (EForcePosType)m_PosType_e;}
	void Use_Force::Set_PosType(EForcePosType v)
	{
		if(v<eBEGIN_EForcePosType || v>=eEND_EForcePosType)
		{
			GetjILog()->Error(_T("Use_Force::Set_PosType(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EForcePosType,eEND_EForcePosType,v);
		}
		m_PosType_e=v;
	}

	int32 Use_Force::Get_PosID()	{		return (int32)m_PosID_i32;}
	void Use_Force::Set_PosID(int32 v)
	{
		m_PosID_i32=v;
	}

	uint16 Use_Force::Get_x()	{		return (uint16)m_x_i16;}
	void Use_Force::Set_x(uint16 v)
	{
		m_x_i16=v;
	}

	uint16 Use_Force::Get_y()	{		return (uint16)m_y_i16;}
	void Use_Force::Set_y(uint16 v)
	{
		m_y_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
void Use_F_Transport::jDebugPrint()
{
	for_each_nAQ_Use_F_Transport_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Force::jDebugPrint()
{
	for_each_nAQ_Use_Force_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

#ifdef TR_SERVER_SIDE_CODE

	for_each_nAQ_sam_force_Use_STRUCT_LIST(jEXCEL_SQL_BIND_FUNC_DEFINE);
#endif //TR_SERVER_SIDE_CODE


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Force> Sys_Force_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Force_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_sam_force)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_sam_force_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_E_ClassItemA_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_E_ClassItemB_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_E_W_Event_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EForceClass_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EForcePosType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_Force_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Force*(int index)","array operator")
				jSQ_fn(find,"Sys_Force*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Force)
			for_each_nAQ_Sys_Force_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Force)
			jSQ_end();
			jSQ_g_var(&g_Sys_Force,g_Sys_Force);

			jSQ_Interface(Use_F_Transport)
			for_each_nAQ_Use_F_Transport_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_F_Transport)
			jSQ_end();

			jSQ_Interface(Use_Force)
			for_each_nAQ_Use_Force_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Force)
			jSQ_end();

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

