/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Mar  9 20:51:21 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\sam_world.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "sam_world.h"


for_each_nAQ_sam_world_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EIssue_Info[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EIssue_Info_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_ETile_Sort[] = 
{
	{ 7 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_ETile_Sort_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	Sys_Tile_id_t Sys_Tile::Get_tisid()	{		return (Sys_Tile_id_t)m_tisid_i16;}
	void Sys_Tile::Set_tisid(uint16 v)
	{
		m_tisid_i16=v;
	}

	tcstr Sys_Tile::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Tile::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Tile::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	tcstr Sys_Tile::Get_name_kor()	{		return (tcstr)m_name_kor_t32;}
	void Sys_Tile::Set_name_kor(tcstr v)
	{
		if(!v){ throw _T("Sys_Tile::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_t32 , v, 32);
	}

	tcstr Sys_Tile::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_Tile::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_Tile::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	ETile_Sort Sys_Tile::Get_sort()	{		return (ETile_Sort)m_sort_e;}
	void Sys_Tile::Set_sort(ETile_Sort v)
	{
		if(v<eBEGIN_ETile_Sort || v>=eEND_ETile_Sort)
		{
			GetjILog()->Error(_T("Sys_Tile::Set_sort(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_ETile_Sort,eEND_ETile_Sort,v);
		}
		m_sort_e=v;
	}

	int16 Sys_Tile::Get_mspeed()	{		return (int16)m_mspeed_i16;}
	void Sys_Tile::Set_mspeed(int16 v)
	{
		if(v>5000) v = 5000;
		if(v<0) v = 0;
		m_mspeed_i16=v;
	}

	int16 Sys_Tile::Get_visibility()	{		return (int16)m_visibility_i16;}
	void Sys_Tile::Set_visibility(int16 v)
	{
		if(v>100) v = 100;
		if(v<-100) v = -100;
		m_visibility_i16=v;
	}

	bool Sys_Tile::Get_build()	{		return (bool)m_build_b;}
	void Sys_Tile::Set_build(bool v)
	{
		m_build_b=v;
	}

	int16 Sys_Tile::Get_fskill()	{		return (int16)m_fskill_i16;}
	void Sys_Tile::Set_fskill(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_fskill_i16=v;
	}

	int16 Sys_Tile::Get_wskill()	{		return (int16)m_wskill_i16;}
	void Sys_Tile::Set_wskill(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_wskill_i16=v;
	}

	int16 Sys_Tile::Get_rskill()	{		return (int16)m_rskill_i16;}
	void Sys_Tile::Set_rskill(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_rskill_i16=v;
	}

	int16 Sys_Tile::Get_hiskill()	{		return (int16)m_hiskill_i16;}
	void Sys_Tile::Set_hiskill(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_hiskill_i16=v;
	}

	Sys_World_id_t Sys_World::Get_wsid()	{		return (Sys_World_id_t)m_wsid_i16;}
	void Sys_World::Set_wsid(uint16 v)
	{
		m_wsid_i16=v;
	}

	tcstr Sys_World::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_World::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_World::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	tcstr Sys_World::Get_name_kor()	{		return (tcstr)m_name_kor_t32;}
	void Sys_World::Set_name_kor(tcstr v)
	{
		if(!v){ throw _T("Sys_World::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_t32 , v, 32);
	}

	EIssue_Info Sys_World::Get_issue()	{		return (EIssue_Info)m_issue_e;}
	void Sys_World::Set_issue(EIssue_Info v)
	{
		if(v<eBEGIN_EIssue_Info || v>=eEND_EIssue_Info)
		{
			GetjILog()->Error(_T("Sys_World::Set_issue(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EIssue_Info,eEND_EIssue_Info,v);
		}
		m_issue_e=v;
	}

	tcstr Sys_World::Get_address()	{		return (tcstr)m_address_t32;}
	void Sys_World::Set_address(tcstr v)
	{
		if(!v){ throw _T("Sys_World::Set_address( val = NULL )");}
		nTR_net::jSetter(m_address_t32 , v, 32);
	}

	tcstr Sys_World::Get_help()	{		return (tcstr)m_help_t64;}
	void Sys_World::Set_help(tcstr v)
	{
		if(!v){ throw _T("Sys_World::Set_help( val = NULL )");}
		nTR_net::jSetter(m_help_t64 , v, 64);
	}

	int16 Sys_World::Get_goldstart()	{		return (int16)m_goldstart_i16;}
	void Sys_World::Set_goldstart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_goldstart_i16=v;
	}

	int16 Sys_World::Get_ricestart()	{		return (int16)m_ricestart_i16;}
	void Sys_World::Set_ricestart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_ricestart_i16=v;
	}

	int16 Sys_World::Get_treestart()	{		return (int16)m_treestart_i16;}
	void Sys_World::Set_treestart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_treestart_i16=v;
	}

	int16 Sys_World::Get_stonestart()	{		return (int16)m_stonestart_i16;}
	void Sys_World::Set_stonestart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_stonestart_i16=v;
	}

	int16 Sys_World::Get_ironstart()	{		return (int16)m_ironstart_i16;}
	void Sys_World::Set_ironstart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_ironstart_i16=v;
	}

	int16 Sys_World::Get_silkstart()	{		return (int16)m_silkstart_i16;}
	void Sys_World::Set_silkstart(int16 v)
	{
		if(v>999) v = 999;
		if(v<0) v = 0;
		m_silkstart_i16=v;
	}

	int16 Sys_World::Get_mspeed()	{		return (int16)m_mspeed_i16;}
	void Sys_World::Set_mspeed(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_mspeed_i16=v;
	}

	int16 Sys_World::Get_re_increase()	{		return (int16)m_re_increase_i16;}
	void Sys_World::Set_re_increase(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_re_increase_i16=v;
	}

	int16 Sys_World::Get_buildtime()	{		return (int16)m_buildtime_i16;}
	void Sys_World::Set_buildtime(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_buildtime_i16=v;
	}

	int16 Sys_World::Get_produtime()	{		return (int16)m_produtime_i16;}
	void Sys_World::Set_produtime(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_produtime_i16=v;
	}

	int16 Sys_World::Get_recrutime()	{		return (int16)m_recrutime_i16;}
	void Sys_World::Set_recrutime(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_recrutime_i16=v;
	}

	int16 Sys_World::Get_researchtime()	{		return (int16)m_researchtime_i16;}
	void Sys_World::Set_researchtime(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_researchtime_i16=v;
	}

	int16 Sys_World::Get_goldamount()	{		return (int16)m_goldamount_i16;}
	void Sys_World::Set_goldamount(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_goldamount_i16=v;
	}

	int16 Sys_World::Get_peo_increase()	{		return (int16)m_peo_increase_i16;}
	void Sys_World::Set_peo_increase(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_peo_increase_i16=v;
	}

	int16 Sys_World::Get_questbenefit()	{		return (int16)m_questbenefit_i16;}
	void Sys_World::Set_questbenefit(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_questbenefit_i16=v;
	}

	int16 Sys_World::Get_huntbenefit()	{		return (int16)m_huntbenefit_i16;}
	void Sys_World::Set_huntbenefit(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_huntbenefit_i16=v;
	}

	int16 Sys_World::Get_appoint_ratio()	{		return (int16)m_appoint_ratio_i16;}
	void Sys_World::Set_appoint_ratio(int16 v)
	{
		if(v>999) v = 999;
		if(v<-999) v = -999;
		m_appoint_ratio_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Tile> g_Sys_Tile;


void Sys_Tile::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_tisid(nTR_net::StringToVal<Sys_Tile_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_name_kor(nUNI::scb1024_t(out[2]).getT());
	Set_client_file(nUNI::scb1024_t(out[3]).getT());
	Set_sort(nTR_net::StringToVal(out[4],nAQ::eBEGIN_ETile_Sort));
	Set_mspeed(nTR_net::StringToVal<int16>(out[5]));
	Set_visibility(nTR_net::StringToVal<int16>(out[6]));
	Set_build(nTR_net::StringToVal<bool>(out[7]));
	Set_fskill(nTR_net::StringToVal<int16>(out[8]));
	Set_wskill(nTR_net::StringToVal<int16>(out[9]));
	Set_rskill(nTR_net::StringToVal<int16>(out[10]));
	Set_hiskill(nTR_net::StringToVal<int16>(out[11]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_World> g_Sys_World;


void Sys_World::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_wsid(nTR_net::StringToVal<Sys_World_id_t>(out[0]));
	Set_name(nUNI::scb1024_t(out[1]).getT());
	Set_name_kor(nUNI::scb1024_t(out[2]).getT());
	Set_issue(nTR_net::StringToVal(out[3],nAQ::eBEGIN_EIssue_Info));
	Set_address(nUNI::scb1024_t(out[4]).getT());
	Set_help(nUNI::scb1024_t(out[5]).getT());
	Set_goldstart(nTR_net::StringToVal<int16>(out[6]));
	Set_ricestart(nTR_net::StringToVal<int16>(out[7]));
	Set_treestart(nTR_net::StringToVal<int16>(out[8]));
	Set_stonestart(nTR_net::StringToVal<int16>(out[9]));
	Set_ironstart(nTR_net::StringToVal<int16>(out[10]));
	Set_silkstart(nTR_net::StringToVal<int16>(out[11]));
	Set_mspeed(nTR_net::StringToVal<int16>(out[12]));
	Set_re_increase(nTR_net::StringToVal<int16>(out[13]));
	Set_buildtime(nTR_net::StringToVal<int16>(out[14]));
	Set_produtime(nTR_net::StringToVal<int16>(out[15]));
	Set_recrutime(nTR_net::StringToVal<int16>(out[16]));
	Set_researchtime(nTR_net::StringToVal<int16>(out[17]));
	Set_goldamount(nTR_net::StringToVal<int16>(out[18]));
	Set_peo_increase(nTR_net::StringToVal<int16>(out[19]));
	Set_questbenefit(nTR_net::StringToVal<int16>(out[20]));
	Set_huntbenefit(nTR_net::StringToVal<int16>(out[21]));
	Set_appoint_ratio(nTR_net::StringToVal<int16>(out[22]));
}

void Sys_Tile::jDebugPrint()
{
	for_each_nAQ_Sys_Tile_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_World::jDebugPrint()
{
	for_each_nAQ_Sys_World_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Tile> Sys_Tile_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Tile_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_World> Sys_World_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_World_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_sam_world)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_sam_world_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_EIssue_Info_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_ETile_Sort_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_Tile_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Tile*(int index)","array operator")
				jSQ_fn(find,"Sys_Tile*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Tile)
			for_each_nAQ_Sys_Tile_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Tile)
			jSQ_end();
			jSQ_g_var(&g_Sys_Tile,g_Sys_Tile);

			jSQ_Interface(Sys_World_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_World*(int index)","array operator")
				jSQ_fn(find,"Sys_World*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_World)
			for_each_nAQ_Sys_World_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_World)
			jSQ_end();
			jSQ_g_var(&g_Sys_World,g_Sys_World);

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

