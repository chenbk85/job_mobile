
void make_update_table(WCHAR*szSQL , nAQ::Use_Castle* p)
{
jw_sprintf(szSQL, L"UPDATE Use_Castle SET\
[uid]=%I64d \
,[npc_csid]=%d \
 WHERE [cuid]=%d "
	,p->Get_uid()
	,p->Get_npc_csid()
	,p->Get_cuid().m_db_id
);

}


/*
	@cuid	SMALLINT
	,@uid	BIGINT
	,@npc_csid	SMALLINT
*/