/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Mar  9 20:51:21 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\sam_user.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "sam_user.h"


for_each_nAQ_sam_user_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EBuildType[] = 
{
	{ 22 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EBuildType_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EOutput[] = 
{
	{ 24 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EOutput_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	Sys_T_Bar_id_t Sys_T_Bar::Get_isid()	{		return (Sys_T_Bar_id_t)m_isid_i16;}
	void Sys_T_Bar::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_Bar::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_Bar::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_Bar::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_Bar::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_Bar::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_Bar::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_Bar::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_Bar::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_Bar::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_Bar::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_Bar::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_Bar::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_Bar::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_Bar::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_Bar::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_Bar::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_Bar::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_Bar::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_Bar::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_Bar::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_Bar::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_Bar::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_Bar::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_Bar::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_Bar::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_Bar::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_Bar::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_Bar::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_Bar::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_Bar::Get_hideHero()	{		return (int16)m_hideHero_i16;}
	void Sys_T_Bar::Set_hideHero(int16 v)
	{
		m_hideHero_i16=v;
	}

	uint32 Sys_T_Bar::Get_resettime()	{		return (uint32)m_resettime_i32;}
	void Sys_T_Bar::Set_resettime(uint32 v)
	{
		m_resettime_i32=v;
	}

	int16 Sys_T_Bar::Get_itemnum()	{		return (int16)m_itemnum_i16;}
	void Sys_T_Bar::Set_itemnum(int16 v)
	{
		m_itemnum_i16=v;
	}

	Sys_T_Barrack_id_t Sys_T_Barrack::Get_isid()	{		return (Sys_T_Barrack_id_t)m_isid_i16;}
	void Sys_T_Barrack::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_Barrack::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_Barrack::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_Barrack::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_Barrack::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_Barrack::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_Barrack::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_Barrack::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_Barrack::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_Barrack::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_Barrack::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_Barrack::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_Barrack::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_Barrack::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_Barrack::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_Barrack::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_Barrack::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_Barrack::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_Barrack::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_Barrack::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_Barrack::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_Barrack::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_Barrack::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_Barrack::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_Barrack::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_Barrack::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_Barrack::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_Barrack::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_Barrack::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_Barrack::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_Barrack::Get_s_p_speed()	{		return (int16)m_s_p_speed_i16;}
	void Sys_T_Barrack::Set_s_p_speed(int16 v)
	{
		m_s_p_speed_i16=v;
	}

	int16 Sys_T_Barrack::Get_s_p_cost()	{		return (int16)m_s_p_cost_i16;}
	void Sys_T_Barrack::Set_s_p_cost(int16 v)
	{
		m_s_p_cost_i16=v;
	}

	int16 Sys_T_Barrack::Get_s_output()	{		return (int16)m_s_output_i16;}
	void Sys_T_Barrack::Set_s_output(int16 v)
	{
		m_s_output_i16=v;
	}

	Sys_T_Camp_id_t Sys_T_Camp::Get_isid()	{		return (Sys_T_Camp_id_t)m_isid_i16;}
	void Sys_T_Camp::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_Camp::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_Camp::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_Camp::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_Camp::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_Camp::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_Camp::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_Camp::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_Camp::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_Camp::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_Camp::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_Camp::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_Camp::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_Camp::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_Camp::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_Camp::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_Camp::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_Camp::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_Camp::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_Camp::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_Camp::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_Camp::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_Camp::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_Camp::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_Camp::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_Camp::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_Camp::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_Camp::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_Camp::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_Camp::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_Camp::Get_f_r_spend()	{		return (int16)m_f_r_spend_i16;}
	void Sys_T_Camp::Set_f_r_spend(int16 v)
	{
		m_f_r_spend_i16=v;
	}

	int32 Sys_T_Camp::Get_f_storage()	{		return (int32)m_f_storage_i32;}
	void Sys_T_Camp::Set_f_storage(int32 v)
	{
		m_f_storage_i32=v;
	}

	Sys_T_Depot_id_t Sys_T_Depot::Get_isid()	{		return (Sys_T_Depot_id_t)m_isid_i16;}
	void Sys_T_Depot::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_Depot::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_Depot::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_Depot::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_Depot::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_Depot::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_Depot::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_Depot::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_Depot::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_Depot::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_Depot::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_Depot::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_Depot::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_Depot::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_Depot::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_Depot::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_Depot::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_Depot::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_Depot::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_Depot::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_Depot::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_Depot::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_Depot::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_Depot::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_Depot::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_Depot::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_Depot::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_Depot::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_Depot::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_Depot::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int32 Sys_T_Depot::Get_storage()	{		return (int32)m_storage_i32;}
	void Sys_T_Depot::Set_storage(int32 v)
	{
		m_storage_i32=v;
	}

	Sys_T_Farm_id_t Sys_T_Farm::Get_isid()	{		return (Sys_T_Farm_id_t)m_isid_i16;}
	void Sys_T_Farm::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_Farm::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_Farm::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_Farm::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_Farm::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_Farm::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_Farm::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_Farm::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_Farm::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_Farm::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_Farm::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_Farm::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_Farm::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_Farm::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_Farm::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_Farm::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_Farm::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_Farm::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_Farm::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_Farm::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_Farm::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_Farm::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_Farm::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_Farm::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_Farm::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_Farm::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_Farm::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_Farm::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_Farm::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_Farm::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_Farm::Get_foodoutput()	{		return (int16)m_foodoutput_i16;}
	void Sys_T_Farm::Set_foodoutput(int16 v)
	{
		m_foodoutput_i16=v;
	}

	Sys_T_House_id_t Sys_T_House::Get_isid()	{		return (Sys_T_House_id_t)m_isid_i16;}
	void Sys_T_House::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_House::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_House::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_House::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_House::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_House::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_House::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_House::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_House::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_House::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_House::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_House::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_House::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_House::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_House::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_House::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_House::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_House::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_House::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_House::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_House::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_House::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_House::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_House::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_House::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_House::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_House::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_House::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_House::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_House::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_House::Get_maxpopulation()	{		return (int16)m_maxpopulation_i16;}
	void Sys_T_House::Set_maxpopulation(int16 v)
	{
		m_maxpopulation_i16=v;
	}

	Sys_T_HQ_id_t Sys_T_HQ::Get_isid()	{		return (Sys_T_HQ_id_t)m_isid_i16;}
	void Sys_T_HQ::Set_isid(uint16 v)
	{
		m_isid_i16=v;
	}

	tcstr Sys_T_HQ::Get_client_file()	{		return (tcstr)m_client_file_t256;}
	void Sys_T_HQ::Set_client_file(tcstr v)
	{
		if(!v){ throw _T("Sys_T_HQ::Set_client_file( val = NULL )");}
		nTR_net::jSetter(m_client_file_t256 , v, 256);
	}

	uint32 Sys_T_HQ::Get_upgradetime()	{		return (uint32)m_upgradetime_i32;}
	void Sys_T_HQ::Set_upgradetime(uint32 v)
	{
		m_upgradetime_i32=v;
	}

	int16 Sys_T_HQ::Get_tree_num()	{		return (int16)m_tree_num_i16;}
	void Sys_T_HQ::Set_tree_num(int16 v)
	{
		m_tree_num_i16=v;
	}

	int16 Sys_T_HQ::Get_stone_num()	{		return (int16)m_stone_num_i16;}
	void Sys_T_HQ::Set_stone_num(int16 v)
	{
		m_stone_num_i16=v;
	}

	int16 Sys_T_HQ::Get_iron_num()	{		return (int16)m_iron_num_i16;}
	void Sys_T_HQ::Set_iron_num(int16 v)
	{
		m_iron_num_i16=v;
	}

	int16 Sys_T_HQ::Get_silk_num()	{		return (int16)m_silk_num_i16;}
	void Sys_T_HQ::Set_silk_num(int16 v)
	{
		m_silk_num_i16=v;
	}

	int16 Sys_T_HQ::Get_population_num()	{		return (int16)m_population_num_i16;}
	void Sys_T_HQ::Set_population_num(int16 v)
	{
		m_population_num_i16=v;
	}

	int16 Sys_T_HQ::Get_maxbuild()	{		return (int16)m_maxbuild_i16;}
	void Sys_T_HQ::Set_maxbuild(int16 v)
	{
		m_maxbuild_i16=v;
	}

	int16 Sys_T_HQ::Get_downlevel()	{		return (int16)m_downlevel_i16;}
	void Sys_T_HQ::Set_downlevel(int16 v)
	{
		m_downlevel_i16=v;
	}

	int16 Sys_T_HQ::Get_treereturn()	{		return (int16)m_treereturn_i16;}
	void Sys_T_HQ::Set_treereturn(int16 v)
	{
		m_treereturn_i16=v;
	}

	int16 Sys_T_HQ::Get_stonereturn()	{		return (int16)m_stonereturn_i16;}
	void Sys_T_HQ::Set_stonereturn(int16 v)
	{
		m_stonereturn_i16=v;
	}

	int16 Sys_T_HQ::Get_ironreturn()	{		return (int16)m_ironreturn_i16;}
	void Sys_T_HQ::Set_ironreturn(int16 v)
	{
		m_ironreturn_i16=v;
	}

	int16 Sys_T_HQ::Get_silkreturn()	{		return (int16)m_silkreturn_i16;}
	void Sys_T_HQ::Set_silkreturn(int16 v)
	{
		m_silkreturn_i16=v;
	}

	int16 Sys_T_HQ::Get_populationreturn()	{		return (int16)m_populationreturn_i16;}
	void Sys_T_HQ::Set_populationreturn(int16 v)
	{
		m_populationreturn_i16=v;
	}

	int16 Sys_T_HQ::Get_getgold()	{		return (int16)m_getgold_i16;}
	void Sys_T_HQ::Set_getgold(int16 v)
	{
		m_getgold_i16=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_Bar> g_Sys_T_Bar;


void Sys_T_Bar::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_Bar_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_hideHero(nTR_net::StringToVal<int16>(out[15]));
	Set_resettime(nTR_net::StringToVal<uint32>(out[16]));
	Set_itemnum(nTR_net::StringToVal<int16>(out[17]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_Barrack> g_Sys_T_Barrack;


void Sys_T_Barrack::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_Barrack_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_s_p_speed(nTR_net::StringToVal<int16>(out[15]));
	Set_s_p_cost(nTR_net::StringToVal<int16>(out[16]));
	Set_s_output(nTR_net::StringToVal<int16>(out[17]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_Camp> g_Sys_T_Camp;


void Sys_T_Camp::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_Camp_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_f_r_spend(nTR_net::StringToVal<int16>(out[15]));
	Set_f_storage(nTR_net::StringToVal<int32>(out[16]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_Depot> g_Sys_T_Depot;


void Sys_T_Depot::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_Depot_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_storage(nTR_net::StringToVal<int32>(out[15]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_Farm> g_Sys_T_Farm;


void Sys_T_Farm::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_Farm_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_foodoutput(nTR_net::StringToVal<int16>(out[15]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_House> g_Sys_T_House;


void Sys_T_House::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_House_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_maxpopulation(nTR_net::StringToVal<int16>(out[15]));
}

TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_T_HQ> g_Sys_T_HQ;


void Sys_T_HQ::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_isid(nTR_net::StringToVal<Sys_T_HQ_id_t>(out[0]));
	Set_client_file(nUNI::scb1024_t(out[1]).getT());
	Set_upgradetime(nTR_net::StringToVal<uint32>(out[2]));
	Set_tree_num(nTR_net::StringToVal<int16>(out[3]));
	Set_stone_num(nTR_net::StringToVal<int16>(out[4]));
	Set_iron_num(nTR_net::StringToVal<int16>(out[5]));
	Set_silk_num(nTR_net::StringToVal<int16>(out[6]));
	Set_population_num(nTR_net::StringToVal<int16>(out[7]));
	Set_maxbuild(nTR_net::StringToVal<int16>(out[8]));
	Set_downlevel(nTR_net::StringToVal<int16>(out[9]));
	Set_treereturn(nTR_net::StringToVal<int16>(out[10]));
	Set_stonereturn(nTR_net::StringToVal<int16>(out[11]));
	Set_ironreturn(nTR_net::StringToVal<int16>(out[12]));
	Set_silkreturn(nTR_net::StringToVal<int16>(out[13]));
	Set_populationreturn(nTR_net::StringToVal<int16>(out[14]));
	Set_getgold(nTR_net::StringToVal<int16>(out[15]));
}

void Sys_T_Bar::jDebugPrint()
{
	for_each_nAQ_Sys_T_Bar_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_Barrack::jDebugPrint()
{
	for_each_nAQ_Sys_T_Barrack_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_Camp::jDebugPrint()
{
	for_each_nAQ_Sys_T_Camp_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_Depot::jDebugPrint()
{
	for_each_nAQ_Sys_T_Depot_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_Farm::jDebugPrint()
{
	for_each_nAQ_Sys_T_Farm_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_House::jDebugPrint()
{
	for_each_nAQ_Sys_T_House_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Sys_T_HQ::jDebugPrint()
{
	for_each_nAQ_Sys_T_HQ_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	db_uid_type_ref Use_T_Output::Get_to_uid()	{		return (db_uid_type_ref)m_to_uid_i64;}
	void Use_T_Output::Set_to_uid(db_uid_type_ref v)
	{
		m_to_uid_i64=v;
	}

	db_uid_type_ref Use_T_Output::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_T_Output::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	db_uid_type_ref Use_T_Output::Get_tuid()	{		return (db_uid_type_ref)m_tuid_i64;}
	void Use_T_Output::Set_tuid(db_uid_type_ref v)
	{
		m_tuid_i64=v;
	}

	EBuildType Use_T_Output::Get_build_type()	{		return (EBuildType)m_build_type_e;}
	void Use_T_Output::Set_build_type(EBuildType v)
	{
		if(v<eBEGIN_EBuildType || v>=eEND_EBuildType)
		{
			GetjILog()->Error(_T("Use_T_Output::Set_build_type(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EBuildType,eEND_EBuildType,v);
		}
		m_build_type_e=v;
	}

	db_uid_type_ref Use_T_Output::Get_huid()	{		return (db_uid_type_ref)m_huid_i64;}
	void Use_T_Output::Set_huid(db_uid_type_ref v)
	{
		m_huid_i64=v;
	}

	EOutput Use_T_Output::Get_output()	{		return (EOutput)m_output_e;}
	void Use_T_Output::Set_output(EOutput v)
	{
		if(v<eBEGIN_EOutput || v>=eEND_EOutput)
		{
			GetjILog()->Error(_T("Use_T_Output::Set_output(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EOutput,eEND_EOutput,v);
		}
		m_output_e=v;
	}

	int32 Use_T_Output::Get_amount()	{		return (int32)m_amount_i32;}
	void Use_T_Output::Set_amount(int32 v)
	{
		m_amount_i32=v;
	}

	SYSTEMTIME_REF Use_T_Output::Get_finish_time()	{		return (SYSTEMTIME_REF)m_finish_time_tm;}
	void Use_T_Output::Set_finish_time(const SYSTEMTIME_REF v)
	{
		m_finish_time_tm=v;
	}

	db_uid_type_ref Use_Town::Get_tuid()	{		return (db_uid_type_ref)m_tuid_i64;}
	void Use_Town::Set_tuid(db_uid_type_ref v)
	{
		m_tuid_i64=v;
	}

	db_uid_type_ref Use_Town::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_Town::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	wcstr Use_Town::Get_name()	{		return (wcstr)m_name_w32;}
	void Use_Town::Set_name(wcstr v)
	{
		if(!v){ throw _T("Use_Town::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_w32 , v, 32);
	}

	Sys_Castle_id_t Use_Town::Get_castle_sid()	{		return (Sys_Castle_id_t)m_castle_sid_i16;}
	void Use_Town::Set_castle_sid(uint16 v)
	{
		m_castle_sid_i16=v;
	}

	Sys_TownPos_id_t Use_Town::Get_townpos_sid()	{		return (Sys_TownPos_id_t)m_townpos_sid_u16;}
	void Use_Town::Set_townpos_sid(uint16 v)
	{
		m_townpos_sid_u16=v;
	}

	uint32 Use_Town::Get_village_con()	{		return (uint32)m_village_con_i32;}
	void Use_Town::Set_village_con(uint32 v)
	{
		m_village_con_i32=v;
	}

	db_uid_type_ref Use_Town::Get_town_hero_huid()	{		return (db_uid_type_ref)m_town_hero_huid_i64;}
	void Use_Town::Set_town_hero_huid(db_uid_type_ref v)
	{
		m_town_hero_huid_i64=v;
	}

	int32 Use_Town::Get_gold_num()	{		return (int32)m_gold_num_i32;}
	void Use_Town::Set_gold_num(int32 v)
	{
		if(v<0) v = 0;
		m_gold_num_i32=v;
	}

	int32 Use_Town::Get_food_num()	{		return (int32)m_food_num_i32;}
	void Use_Town::Set_food_num(int32 v)
	{
		if(v<0) v = 0;
		m_food_num_i32=v;
	}

	int32 Use_Town::Get_tree_num()	{		return (int32)m_tree_num_i32;}
	void Use_Town::Set_tree_num(int32 v)
	{
		m_tree_num_i32=v;
	}

	int32 Use_Town::Get_stone_num()	{		return (int32)m_stone_num_i32;}
	void Use_Town::Set_stone_num(int32 v)
	{
		m_stone_num_i32=v;
	}

	int32 Use_Town::Get_iron_num()	{		return (int32)m_iron_num_i32;}
	void Use_Town::Set_iron_num(int32 v)
	{
		m_iron_num_i32=v;
	}

	int32 Use_Town::Get_silk_num()	{		return (int32)m_silk_num_i32;}
	void Use_Town::Set_silk_num(int32 v)
	{
		m_silk_num_i32=v;
	}

	int32 Use_Town::Get_population_num()	{		return (int32)m_population_num_i32;}
	void Use_Town::Set_population_num(int32 v)
	{
		if(v<0) v = 0;
		m_population_num_i32=v;
	}

	int32 Use_Town::Get_soldier_num()	{		return (int32)m_soldier_num_i32;}
	void Use_Town::Set_soldier_num(int32 v)
	{
		m_soldier_num_i32=v;
	}

	int32 Use_Town::Get_pike_num()	{		return (int32)m_pike_num_i32;}
	void Use_Town::Set_pike_num(int32 v)
	{
		m_pike_num_i32=v;
	}

	int32 Use_Town::Get_heavy_num()	{		return (int32)m_heavy_num_i32;}
	void Use_Town::Set_heavy_num(int32 v)
	{
		m_heavy_num_i32=v;
	}

	int32 Use_Town::Get_halberd_num()	{		return (int32)m_halberd_num_i32;}
	void Use_Town::Set_halberd_num(int32 v)
	{
		m_halberd_num_i32=v;
	}

	int32 Use_Town::Get_bow_num()	{		return (int32)m_bow_num_i32;}
	void Use_Town::Set_bow_num(int32 v)
	{
		m_bow_num_i32=v;
	}

	int32 Use_Town::Get_crossbow_num()	{		return (int32)m_crossbow_num_i32;}
	void Use_Town::Set_crossbow_num(int32 v)
	{
		m_crossbow_num_i32=v;
	}

	int32 Use_Town::Get_bowgun_num()	{		return (int32)m_bowgun_num_i32;}
	void Use_Town::Set_bowgun_num(int32 v)
	{
		m_bowgun_num_i32=v;
	}

	int32 Use_Town::Get_ballista_num()	{		return (int32)m_ballista_num_i32;}
	void Use_Town::Set_ballista_num(int32 v)
	{
		m_ballista_num_i32=v;
	}

	int32 Use_Town::Get_chariot_num()	{		return (int32)m_chariot_num_i32;}
	void Use_Town::Set_chariot_num(int32 v)
	{
		m_chariot_num_i32=v;
	}

	int32 Use_Town::Get_wagon_num()	{		return (int32)m_wagon_num_i32;}
	void Use_Town::Set_wagon_num(int32 v)
	{
		m_wagon_num_i32=v;
	}

	int32 Use_Town::Get_horse_num()	{		return (int32)m_horse_num_i32;}
	void Use_Town::Set_horse_num(int32 v)
	{
		m_horse_num_i32=v;
	}

	int32 Use_Town::Get_wheelbarrow_num()	{		return (int32)m_wheelbarrow_num_i32;}
	void Use_Town::Set_wheelbarrow_num(int32 v)
	{
		m_wheelbarrow_num_i32=v;
	}

	int32 Use_Town::Get_cart_num()	{		return (int32)m_cart_num_i32;}
	void Use_Town::Set_cart_num(int32 v)
	{
		m_cart_num_i32=v;
	}

	int32 Use_Town::Get_ladder_num()	{		return (int32)m_ladder_num_i32;}
	void Use_Town::Set_ladder_num(int32 v)
	{
		m_ladder_num_i32=v;
	}

	int32 Use_Town::Get_ram_num()	{		return (int32)m_ram_num_i32;}
	void Use_Town::Set_ram_num(int32 v)
	{
		m_ram_num_i32=v;
	}

	int32 Use_Town::Get_tower_num()	{		return (int32)m_tower_num_i32;}
	void Use_Town::Set_tower_num(int32 v)
	{
		m_tower_num_i32=v;
	}

	int32 Use_Town::Get_trebuchet_num()	{		return (int32)m_trebuchet_num_i32;}
	void Use_Town::Set_trebuchet_num(int32 v)
	{
		m_trebuchet_num_i32=v;
	}

	wcstr Use_Town::Get_help()	{		return (wcstr)m_help_w64;}
	void Use_Town::Set_help(wcstr v)
	{
		if(!v){ throw _T("Use_Town::Set_help( val = NULL )");}
		nTR_net::jSetter(m_help_w64 , v, 64);
	}

	db_uid_type_ref Use_User::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_User::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	acstr Use_User::Get_name()	{		return (acstr)m_name_a64;}
	void Use_User::Set_name(acstr v)
	{
		if(!v){ throw _T("Use_User::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_a64 , v, 64);
	}

	acstr Use_User::Get_pwd()	{		return (acstr)m_pwd_a64;}
	void Use_User::Set_pwd(acstr v)
	{
		if(!v){ throw _T("Use_User::Set_pwd( val = NULL )");}
		nTR_net::jSetter(m_pwd_a64 , v, 64);
	}

	wcstr Use_User::Get_nic_name()	{		return (wcstr)m_nic_name_w32;}
	void Use_User::Set_nic_name(wcstr v)
	{
		if(!v){ throw _T("Use_User::Set_nic_name( val = NULL )");}
		nTR_net::jSetter(m_nic_name_w32 , v, 32);
	}

	SYSTEMTIME_REF Use_User::Get_last_login_time()	{		return (SYSTEMTIME_REF)m_last_login_time_tm;}
	void Use_User::Set_last_login_time(const SYSTEMTIME_REF v)
	{
		m_last_login_time_tm=v;
	}

	SYSTEMTIME_REF Use_User::Get_last_logout_time()	{		return (SYSTEMTIME_REF)m_last_logout_time_tm;}
	void Use_User::Set_last_logout_time(const SYSTEMTIME_REF v)
	{
		m_last_logout_time_tm=v;
	}

	acstr Use_User::Get_joined_world()	{		return (acstr)m_joined_world_a32;}
	void Use_User::Set_joined_world(acstr v)
	{
		if(!v){ throw _T("Use_User::Set_joined_world( val = NULL )");}
		nTR_net::jSetter(m_joined_world_a32 , v, 32);
	}

	db_uid_type_ref Use_User::Get_capital_tuid()	{		return (db_uid_type_ref)m_capital_tuid_i64;}
	void Use_User::Set_capital_tuid(db_uid_type_ref v)
	{
		m_capital_tuid_i64=v;
	}

	uint32 Use_User::Get_faim()	{		return (uint32)m_faim_i32;}
	void Use_User::Set_faim(uint32 v)
	{
		m_faim_i32=v;
	}

	uint32 Use_User::Get_bad_faim()	{		return (uint32)m_bad_faim_i32;}
	void Use_User::Set_bad_faim(uint32 v)
	{
		m_bad_faim_i32=v;
	}

	cash_money_t Use_User::Get_cash_money()	{		return (cash_money_t)m_cash_money_i32;}
	void Use_User::Set_cash_money(int32 v)
	{
		m_cash_money_i32=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
void Use_T_Output::jDebugPrint()
{
	for_each_nAQ_Use_T_Output_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_Town::jDebugPrint()
{
	for_each_nAQ_Use_Town_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

void Use_User::jDebugPrint()
{
	for_each_nAQ_Use_User_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

#ifdef TR_SERVER_SIDE_CODE

	for_each_nAQ_sam_user_Use_STRUCT_LIST(jEXCEL_SQL_BIND_FUNC_DEFINE);
#endif //TR_SERVER_SIDE_CODE


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_Bar> Sys_T_Bar_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_Bar_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_Barrack> Sys_T_Barrack_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_Barrack_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_Camp> Sys_T_Camp_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_Camp_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_Depot> Sys_T_Depot_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_Depot_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_Farm> Sys_T_Farm_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_Farm_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_House> Sys_T_House_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_House_csv_file_t);

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_T_HQ> Sys_T_HQ_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_T_HQ_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_sam_user)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_sam_user_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_EBuildType_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EOutput_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_T_Bar_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_Bar*(int index)","array operator")
				jSQ_fn(find,"Sys_T_Bar*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_Bar)
			for_each_nAQ_Sys_T_Bar_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_Bar)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_Bar,g_Sys_T_Bar);

			jSQ_Interface(Sys_T_Barrack_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_Barrack*(int index)","array operator")
				jSQ_fn(find,"Sys_T_Barrack*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_Barrack)
			for_each_nAQ_Sys_T_Barrack_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_Barrack)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_Barrack,g_Sys_T_Barrack);

			jSQ_Interface(Sys_T_Camp_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_Camp*(int index)","array operator")
				jSQ_fn(find,"Sys_T_Camp*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_Camp)
			for_each_nAQ_Sys_T_Camp_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_Camp)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_Camp,g_Sys_T_Camp);

			jSQ_Interface(Sys_T_Depot_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_Depot*(int index)","array operator")
				jSQ_fn(find,"Sys_T_Depot*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_Depot)
			for_each_nAQ_Sys_T_Depot_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_Depot)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_Depot,g_Sys_T_Depot);

			jSQ_Interface(Sys_T_Farm_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_Farm*(int index)","array operator")
				jSQ_fn(find,"Sys_T_Farm*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_Farm)
			for_each_nAQ_Sys_T_Farm_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_Farm)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_Farm,g_Sys_T_Farm);

			jSQ_Interface(Sys_T_House_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_House*(int index)","array operator")
				jSQ_fn(find,"Sys_T_House*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_House)
			for_each_nAQ_Sys_T_House_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_House)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_House,g_Sys_T_House);

			jSQ_Interface(Sys_T_HQ_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_T_HQ*(int index)","array operator")
				jSQ_fn(find,"Sys_T_HQ*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_T_HQ)
			for_each_nAQ_Sys_T_HQ_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_T_HQ)
			jSQ_end();
			jSQ_g_var(&g_Sys_T_HQ,g_Sys_T_HQ);

			jSQ_Interface(Use_T_Output)
			for_each_nAQ_Use_T_Output_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_T_Output)
			jSQ_end();

			jSQ_Interface(Use_Town)
			for_each_nAQ_Use_Town_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Town)
			jSQ_end();

			jSQ_Interface(Use_User)
			for_each_nAQ_Use_User_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_User)
			jSQ_end();

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

