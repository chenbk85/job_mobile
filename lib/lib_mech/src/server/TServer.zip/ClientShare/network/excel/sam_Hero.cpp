/*------------------------------------------------------------
Create By Z:\job_sam\bin\server\xls\bin\URelease\Excel_Converter.exe  
Version = 1,013 
Date =  Tue Mar  9 20:51:21 2010

command line : 
Excel_Converter.exe Z:\job_sam\src\share\network\excel\sam_hero.txt Z:\job_sam\src\share\network\excel\aq_enum.txt 

-------------------------------------------------------------*/

#include "stdafx.h"
#include "sam_hero.h"


for_each_nAQ_sam_hero_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE);
namespace nTR_excel { namespace nAQ {

TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EDeckYear[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EDeckYear_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroCategory[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroCategory_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroEngagementtype[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroEngagementtype_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroFacetype[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroFacetype_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroPersonality[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroPersonality_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroSex[] = 
{
	{ 2 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroSex_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};
TR_SERVER_LIB_API nTR_net::jEnumString g_ES_EHeroWorkState[] = 
{
	{ 4 , 0, 0},
	#ifdef jEXCEL_ENUM_STRING_CPP_CODE
		for_each_nAQ_EHeroWorkState_ENUM_FIELD(jEXCEL_ENUM_STRING_CPP_CODE)
	#endif // jEXCEL_ENUM_STRING_CPP_CODE
};

#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	Sys_Hero_id_t Sys_Hero::Get_hsid()	{		return (Sys_Hero_id_t)m_hsid_u16;}
	void Sys_Hero::Set_hsid(uint16 v)
	{
		m_hsid_u16=v;
	}

	EHeroCategory Sys_Hero::Get_category()	{		return (EHeroCategory)m_category_e;}
	void Sys_Hero::Set_category(EHeroCategory v)
	{
		if(v<eBEGIN_EHeroCategory || v>=eEND_EHeroCategory)
		{
			GetjILog()->Error(_T("Sys_Hero::Set_category(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EHeroCategory,eEND_EHeroCategory,v);
		}
		m_category_e=v;
	}

	EDeckYear Sys_Hero::Get_deck_year()	{		return (EDeckYear)m_deck_year_e;}
	void Sys_Hero::Set_deck_year(EDeckYear v)
	{
		if(v<eBEGIN_EDeckYear || v>=eEND_EDeckYear)
		{
			GetjILog()->Error(_T("Sys_Hero::Set_deck_year(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EDeckYear,eEND_EDeckYear,v);
		}
		m_deck_year_e=v;
	}

	tcstr Sys_Hero::Get_name()	{		return (tcstr)m_name_t32;}
	void Sys_Hero::Set_name(tcstr v)
	{
		if(!v){ throw _T("Sys_Hero::Set_name( val = NULL )");}
		nTR_net::jSetter(m_name_t32 , v, 32);
	}

	wcstr Sys_Hero::Get_name_kor()	{		return (wcstr)m_name_kor_w32;}
	void Sys_Hero::Set_name_kor(wcstr v)
	{
		if(!v){ throw _T("Sys_Hero::Set_name_kor( val = NULL )");}
		nTR_net::jSetter(m_name_kor_w32 , v, 32);
	}

	tcstr Sys_Hero::Get_image_file()	{		return (tcstr)m_image_file_t256;}
	void Sys_Hero::Set_image_file(tcstr v)
	{
		if(!v){ throw _T("Sys_Hero::Set_image_file( val = NULL )");}
		nTR_net::jSetter(m_image_file_t256 , v, 256);
	}

	int32 Sys_Hero::Get_grade()	{		return (int32)m_grade_i32;}
	void Sys_Hero::Set_grade(int32 v)
	{
		m_grade_i32=v;
	}

	int32 Sys_Hero::Get_age()	{		return (int32)m_age_i32;}
	void Sys_Hero::Set_age(int32 v)
	{
		if(v>99) v = 99;
		if(v<1) v = 1;
		m_age_i32=v;
	}

	int32 Sys_Hero::Get_leadership()	{		return (int32)m_leadership_i32;}
	void Sys_Hero::Set_leadership(int32 v)
	{
		if(v>200) v = 200;
		if(v<1) v = 1;
		m_leadership_i32=v;
	}

	int32 Sys_Hero::Get_power()	{		return (int32)m_power_i32;}
	void Sys_Hero::Set_power(int32 v)
	{
		if(v>200) v = 200;
		if(v<1) v = 1;
		m_power_i32=v;
	}

	int32 Sys_Hero::Get_intelligent()	{		return (int32)m_intelligent_i32;}
	void Sys_Hero::Set_intelligent(int32 v)
	{
		if(v>200) v = 200;
		if(v<1) v = 1;
		m_intelligent_i32=v;
	}

	int32 Sys_Hero::Get_politic()	{		return (int32)m_politic_i32;}
	void Sys_Hero::Set_politic(int32 v)
	{
		if(v>200) v = 200;
		if(v<1) v = 1;
		m_politic_i32=v;
	}

	int32 Sys_Hero::Get_charm()	{		return (int32)m_charm_i32;}
	void Sys_Hero::Set_charm(int32 v)
	{
		if(v>200) v = 200;
		if(v<1) v = 1;
		m_charm_i32=v;
	}

	bool Sys_Hero::Get_is_male()	{		return (bool)m_is_male_b;}
	void Sys_Hero::Set_is_male(bool v)
	{
		m_is_male_b=v;
	}

	EHeroPersonality Sys_Hero::Get_personality()	{		return (EHeroPersonality)m_personality_e;}
	void Sys_Hero::Set_personality(EHeroPersonality v)
	{
		if(v<eBEGIN_EHeroPersonality || v>=eEND_EHeroPersonality)
		{
			GetjILog()->Error(_T("Sys_Hero::Set_personality(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EHeroPersonality,eEND_EHeroPersonality,v);
		}
		m_personality_e=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
TR_SERVER_LIB_API nMech::nUtil::jCSV_File<Sys_Hero> g_Sys_Hero;


void Sys_Hero::ReadCSV(const WCHAR* szLine)
{
	std::vector<std::wstring> out;
	nMech::nString::jSplitW(szLine, L",", out);
	if(out.size() != eSTRUCT_COUNT)
	{
		GetjILog()->Error(jFUNC1 _T("parse size error(%d!=eSTRUCT_COUNT(%d) szLine=%s"),out.size(),eSTRUCT_COUNT,jT(szLine) );
	}
	Set_hsid(nTR_net::StringToVal<Sys_Hero_id_t>(out[0]));
	Set_category(nTR_net::StringToVal(out[1],nAQ::eBEGIN_EHeroCategory));
	Set_deck_year(nTR_net::StringToVal(out[2],nAQ::eBEGIN_EDeckYear));
	Set_name(nUNI::scb1024_t(out[3]).getT());
	Set_name_kor(nUNI::scb1024_t(out[4]).getW());
	Set_image_file(nUNI::scb1024_t(out[5]).getT());
	Set_grade(nTR_net::StringToVal<int32>(out[6]));
	Set_age(nTR_net::StringToVal<int32>(out[7]));
	Set_leadership(nTR_net::StringToVal<int32>(out[8]));
	Set_power(nTR_net::StringToVal<int32>(out[9]));
	Set_intelligent(nTR_net::StringToVal<int32>(out[10]));
	Set_politic(nTR_net::StringToVal<int32>(out[11]));
	Set_charm(nTR_net::StringToVal<int32>(out[12]));
	Set_is_male(nTR_net::StringToVal<bool>(out[13]));
	Set_personality(nTR_net::StringToVal(out[14],nAQ::eBEGIN_EHeroPersonality));
}

void Sys_Hero::jDebugPrint()
{
	for_each_nAQ_Sys_Hero_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}


#ifdef jEXCEL_STRUCT_GETTER_SETTER_GEN
#ifdef TR_SERVER_SIDE_CODE
	db_uid_type_ref Use_Hero::Get_huid()	{		return (db_uid_type_ref)m_huid_i64;}
	void Use_Hero::Set_huid(db_uid_type_ref v)
	{
		m_huid_i64=v;
	}

	Sys_Hero_id_t Use_Hero::Get_hsid()	{		return (Sys_Hero_id_t)m_hsid_u16;}
	void Use_Hero::Set_hsid(uint16 v)
	{
		m_hsid_u16=v;
	}

	db_uid_type_ref Use_Hero::Get_uid()	{		return (db_uid_type_ref)m_uid_i64;}
	void Use_Hero::Set_uid(db_uid_type_ref v)
	{
		m_uid_i64=v;
	}

	db_uid_type_ref Use_Hero::Get_tuid()	{		return (db_uid_type_ref)m_tuid_i64;}
	void Use_Hero::Set_tuid(db_uid_type_ref v)
	{
		m_tuid_i64=v;
	}

	int32 Use_Hero::Get_exp_domestic()	{		return (int32)m_exp_domestic_i32;}
	void Use_Hero::Set_exp_domestic(int32 v)
	{
		if(v<0) v = 0;
		m_exp_domestic_i32=v;
	}

	int32 Use_Hero::Get_exp_combat()	{		return (int32)m_exp_combat_i32;}
	void Use_Hero::Set_exp_combat(int32 v)
	{
		if(v<0) v = 0;
		m_exp_combat_i32=v;
	}

	int32 Use_Hero::Get_exp_total()	{		return (int32)m_exp_total_i32;}
	void Use_Hero::Set_exp_total(int32 v)
	{
		if(v<0) v = 0;
		m_exp_total_i32=v;
	}

	int32 Use_Hero::Get_level()	{		return (int32)m_level_i32;}
	void Use_Hero::Set_level(int32 v)
	{
		if(v<1) v = 1;
		m_level_i32=v;
	}

	EHeroWorkState Use_Hero::Get_work_state()	{		return (EHeroWorkState)m_work_state_e;}
	void Use_Hero::Set_work_state(EHeroWorkState v)
	{
		if(v<eBEGIN_EHeroWorkState || v>=eEND_EHeroWorkState)
		{
			GetjILog()->Error(_T("Use_Hero::Set_work_state(enum minmax(%d,%d)error, val=%d")
				,eBEGIN_EHeroWorkState,eEND_EHeroWorkState,v);
		}
		m_work_state_e=v;
	}

	int32 Use_Hero::Get_slot_horse()	{		return (int32)m_slot_horse_i32;}
	void Use_Hero::Set_slot_horse(int32 v)
	{
		m_slot_horse_i32=v;
	}

	int32 Use_Hero::Get_slot_weapon()	{		return (int32)m_slot_weapon_i32;}
	void Use_Hero::Set_slot_weapon(int32 v)
	{
		m_slot_weapon_i32=v;
	}

	int32 Use_Hero::Get_slot_armor()	{		return (int32)m_slot_armor_i32;}
	void Use_Hero::Set_slot_armor(int32 v)
	{
		m_slot_armor_i32=v;
	}

	int32 Use_Hero::Get_slot_accessory1()	{		return (int32)m_slot_accessory1_i32;}
	void Use_Hero::Set_slot_accessory1(int32 v)
	{
		m_slot_accessory1_i32=v;
	}

	int32 Use_Hero::Get_slot_accessory2()	{		return (int32)m_slot_accessory2_i32;}
	void Use_Hero::Set_slot_accessory2(int32 v)
	{
		m_slot_accessory2_i32=v;
	}

#endif //TR_SERVER_SIDE_CODE

#endif // jEXCEL_STRUCT_GETTER_SETTER_GEN
void Use_Hero::jDebugPrint()
{
	for_each_nAQ_Use_Hero_STRUCT_FIELD(jEXCEL_STRUCT_FIELD_DebugPrint);
}

#ifdef TR_SERVER_SIDE_CODE

	for_each_nAQ_sam_hero_Use_STRUCT_LIST(jEXCEL_SQL_BIND_FUNC_DEFINE);
#endif //TR_SERVER_SIDE_CODE


} //namespace nAQ 

}// namespace nTR_excel 
#ifndef jNOT_USE_SQ_BIND_CODE

	using namespace nTR_excel::nAQ;

	typedef nMech::nUtil::jCSV_File<nTR_excel::nAQ::Sys_Hero> Sys_Hero_csv_file_t;
	DECLARE_INSTANCE_TYPE(Sys_Hero_csv_file_t);

	namespace nTR_excel { namespace nAQ
	{
		jSQ_REGIST_BIND(nTR_excel_nAQ_sam_hero)
		{
			{
				SquirrelObject enumRoot= nSQ::jSQ_GetEnumTable();
				for_each_nAQ_sam_hero_ENUM(jEXCEL_SQ_bind_EnumField_BEGIN);
				for_each_nAQ_EDeckYear_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroCategory_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroEngagementtype_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroFacetype_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroPersonality_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroSex_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
				for_each_nAQ_EHeroWorkState_ENUM_FIELD(jEXCEL_SQ_bind_EnumField);
			}
			jSQ_Interface(Sys_Hero_csv_file_t)
				jSQ_fn(size,"int(void)","total size")
				jSQ_fn(at,"Sys_Hero*(int index)","array operator")
				jSQ_fn(find,"Sys_Hero*(tcstr key)","map operator")
			jSQ_end();

			jSQ_Interface(Sys_Hero)
			for_each_nAQ_Sys_Hero_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Sys_Hero)
			jSQ_end();
			jSQ_g_var(&g_Sys_Hero,g_Sys_Hero);

			jSQ_Interface(Use_Hero)
			for_each_nAQ_Use_Hero_STRUCT_FIELD(jEXCEL_SQ_TABLE_FILED_BIND);
			jEXCEL_SQ_TABLE_FUNC_BIND(Use_Hero)
			jSQ_end();

		}
	} /*namespace nAQ */ }// namespace nTR_excel 
#endif //jNOT_USE_SQ_BIND_CODE

