
void make_update_table(WCHAR*szSQL , nAQ::Use_F_Transport* p)
{
jw_sprintf(szSQL, L"UPDATE Use_F_Transport SET\
[uid]=%I64d \
,[fuid]=%I64d \
,[movetown]=%I64d \
,[finish_time]=%d-%d-%d %d:%d:%d \
 WHERE [ft_uid]=%I64d "
	,p->Get_uid()
	,p->Get_fuid()
	,p->Get_movetown()
	,p->Get_finish_time()
	,p->Get_ft_uid().m_db_id
);

}


/*
	@ft_uid	BIGINT
	,@uid	BIGINT
	,@fuid	BIGINT
	,@movetown	BIGINT
	,@finish_time	DATETIME
*/