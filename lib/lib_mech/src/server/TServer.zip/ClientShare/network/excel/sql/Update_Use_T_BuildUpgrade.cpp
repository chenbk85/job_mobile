
void make_update_Use_T_BuildUpgrade(WCHAR*szSQL , nAQ::Use_T_BuildUpgrade* p)
{
jw_sprintf(szSQL, L"UPDATE Use_T_BuildUpgrade SET\
[user_uid] = %I64d\
,[town_uid] = %d\
,[build_type] = %d\
,[finish_time] = %UNKOWN\
 WHERE [tb_uid] = %I64d "
	,p->Get_user_uid()
	,p->Get_town_uid()
	,p->Get_build_type()
	,p->Get_finish_time()
	,p->Get_tb_uid().m_db_id
);

}


/*
	@tb_uid	BIGINT
	,@user_uid	BIGINT
	,@town_uid	INT
	,@build_type	TINYINT
	,@finish_time	DATETIME
*/