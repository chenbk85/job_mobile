
void make_update_table(WCHAR*szSQL , nAQ::Use_User* p)
{
jw_sprintf(szSQL, L"UPDATE Use_User SET\
[name]='%s' \
,[pwd]='%s' \
,[nic_name]='%s' \
,[last_login_time]=%d-%d-%d %d:%d:%d \
,[last_logout_time]=%d-%d-%d %d:%d:%d \
,[joined_world]='%s' \
,[capital_tuid]=%I64d \
,[faim]=%d \
,[bad_faim]=%d \
,[cash_money]=%d \
 WHERE [uid]=%I64d "
	,p->Get_name()
	,p->Get_pwd()
	,p->Get_nic_name()
	,p->Get_last_login_time()
	,p->Get_last_logout_time()
	,p->Get_joined_world()
	,p->Get_capital_tuid()
	,p->Get_faim()
	,p->Get_bad_faim()
	,p->Get_cash_money()
	,p->Get_uid().m_db_id
);

}


/*
	@uid	BIGINT
	,@name	VARCHAR(64)
	,@pwd	VARCHAR(64)
	,@nic_name	NVARCHAR(32)
	,@last_login_time	DATETIME
	,@last_logout_time	DATETIME
	,@joined_world	VARCHAR(32)
	,@capital_tuid	BIGINT
	,@faim	INT
	,@bad_faim	INT
	,@cash_money	INT
*/