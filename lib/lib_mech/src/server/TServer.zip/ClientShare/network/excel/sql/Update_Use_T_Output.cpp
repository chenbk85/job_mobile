
void make_update_table(WCHAR*szSQL , nAQ::Use_T_Output* p)
{
jw_sprintf(szSQL, L"UPDATE Use_T_Output SET\
[uid]=%I64d \
,[tuid]=%I64d \
,[build_type]=%d \
,[huid]=%I64d \
,[output]=%d \
,[amount]=%d \
,[finish_time]=%d-%d-%d %d:%d:%d \
 WHERE [to_uid]=%I64d "
	,p->Get_uid()
	,p->Get_tuid()
	,p->Get_build_type()
	,p->Get_huid()
	,p->Get_output()
	,p->Get_amount()
	,p->Get_finish_time()
	,p->Get_to_uid().m_db_id
);

}


/*
	@to_uid	BIGINT
	,@uid	BIGINT
	,@tuid	BIGINT
	,@build_type	TINYINT
	,@huid	BIGINT
	,@output	TINYINT
	,@amount	INT
	,@finish_time	DATETIME
*/