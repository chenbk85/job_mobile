/* file : AqConnectedServerNode.cpp
Coder : by icandoit ( mech12@nate.com)
Date : 2009-07-14 15:42:03
comp.: wiki.aqrius.com
title : 
desc : 

*/

#include "stdafx.h"
#include "AqServerNode.h"

jDEFINE_YVECTOR_MANAGER(AqConnectedServerNode, 256,10);

