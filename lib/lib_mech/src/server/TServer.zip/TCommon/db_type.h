/* file : common_test_server.h
Coder : by icandoit ( mech12@nate.com)
Date : 2008-03-06 10:56:59
comp.: www.actoz.com
title : 
desc : 

*/

#ifndef __db_type_hlksdjfoiwejfk__
#define __db_type_hlksdjfoiwejfk__
#pragma once


#include "header/nNET_Stream.h"
#include "interface/net/Excel_code_util.h"
#include "network/net_Setter.h"
#include "network/excel/aq_enum.h"

for_each_nAQ_aq_enum_ENUM(jEXCEL_SQ_DECLARE_ENUM_TYPE_PROTO);

//PROTOS_ENUM_TYPE_csv(ETownClass);

#endif // __db_type_hlksdjfoiwejfk__

