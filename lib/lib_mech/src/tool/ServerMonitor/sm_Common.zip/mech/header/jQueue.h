/* file : jQueue.h
Coder : by icandoit (mech12@nate.com, icandoit@n_jGame_c.net)
Date : 2006-08-11 13:38:57
title : 
desc : 

*/

#ifndef __jQueue_header__
#define __jQueue_header__
#pragma once

template<typename T>
class jCircleQueue
{
public:
	enum EState 
	{
		eNO_CIRCLED
		,eCIRCLED
	};
	int m_it;
	int m_iNewInsertPos;
	int m_iTot;
	T* m_pArray;
	EState m_eFlag;
public:
	jCircleQueue()
	{ 
		m_eFlag=eNO_CIRCLED; 
		m_pArray=0; m_iNewInsertPos=0;
	}
	jCircleQueue(int iCnt)
	{ 
		m_iTot = iCnt;
		m_eFlag=eNO_CIRCLED; 
		m_pArray = new T[m_iTot]; m_iNewInsertPos=0;
	}
	void Init(int iCnt)
	{ 
		Release() ; 
		m_iTot=iCnt;  m_pArray = new T[iCnt] ; m_iNewInsertPos=0;
	}
	void Release()
	{ 
		SAFE_DELETE_ARRAY(m_pArray);
		m_iTot =0; m_iNewInsertPos = 0;
		m_eFlag=eNO_CIRCLED;
	}

	int capacity(){ return m_iTot;}
	int size()
	{ 
		if(m_eFlag==eCIRCLED) return m_iTot;
		return m_iNewInsertPos;
	}
	
	T* push_back()
	{ 
		int i = m_iNewInsertPos; 
		assert(i>=0 && i<m_iTot);
		++m_iNewInsertPos;
		if(m_iNewInsertPos>=m_iTot )
		{
			m_eFlag=eCIRCLED;
			m_iNewInsertPos=0;
		}
		return m_pArray + i;
	}
	
	T* GotoBegin()
	{
		if(m_eFlag==eNO_CIRCLED)
		{
			if(m_iNewInsertPos ==0)
			{
				m_it =-2;
				return 0;
			}
			m_it = 0;
		}
		else
		{
			m_it=m_iNewInsertPos;
		}
		return m_pArray + m_it;
	}

	T* GotoBeginNext()
	{
		if(m_it==-2) return 0;

		++m_it;

		if(m_eFlag==eNO_CIRCLED)
		{
			if( m_it >=m_iNewInsertPos)
				return 0;
		}
		else
		{
			if( m_it >=m_iTot) 
				m_it=0;
			if(m_it == m_iNewInsertPos)
			{
				m_it=-2;
				return 0;
			}
		}

		return m_pArray + m_it;
	}

	T* GotoEnd()
	{
		if(m_eFlag==eNO_CIRCLED)
		{
			if(m_iNewInsertPos==0)
			{
				m_it=-2;
				return 0;
			}

			m_it = m_iNewInsertPos-1;
		}
		else
		{
			m_it = m_iNewInsertPos-1;
			if(m_it<0)
				m_it = m_iTot-1;
		}
		return m_pArray + m_it;
	}
	T* GotoEndPrev()
	{
		if(m_it==-2) return 0;
		--m_it;
		if(m_eFlag == eNO_CIRCLED)
		{
			if(m_it<0)
			{
				m_it =-2;
				return 0;
			}
		}
		else
		{
			if(m_it <0)
			{
				m_it = m_iTot-1;
			}
			if(m_it == (m_iNewInsertPos-1))
			{
				m_it =-2;
				return 0;
			}
		}
		return m_pArray + m_it;
	}
	/* *_* by icandoit : 2006-08-11 15:07:08

	static void jTest()
	{
		struct _aaa
		{
			fname_t buf;
			int id;
		};
		jCircleQueue<_aaa> test(5);
		
		for( int i=0; i< 3 ; ++i)
		{
			_aaa* a = test.push_back();
			a->id = i;
			sprintf(a->buf ," id =%d",a->id);
		}

		_aaa* pA = test.GotoBegin();
		for( ; pA ; pA = test.GotBeginNext() )
		{
			printf(" %d => %s \n", pA->id, pA->buf);
		}

		for( int i=10; i< 13 ; ++i)
		{
			_aaa* a = test.push_back();
			a->id = i;
			sprintf(a->buf ," id =%d",a->id);
		}

		pA = test.GotoBegin();
		for( ; pA ; pA = test.GotBeginNext() )
		{
			printf(" %d => %s \n", pA->id, pA->buf);
		}

	}
*/ //*_* by icandoit : 2006-08-11 15:07:10

};



#endif // __jQueue_header__
