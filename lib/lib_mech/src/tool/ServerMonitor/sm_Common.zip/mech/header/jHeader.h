/* file : jHeader.h
Coder : by icandoit ( whdnrfo@gmail.com)
Date : 2010-09-07 13:02:44
comp.: t3.co.kr
title : 
desc : 

*/

#ifndef __jHeader_header__
#define __jHeader_header__
#pragma once


#include <windows.h>
#include "stdio.h"
#include "tchar.h"
#include "stdlib.h"
#include "direct.h"

#include "mech/header/jTypedef_type.h"
#include "mech/header/jInterface.h"
#include "mech/header/jRDTSC.h"
#include "mech/header/m_stltag.h"
#include "mech/header/jTypedef_func.h"

#include "mech/header/jDefine.h"
#include "mech/header/m_Stltag.h"
#include "mech/header/jtchar_util.h"
#include "mech/header/jcriticalsection.h"
#include "mech/header/UFile.h"
#include "mech/header/jFileName.h"



#endif // __jHeader_header__
