/* file : jTypedef_struct.cpp
Coder : by icandoit ( mech12@nate.com)
Date : 2006-12-13 10:37:23
comp.: pantavision.co.kr
title : 
desc : 

*/

#include "stdafx.h"
#include "jTypedef_struct.h"


