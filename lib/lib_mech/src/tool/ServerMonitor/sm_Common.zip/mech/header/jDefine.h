/* file : jDefine.h
Coder : by icandoit (mech12@nate.com)
Date : 2005-06-07 22:42:55
title : 
desc : 

*/

#ifndef __jDefine_header__
#define __jDefine_header__
#pragma once


// 32/64 Bit versions.
#define SIGN_MASK(x) ((intptr_t)(x) >> ((sizeof(size_t)*8)-1))

#ifndef _CV
#define _CV(type , var) (*(type*)(void*)&var)
#endif
#ifndef _CVP
#define _CVP(type , var) ((type*)(void*)var)
#endif

#ifndef jS
#define jS(x)  TEXT(#x)
#endif

#ifndef _jL
#define _jL
#endif

#define jFUNC _T(__FUNCTION__)
#define jFUNC1 _T(__FUNCTION__) _T(">")
#define jF jFUNC
#define jF1 jFUNC1

#define _jA(x) #x
#define _jW(x) L ## #x

#define jA(x) nUNI::scb256_t(x).getA()
#define jT(x) nUNI::scb256_t(x).getT()
#define jW(x) nUNI::scb256_t(x).getW()

//�÷��ÿ� ���� ���� 
#define jFLOAT_ZERO		1.0e-20f	//0 ���� ���ֵǴ� ��
#define jFLOAT_ERROR	1.0e-10f	// ������	

#define jNEW( x , type ) x = new type;    if( !x ) throw false
#define jNEWi( x , type, i )  x = new type[i]; if( !x ) throw false

#define jDEL(x) if(x){delete (x); x = NULL; }
#define jDELi(x) if( (x) ){delete[] (x); (x) = NULL; }
#define jDEL_REL(x) if( x ){(x)->Release();delete (x); x = NULL; }

//#define ONETIME_CALL(a) struct _##a##_{_##a##_():};_##a##_::_##a##_()
#define ONETIME_CALL(a) struct a##_{ a##_(); ~a##_(); }
#define DEBUG_HERE()  __asm int 3;  // DebugBreak()
#define MY_ASSERT(a) if(!(a)) DEBUG_HERE();

#define CLASS_CLS()			memset(this , 0 , sizeof(*this) );
#define CLASS_CLS1(p)			memset(((TCHAR*)this)+sizeof(p),0,sizeof(*this)-sizeof(p) );
#define CLASS_CLS2(p1,p2) memset(((TCHAR*)this)+sizeof(p1)+sizeof(p2),0,sizeof(*this)-sizeof(p1)-sizeof(p2) );

#define jCLEAR(X) memset(&X,0,sizeof(X));

#define FILE_LEN(fp) filelength( fileno(fp) )
#define ARRAY_SIZE(a) (sizeof(a)/sizeof(a[0])-1)
#define ArraySize(a) (sizeof(a)/sizeof(a[0]))

#define MECH_TRY try{
#define MECH_CATCH }catch(TCHAR* s){if(_tcslen(s)>255)s[255]=0; ::MessageBox(0 , s ,TEXT("MECH_CATCH") , MB_OK); } \
	catch(bool){::MessageBox(0 ,  TEXT("ERROR BOOL EXCEPTION"),TEXT("MECH_CATCH") , MB_OK);} 
#define MECH_CATCH_END catch(EMechTryType) {;}

#define ONETIME_START() struct a_{a_();};static a_ s_a_;a_::a_()
#define ONETIME_END() struct b_{b_(){}~b_();};static b_ s_b_;b_::~b_()


#define jBIT_0		0x00000001
#define jBIT_1		0x00000002
#define jBIT_2		0x00000004
#define jBIT_3		0x00000008
#define jBIT_4		0x00000010
#define jBIT_5		0x00000020
#define jBIT_6		0x00000040
#define jBIT_7		0x00000080
#define jBIT_8		0x00000100
#define jBIT_9		0x00000200
#define jBIT_10		0x00000400
#define jBIT_11		0x00000800
#define jBIT_12		0x00001000
#define jBIT_13		0x00002000
#define jBIT_14		0x00004000
#define jBIT_15		0x00008000
#define jBIT_16		0x00010000
#define jBIT_17		0x00020000
#define jBIT_18		0x00040000
#define jBIT_19		0x00080000
#define jBIT_20		0x00100000
#define jBIT_21		0x00200000
#define jBIT_22		0x00400000
#define jBIT_23		0x00800000
#define jBIT_24		0x01000000
#define jBIT_25		0x02000000
#define jBIT_26		0x04000000
#define jBIT_27		0x08000000
#define jBIT_28		0x10000000
#define jBIT_29		0x20000000
#define jBIT_30		0x40000000
#define jBIT_31		0x80000000


#define MASK_OFF			0x00000000
#define MASK_ON				0xffffffff



#define jSET_FLAG(var , bit)\
	bool GetFlag_##var(){ return m_iFlag &bit; }\
	void SetFlag_##var(bool is){ if(is) m_iFlag |=bit; 	else		m_iFlag &=~(bit); }

#define jFLAG_ENUM(enum_bit)\
	bool GetFlag_##enum_bit() const { return m_iFlag &enum_bit; }\
	void SetFlag_##enum_bit(bool is){ if(is) m_iFlag |=enum_bit; 	else		m_iFlag &=~(enum_bit); }


#define jFLAG_ENUM_VAL(val, enum_bit)\
	bool GetFlag_##enum_bit() const { return val &enum_bit; }\
	void SetFlag_##enum_bit(bool is){ if(is) val |=enum_bit; 	else		val &=~(enum_bit); }

namespace nMech
{
	template<typename T>	inline int jGETFLAG(T var, int bit) { return (var & bit);}
	template<typename T>	inline void jSETFLAG(T& var, int bit, bool is) {	if(is) var|=bit;	else var &=~bit;}

	//--------------------------------------------------------------------------
	class jFlagHelper
		//--------------------------------------------------------------------------
	{
		/*
		int m_iFlag = 0;
		bool myOldValue=jGETFLAG(m_iFlag,jBIT_12);
		bool myNewValue = true;
		jFlagHelper  flagTinyXml(m_iFlag, jBIT_12, myNewValue);
		jEQUAL(flagTinyXml.Get() , myNewValue);
		flagTinyXml.Set(false);
		jEQUAL(flagTinyXml.Get() , false);
		flagTinyXml.Reset();
		jEQUAL(flagTinyXml.Get() , myOldValue);
		*/
	private:
		int &m_iFlag;
		int m_iBit;
		bool m_bNewVal;
		bool m_bOldVal;
	public:
#pragma warning(disable : 4800)
		jFlagHelper(int& flag, int bit, bool bNewVal)	:m_iFlag(flag),m_iBit(bit), m_bNewVal(bNewVal)	
		{	
			m_bOldVal = (bool)jGETFLAG(flag, bit);
			Set();
		}
		bool Get(){ return (bool)jGETFLAG(m_iFlag,m_iBit);}
#pragma warning(default : 4800)

		~jFlagHelper(){ Reset();}
		void Set(bool is)	{		jSETFLAG(m_iFlag, m_iBit, is);}
		void Set()	{		jSETFLAG(m_iFlag, m_iBit, m_bNewVal);}
		void Reset() { jSETFLAG(m_iFlag, m_iBit, m_bOldVal);}
	};

	template<typename T>	struct jChangeHelper
	{
		T& m_TargetVar;
		T m_savedValue;
		jChangeHelper(T &oldValue,T newValue): m_TargetVar(oldValue),m_savedValue(oldValue){ m_TargetVar = newValue;}
		~jChangeHelper(){ m_TargetVar= m_savedValue; }
	};

}


#define jSET_GET(type, var) type m_##var;type Get_##var(){return m_##var;};void Set_##var(type val){m_##var=val;}


// use -> jSET_FLAG(MouseOver, jBIT_0);



#define Naked				__declspec( naked )
#define Naked_Fast  __declspec( naked ) __fastcall
/////////////////////////////////////////////////////
#define _Naked_Start()	\
	__asm{push ebp}	__asm{mov ebp, esp}	\
	__asm{sub esp, __LOCAL_SIZE}
#define  _Naked_End(i)		\
	__asm{mov esp, ebp} __asm{pop ebp} __asm{ret}
/////////////////////////////////////////////////////

/////////////////////////////////////////////////////
#define Naked_Start()	_Naked_Start() \
	__asm{ push ebx} __asm{push edi} __asm{push esi}
#define  Naked_End(i)		\
	__asm{ pop esi} __asm{pop edi} __asm{pop ebx}\
	_Naked_End(i)
/////////////////////////////////////////////////////

/////////////////////////////////////////////////////
#define Naked_Start_d()	_Naked_Start(); __asm{push edi}
#define  Naked_End_d(i)	__asm{pop edi} _Naked_End(i);
/////////////////////////////////////////////////////

/////////////////////////////////////////////////////
#define Naked_Start_b()		_Naked_Start() __asm{push ebx}
#define Naked_End_b(i)		__asm{pop ebx} _Naked_End(i)
/////////////////////////////////////////////////////

/////////////////////////////////////////////////////
#define Naked_Start_bd()		Naked_Start_b() __asm{push edi}
#define Naked_End_bd(i)		__asm{pop edi}  Naked_End_b(i)
/////////////////////////////////////////////////////


#define jDXM(X) ( *(D3DXMATRIX*)(void*)&X)
#define jDV3(x) ( *(D3DXVECTOR3*)(void*)&x)
#define jP3(x) ( *(jPoint3*)(void*)&x)
#define jDC4(x) ( *(D3DCOLORVALUE*)(void*)&x)

#ifndef jFOR
#define jFOR( a , it) for( it = (a).begin() ; it != (a).end(); ++it)
#define pFOR(a,it) for(it=(a);it;it=it->GetParent() )
#define rFOR(a,it) for(it=(a);it;it=it->GetRight())
#define cFOR(a,it) for(it=(a)->begin();it;it=it->GetRight())
#define lFOR(a,it) for(it=(a);it;it=it->GetLeft() )
#define jrFOR(it) for(; it ; it=it->GetRight() )
#define eFOR(it) for( ; it.full() ; it = it->GetRight() )
#endif // jFOR

#define ___jJOIN___(x,y) x##y
#define _jJOIN_(x,y) ___jJOIN___(x,y)
#define _jJOIN_2(x,y) _jJOIN_(x,y)
#define _jJOIN_3(x,y,z) _jJOIN_2(_jJOIN_(x,y),z)
#define _jJOIN_4(x,y,z,z1) _jJOIN_3(_jJOIN_(x,y),z,z1)
#define _jJOIN_5(x,y,z,z1,z2) _jJOIN_4(_jJOIN_(x,y),z,z1,z2)

#define ___jWIDEN2___(x) L ## x
#ifdef UNICODE
#define jTEXT(x) ___jWIDEN2___(#x)
#else
#define jTEXT(x) #x
#endif

#define __WFILE__ WIDEN(__FILE__)

#define CONCAT_3_(x, y)					x##y
#define CONCAT_2_(x, y)					CONCAT_3_(x, y)
#define CONCAT(x, y)					CONCAT_2_(x, y)
#define UIDEN(x)						CONCAT(x, __LINE__)

#define jONCE										for (int UIDEN(_once) = 0; UIDEN(_once)++ == 0;)
#define jTWICE										for (int UIDEN(_twice) = 2; UIDEN(_twice)-- > 0;)

#ifndef ja_strcpy1
#	define ja_strcpy1(var,sz) strncpy_s(var,sz,sizeof(var)-1);var[sizeof(var)-1]=0;
#	define ja_strncpy1(var,sz,n) strncpy(var,sz,n-1);var[n-1]=0;

#	define jt_strcpy1(var,sz) jt_strncpy_s(var,sz,sizeof(var)-1);var[sizeof(var)-1]=0;
#	define jt_strncpy1(var,sz,n) jt_strncpy(var,sz,n-1);var[n-1]=0;

#	define jw_strcpy1(var,sz) jw_strncpy_s(var,sz,sizeof(var)/2-1);var[sizeof(var)/2-1]=0;
#	define jw_strncpy1(var,sz,n) jw_strncpy(var,sz,n-1);var[n-1]=0;
#endif


#define SQL_OK(res)		((res) == SQL_SUCCESS || (res) == SQL_SUCCESS_WITH_INFO)
#define SQL_ERR(res)	(!SQL_OK(res))
#define SAFE_STR(str)	((str == NULL) ? _T("") : str)


// #pragma warning(disable : 4251)

#define jD3DCOLOR_ARGB(a,r,g,b) 	((uint)((((a)&0xff)<<24)|(((r)&0xff)<<16)|(((g)&0xff)<<8)|((b)&0xff)))

#ifndef SAFE_DELETE
#define SAFE_DELETE(p)			{ if(p) { delete (p);		(p)=NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p)	{ if(p) { delete[] (p);		(p)=NULL; } }
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)			{ if(p) { (p)->Release();	(p)=NULL; } }
#endif

#ifndef SAFE_RELEASE_FORCE
#define SAFE_RELEASE_FORCE(p)			{ if(p) { (p)->Release(1);	(p)=NULL; } }
#endif


#ifndef CLAMP
#define CLAMP(X, mn, mx) (X<mn ? mn : X<mx ? X : mx)
#endif

#ifndef LERP
#define LERP(A, B, Alpha) (A + Alpha * (B-A))
#endif



#define jONCE_RUN(jcls_x) struct UIDEN(jcls_x) { 	UIDEN(jcls_x)(); };static UIDEN(jcls_x) _jJOIN_2(UIDEN(jcls_x),_var); UIDEN(jcls_x)::UIDEN(jcls_x)()
#define jONCE_RUN_CTOR(jcls_x) struct jcls_x { 	jcls_x(); ~jcls_x(); };static jcls_x s_##jcls_x; jcls_x::jcls_x()
#define jONCE_RUN_DTOR(jcls_x) jcls_x::~jcls_x()




// macro for structure alignement
#ifdef LINUX
#define DEFINE_ALIGNED_DATA( type, name, alignment ) type name __attribute__ ((aligned(alignment)));
#define DEFINE_ALIGNED_DATA_STATIC( type, name, alignment ) static type name __attribute__ ((aligned(alignment)));
#define DEFINE_ALIGNED_DATA_CONST( type, name, alignment ) const type name __attribute__ ((aligned(alignment)));
#else
#define DEFINE_ALIGNED_DATA( type, name, alignment ) _declspec(align(alignment)) type name;
#define DEFINE_ALIGNED_DATA_STATIC( type, name, alignment ) static _declspec(align(alignment)) type name;
#define DEFINE_ALIGNED_DATA_CONST( type, name, alignment ) const _declspec(align(alignment)) type name;
#endif



#ifndef DEBUG_BREAK
#ifndef _WIN64
	#if defined(WIN32) 
	#define DEBUG_BREAK _asm { int 3 }
	#else 
	#define DEBUG_BREAK
	#endif
#else
	#define DEBUG_BREAK __debugbreak();
#endif

#endif



/*
#pragma warning(disable : 4267)
#pragma warning(default : 4267)

// bool , int ����
#pragma warning(disable : 4805)
#pragma warning(default : 4805)

DLL �ɹ���������
#pragma warning(disable : 4251)
#pragma warning(default : 4251)


//--------------------------------------------------------------------------
����ü ũ������
//--------------------------------------------------------------------------
#pragma pack(1)
 1����Ʈ ������ �մϴ�.
#pragma pack()
 �⺻ ������ �մϴ�.(4 or 8 ����Ʈ ����)  

*/




//////////////////////////////////////////////////////////////////////////
// #pragma message TODO(msg) ������ - �ؾ��� ��

#define jLINE1(x) #x
#define jLINE(x) jLINE1(x)
#define jTODO(msg)   message ( __FILE__ "(" jLINE(__LINE__)  "): [jTODO] " #msg )
#define jNOTE(msg)   message ( __FILE__ "(" jLINE(__LINE__)  "): [jNOTE] " #msg )

// ���� :
// #pragma TODO( "�ؾ��� ��" )
/*
http://www.npteam.net/311
#pragma�� �̿��ؼ� ������Ʈ�� ������ F4 ����Ű�� ã�ư� �� �ְ� �ϴ� ���

���� �� �κ��� �����ؼ� stdafx.h.. ���� ��ġ�� ������ �� �ҽ��ڵ� �߰���
#pragma TODO( "WM_TIMER - Ÿ�̸� ó�� �̱���" )

�̿� ���� �߰��ϸ� ������ �� Build â�� ������ ǥ�õȴ�. 

��ó : TTF���α�(http://www.npteam.net)
*/


//using namespace nMech;

#define jDECL_VAR(TYPE,VAR,INIT_VAL,HELP) TYPE VAR;


#ifdef _WIN32
#define jMB(x,y) ::MessageBoxA(0, x,y, MB_OK)
#define jMBW(x,y) ::MessageBoxW(0, x,y, MB_OK)
#endif

#define jSET_LOCALE() std::locale::global( std::locale( g_ExeEnv.GetDefaultLocale() ) ); 
#define jSET_LOCALE1(LANG) std::locale::global( std::locale( LANG ) ); 


#define jPLUS(X,TYPE) ( X=(TYPE)(X+1))
#define jMINUS(X,TYPE) ( X=(TYPE)(X-1))
template<typename T> T jPlus(T &x,int val=1){x = (T)(x+val);return x;}
template<typename T> T jMinus(T &x,int val=1){x = (T)(x-val);return x;}


//--------------------------------------------------------------------------
// LAMDA ����
//--------------------------------------------------------------------------
// X�� �Ϲ��� �Ķ����Ǹ� �ǹ��ϰ�	Z�� �Ǹ����� �Ķ����Ǹ� �ǹ�.
#define _jLAMDA_MEMBER_(TYPE,VAL) TYPE VAL;
#define _jLAMDA_ARG_X(TYPE ,VAL) TYPE _##VAL,
#define _jLAMDA_ARG_Z(TYPE ,VAL) TYPE _##VAL
#define _jLAMDA_SET_ARG_X(TYPE,VAL) VAL(_##VAL),
#define _jLAMDA_SET_ARG_Z(TYPE,VAL) VAL(_##VAL)

#define jLAMDA_begin(STRUCT)	struct STRUCT{jLAMDA_##STRUCT(_jLAMDA_MEMBER_,_jLAMDA_MEMBER_); \
	STRUCT(){};\
	STRUCT( jLAMDA_##STRUCT(_jLAMDA_ARG_X,_jLAMDA_ARG_Z)):\
	jLAMDA_##STRUCT(_jLAMDA_SET_ARG_X,_jLAMDA_SET_ARG_Z){}\


#define jLAMDA_begin2(STRUCT,BASE)	struct STRUCT: public BASE{jLAMDA_##STRUCT(_jLAMDA_MEMBER_,_jLAMDA_MEMBER_); \
	STRUCT( jLAMDA_##STRUCT(_jLAMDA_ARG_X,_jLAMDA_ARG_Z)):\
	jLAMDA_##STRUCT(_jLAMDA_SET_ARG_X,_jLAMDA_SET_ARG_Z){}\

/*
jLAMDA_jStr(X,Z) X(int,iVal) X(float,fVal) Z(cstr,sz)
jLAMDA_begin(jStr)
void func1(){}
void func2(){}
jLAMDA_end();
*/

#define jLAMDA_CTOR(STRUCT)	struct STRUCT{jLAMDA_##STRUCT(_jLAMDA_MEMBER_,_jLAMDA_MEMBER_); \
	STRUCT(){};\
	STRUCT( jLAMDA_##STRUCT(_jLAMDA_ARG_X,_jLAMDA_ARG_Z)):\
	jLAMDA_##STRUCT(_jLAMDA_SET_ARG_X,_jLAMDA_SET_ARG_Z)\

/*

// X(lamdaȯ�溯����) , Z(lamdbȯ�溯���� ������)
#define jLAMDA_jServerUserCountInfo(X,Z) \
X(serverid_t ,sid)\
Z(uint16,totClient)
jLAMDA_CTOR(jServerUserCountInfo)
{
}
jLAMDA_end();


*/

#define jLAMDA_for_each0(NAME,IT_TYPE) struct NAME{	void operator()(IT_TYPE it)
#define jLAMDA_for_each(STRUCT,IT)	struct STRUCT{jLAMDA_##STRUCT(_jLAMDA_MEMBER_,_jLAMDA_MEMBER_); \
	STRUCT( jLAMDA_##STRUCT(_jLAMDA_ARG_X,_jLAMDA_ARG_Z)):\
	jLAMDA_##STRUCT(_jLAMDA_SET_ARG_X,_jLAMDA_SET_ARG_Z){}\
	void operator()(IT it)

#define jLAMDA_find_if0(NAME,IT_TYPE) struct NAME{	bool operator()(IT_TYPE it)
#define jLAMDA_find_if(STRUCT,IT)	struct STRUCT{jLAMDA_##STRUCT(_jLAMDA_MEMBER_,_jLAMDA_MEMBER_); \
	STRUCT( jLAMDA_##STRUCT(_jLAMDA_ARG_X,_jLAMDA_ARG_Z)):\
	jLAMDA_##STRUCT(_jLAMDA_SET_ARG_X,_jLAMDA_SET_ARG_Z){}\
	bool operator()(IT it)


#define jLAMDA_end() };


/* ��뿹

#define jLAMDA_asdf(X,Z) Z(vector<jServerInfo>&,servers)
		jLAMDA_for_each(asdf,jAqServerNode*)
		{
			servers.push_back(it->m_info);
		}
		jLAMDA_end();

		g_SG.for_each(asdf(servers));

*/

#define jSPREED_SYSTEMTIME(t) t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond
#define jSPREED_SYSTEMTIME_PTR(t) &t.wYear,&t.wMonth,&t.wDay,&t.wHour,&t.wMinute,&t.wSecond
#define jPRINTF_SYSTEMTIME "%02d-%02d-%02d %02d:%02d:%03d"





#define jDEBUG_LINE_INFO _T(__FILE__) _T(":") _T(__FUNCTION__) 

#define jLOG_T(fmt,...) nRocDebug::jPrintf(_T(fmt),__VA_ARGS__);
#define jWARN_T(fmt,...) nRocDebug::jPrintf(_T("[WARN] ") _T(fmt),__VA_ARGS__);
#define jERROR_T(fmt,...) nRocDebug::jPrintf(_T("[ERROR] ") _T(fmt),__VA_ARGS__);

#define jLOG(...) nRocDebug::jPrintf(__VA_ARGS__);
#define jWARN(...) nRocDebug::jPrintf(_T("[WARN] ") __VA_ARGS__);
#define jERROR(...) nRocDebug::jPrintf(_T("[ERROR] ") __VA_ARGS__);

#define jASSERT_TAG					UIDEN(__ASSERT_)

#define jASSERT(exp,...) if(!(exp)) {jERROR(_T("jASSERT: ") _T(#exp)  _T(":") jDEBUG_LINE_INFO __VA_ARGS__);}
#define jAssert0(exp) if(!(exp)){jERROR(_T(#exp) _T("jAssert0:") jDEBUG_LINE_INFO _T(":%d") , __LINE__);}
#define jIF_NOT(exp) bool jASSERT_TAG=(exp);if(!jASSERT_TAG){jWARN(_T(#exp) _T(" jIF_NOT:") jDEBUG_LINE_INFO); };if(!jASSERT_TAG)

#define jCHECK(exp) if(!(exp)){jWARN(_T("jCHECK") _T(#exp) );}
#define jCONTINUE(exp) if(!(exp)){jWARN(_T("jCONTINUE") _T(#exp) );continue;}
#define jBREAK(exp) if(!(exp)){jWARN(_T("jBREAK") _T(#exp) );break;}
#define jTHROW(exp) if(!(exp)){jWARN(_T("jTHROW") _T(#exp) );throw _T("jTHROW : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO;}
#define jRETURN(exp) if(!(exp)){jWARN( _T("jRETURN : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO);  return;}
#define jRETURN_ret(ret,exp) if(!(exp)){jWARN(_T("jRETURN_VAL : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO);  return ret;}
#define jRAISE(exp) if(!(exp)){jWARN( _T("jRETURN : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO);  \
								RaiseException( __LINE__, EXCEPTION_ACCESS_VIOLATION, 0, NULL );}


#define jvCHECK(exp,...) if(!(exp)){jWARN(_T("jCHECK") _T(#exp) __VA_ARGS__);}
#define jvCONTINUE(exp,...) if(!(exp)){jWARN(_T("jCONTINUE") _T(#exp) __VA_ARGS__);continue;}
#define jvBREAK(exp,...) if(!(exp)){jWARN(_T("jBREAK") _T(#exp) __VA_ARGS__);break;}
#define jvTHROW(exp,...) if(!(exp)){jWARN(_T("jTHROW") _T(#exp) __VA_ARGS__);throw _T("jTHROW : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO;}
#define jvRETURN(exp,...) if(!(exp)){jWARN( _T("jRETURN : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO __VA_ARGS__);  return;}
#define jvRETURN_ret(ret ,exp, ...) if(!(exp)){jWARN(_T("jRETURN_VAL : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO __VA_ARGS__);  return ret;}
#define jvRAISE(exp,...) if(!(exp)){jWARN( _T("jRETURN : ") _T(#exp)  _T(":") jDEBUG_LINE_INFO __VA_ARGS__);  \
									RaiseException( __LINE__, EXCEPTION_ACCESS_VIOLATION, 0, NULL );}


#define _ENUM_COMMON_FUNCTION_(ENUM)\
	inline ENUM FromHelpString(const tstring& str, ENUM e){ return FromHelpString(str.c_str(), e);}\
	inline ENUM FromString(const tstring& str, ENUM e){ return FromString(str.c_str(), e);}\
	inline tcstr ToStringFromHelpString(tcstr str,ENUM e){return ToString(FromHelpString(str,e) );}\
	inline tcstr ToHelpStringFromString(tcstr str,ENUM e){return ToHelpString(FromString(str,e) );}\
	inline tcstr ToStringFromHelpString(const tstring &str,ENUM e){return ToString(FromHelpString(str.c_str(),e) );}\
	inline tcstr ToHelpStringFromString(const tstring &str,ENUM e){return ToHelpString(FromString(str.c_str(),e) );}\

#define _ENUM_ToHelpString(eVAR,iVal,help) if(eVAR==eInputVal) return _T(help);
#define _ENUM_ToString(eVAR,iVal,help) if(eVAR==eInputVal) return _T(#eVAR);
#define _ENUM_FromString(eVAR,iVal,help) if(jt_strcmp(str,_T(#eVAR))==0) return eVAR;
#define _ENUM_FromHelpString(eVAR,iVal,help) if(jt_strcmp(str,_T(help))==0) return eVAR;
#define _ENUM_field_declare(eVAR,iVal,help)	eVAR=iVal,

// FUNC(eVAR,iVal,"help")
#define jDEFINE_ENUM_CODE(ENUM) enum ENUM{ for_each_##ENUM(_ENUM_field_declare)  ENUM##_MAX };\
	inline tcstr ToHelpString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToHelpString); return _T("Unkown");};\
	inline tcstr ToString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToString); return _T("Unkown");};\
	inline ENUM FromString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromString); return ENUM##_MAX;}\
	inline ENUM FromHelpString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromString); return ENUM##_MAX;}\
	_ENUM_COMMON_FUNCTION_(ENUM)\



#define _ENUM_ToHelpString2(eVAR,help) if(eVAR==eInputVal) return _T(help);
#define _ENUM_ToString2(eVAR,help) if(eVAR==eInputVal) return _T(#eVAR);
#define _ENUM_FromString2(eVAR,help) if(jt_strcmp(str,_T(#eVAR))==0) return eVAR;
#define _ENUM_FromHelpString2(eVAR,help) if(jt_strcmp(str,_T(help))==0) return eVAR;
#define _ENUM_field_declare2(eVAR,help)	eVAR,

// FUNC(eVAR,"help")
#define jDEFINE_ENUM_CODE2(ENUM) enum ENUM{ for_each_##ENUM(_ENUM_field_declare2)  ENUM##_MAX };\
	inline tcstr ToHelpString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToHelpString2); return _T("Unkown");};\
	inline tcstr ToString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToString2); return _T("Unkown");};\
	inline ENUM FromString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromString2); return ENUM##_MAX;}\
	inline ENUM FromHelpString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromHelpString2); return ENUM##_MAX;}\
	_ENUM_COMMON_FUNCTION_(ENUM)\


#define _ENUM_ToHelpString3(eVAR,help,VALUE3) if(eVAR==eInputVal) return _T(help);
#define _ENUM_ToString3(eVAR,help,VALUE3) if(eVAR==eInputVal) return _T(#eVAR);
#define _ENUM_FromString3(eVAR,help,VALUE3) if(jt_strcmp(str,_T(#eVAR))==0) return eVAR;
#define _ENUM_FromHelpString3(eVAR,help,VALUE3) if(jt_strcmp(str,_T(help))==0) return eVAR;
#define _ENUM_field_declare3(eVAR,help,VALUE3)	eVAR,

// FUNC(eVAR,"help",VALUE3)
#define jDEFINE_ENUM_CODE3(ENUM) enum ENUM{ for_each_##ENUM(_ENUM_field_declare3)  ENUM##_MAX };\
	inline tcstr ToHelpString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToHelpString3); return _T("Unkown");};\
	inline tcstr ToString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToString3); return _T("Unkown");};\
	inline ENUM FromHelpString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromHelpString3); return ENUM##_MAX;}\
	inline ENUM FromString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromString3); return ENUM##_MAX;}\
	_ENUM_COMMON_FUNCTION_(ENUM)\


#define _ENUM_ToHelpString4(eVAR,help,VALUE3,VALUE4) if(eVAR==eInputVal) return _T(#eVAR) _T(":") _T(help);
#define _ENUM_ToString4(eVAR,help,VALUE3,VALUE4) if(eVAR==eInputVal) return _T(#eVAR);
#define _ENUM_FromString4(eVAR,help,VALUE3,VALUE4) if(jt_strcmp(str,_T(#eVAR))==0) return eVAR;
#define _ENUM_field_declare4(eVAR,help,VALUE3,VALUE4)	eVAR,

// FUNC(eVAR,"help",VALUE3,VALUE4)
#define jDEFINE_ENUM_CODE4(ENUM) enum ENUM{ for_each_##ENUM(_ENUM_field_declare4)  ENUM##_MAX };\
	inline tcstr ToHelpString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToHelpString4); return _T("Unkown");};\
	inline tcstr ToString(ENUM eInputVal){for_each_##ENUM(_ENUM_ToString4); return _T("Unkown");};\
	inline ENUM FromHelpString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromHelpString4); return ENUM##_MAX;}\
	inline ENUM FromString(tcstr str, ENUM){ for_each_##ENUM(_ENUM_FromString4); return ENUM##_MAX;}\
	_ENUM_COMMON_FUNCTION_(ENUM)\

/*
jDEFINE_ENUM_CODE ����.

	enum EResult_Code{ ... } ���� 

		#define for_each_EResult_Code(X)\
		X(eOK				,0		," Ȯ�� �Ǿ����ϴ�.")\
		X(eERROR			,10		,"Ȯ�κҰ�. �߸��� Ű�Դϴ�.")\
		X(eSERVICE_ERROR	,-10	,"���� ����")\
		X(eIP_ERROR			,-11	,"���� ���� ������ �ƴ�")\

		jDEFINE_ENUM_CODE(EResult_Code);

		#define for_each_EResult_Code2(X)\
		X(eOK					," Ȯ�� �Ǿ����ϴ�.")\
		X(eERROR				,"Ȯ�κҰ�. �߸��� Ű�Դϴ�.")\
		X(eSERVICE_ERROR		,"���� ����")\
		X(eIP_ERROR				,"���� ���� ������ �ƴ�")\

		jDEFINE_ENUM_CODE2(EResult_Code2);



	��� ���� �ڵ� 

		EResult_Code e = eSERVICE_ERROR;
		assert( ToString(e) == string("eSERVICE_ERROR") );
		assert( ToHelpString(e) == string("eSERVICE_ERROR:���� ����") );
		assert( FromString("���� ����", EResult_Code_MAX) == e);
*/


#define JBASE_API

#endif // __jDefine_header__
