using System.Reflection;

[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Protocol Buffers DataReader extensions for .NET")]
[assembly: AssemblyCopyright("Copyright � Richard Dingwall 2011")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]


